
export const ROLES = {
  SUPERADMIN: 'SUPERADMIN',
  ADMIN: 'ADMIN',
  TENANT: 'TENANT',
  CUSTOMER: 'CUSTOMER',
};

const loadInitialData = (key, defaultData) => {
  const saved = localStorage.getItem(`beamcard_${key}`);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.warn(`Failed to parse beamcard_${key}`);
    }
  }
  return defaultData;
};

const saveToStorage = (key, data) => {
  localStorage.setItem(`beamcard_${key}`, JSON.stringify(data));
};

// Initial Data
let companies = loadInitialData('companies', [
  { id: 'c1', name: 'Cafe Aroma', status: 'active', type: 'loyalty', logo: 'https://picsum.photos/seed/aroma/200/200' },
  { id: 'c2', name: 'Tech Store', status: 'active', type: 'loyalty', logo: 'https://picsum.photos/seed/tech/200/200' },
  { id: 'c3', name: 'Gym Elite', status: 'suspended', type: 'loyalty', logo: 'https://picsum.photos/seed/gym/200/200' },
]);

let users = [
  { id: 'u1', email: 'admin@beamcard.com', password: 'admin', role: ROLES.SUPERADMIN, name: 'Global Admin' },
  { id: 'u2_legacy', email: 'owner@aroma.com', password: 'owner', role: ROLES.TENANT, name: 'Aroma Owner', companyId: 'c1' },
  { id: 'u2', email: 'owner1@aroma.com', password: 'owner', role: ROLES.TENANT, name: 'Aroma Owner 1', companyId: 'c1' },
  { id: 'u3', email: 'owner2@aroma.com', password: 'owner', role: ROLES.TENANT, name: 'Aroma Owner 2', companyId: 'c1' },
  { id: 'u4', email: 'owner1@tech.com', password: 'owner', role: ROLES.TENANT, name: 'Tech Owner 1', companyId: 'c2' },
  { id: 'u5', email: 'owner2@tech.com', password: 'owner', role: ROLES.TENANT, name: 'Tech Owner 2', companyId: 'c2' },
  { id: 'u6', email: 'owner1@gym.com', password: 'owner', role: ROLES.TENANT, name: 'Gym Owner 1', companyId: 'c3' },
  { id: 'u7', email: 'owner2@gym.com', password: 'owner', role: ROLES.TENANT, name: 'Gym Owner 2', companyId: 'c3' },
  { id: 'u8', email: 'ahmed@gmail.com', password: 'user', role: ROLES.CUSTOMER, name: 'Ahmed' },
];



let cardPrograms = loadInitialData('programs', [
  { 
    id: 'prog_1', 
    companyId: 'c1', 
    type: 'loyalty', 
    programName: 'Aroma Rewards', 
    logo: 'https://picsum.photos/seed/aroma/200/200',
    rules: { pointsPerPurchase: 10 },
    googleClassId: 'issuer_id.class_id_1',
    applePassTypeIdentifier: 'pass.com.beamcard.aroma',
    appleTeamIdentifier: 'TEAMID1234'
  },
]);

let cards = [
  { 
    id: 'card_1', 
    companyId: 'c1', 
    userId: 'u8',
    programId: 'prog_1',
    name: 'Ahmed', 
    email: 'ahmed@gmail.com',
    phone: '+123456789', 
    currentBalance: 120, 
    savedToWallet: false,
    type: 'loyalty',
    status: 'active',
    walletIds: {
      googleObjectId: 'issuer.c1.card_1',
      appleSerialNumber: 'serial_12345',
      appleAuthenticationToken: 'auth_token_abc123'
    }
  },
  { 
    id: 'card_2', 
    companyId: 'c1', 
    userId: 'u8',
    programId: 'prog_1',
    name: 'Ahmed', 
    email: 'ahmed@gmail.com',
    phone: '+123456789', 
    currentBalance: 0, 
    savedToWallet: false,
    type: 'business_card',
    status: 'active',
    jobTitle: 'Creative Director',
    website: 'https://aroma.com',
    linkedin: 'https://linkedin.com/in/ahmed-aroma',
    walletIds: {
      googleObjectId: 'issuer.c1.card_2',
      appleSerialNumber: 'serial_67890',
      appleAuthenticationToken: 'auth_token_def456'
    }
  },
];

let transactions = [
  { id: 'tx_1', cardId: 'card_1', companyId: 'c1', type: 'award', amount: 100, date: new Date().toISOString(), note: 'Initial points' },
  { id: 'tx_2', cardId: 'card_1', companyId: 'c1', type: 'award', amount: 20, date: new Date().toISOString(), note: 'Coffee purchase' },
];

let subscription_plan= [
  {
    "id": "basic",
    "name": "Basic",
    "price": 0,
    "currency": "CHF",
    "billingPeriod": "month",
    "description": "With the Basic plan, the user can create a digital business card without individual customization.",
    "features": [
      "Presentation with Beamcard branding",
      "Beamcard logo remains visible",
      "No custom colors or personal logo",
      "Upgrade to Pro at any time"
    ],
    "target": "Ideal for testing the platform"
  },
  {
    "id": "pro",
    "name": "Pro",
    "price": 4.9,
    "currency": "CHF",
    "billingPeriod": "month",
    "description": "With the Pro plan, the digital business card can be fully customized.",
    "features": [
      "Custom colors",
      "Personal logo",
      "Remove Beamcard branding",
      "Edit information at any time",
      "Professional and flexible presentation"
    ],
    "target": "Perfect for freelancers, entrepreneurs, and personal brands"
  },
  {
    "id": "team",
    "name": "Team",
    "price": 29.9,
    "currency": "CHF",
    "billingPeriod": "month",
    "description": "The Team plan is designed for companies and organizations.",
    "features": [
      "Up to 5 personalized business cards included",
      "Centralized management by an administrator",
      "Update information at any time",
      "Ability to add additional collaborators"
    ],
    "target": "Ideal for teams and businesses"
  }
]

import { api as axiosApi } from './api/axios';

export const api = {
  login: async (email, password) => {
    const { data } = await axiosApi.post('/auth/login', { email, password });
    return data;
  },

  register: async (email, password, name) => {
    const { data } = await axiosApi.post('/auth/register', { email, password, name });
    return data;
  },

  logout: async () => {
    const { data } = await axiosApi.post('/auth/logout');
    return data;
  },

  getUsers: async (params = {}) => {
    const { data } = await axiosApi.get('/users', { params });
    return data;
  },

  createUser: async (userData) => {
    const { data } = await axiosApi.post('/users', userData);
    return data;
  },

  updateUser: async (id, userData) => {
    const { data } = await axiosApi.put(`/users/${id}`, userData);
    return data;
  },

  deleteUser: async (id) => {
    const { data } = await axiosApi.delete(`/users/${id}`);
    return data;
  },
  
  findUserByContact: async (contact) => {
    const { data } = await axiosApi.get('/users/find-by-contact', { params: { contact } });
    return data;
  },

  getCompanies: async (params = {}) => {
    const { data } = await axiosApi.get('/companies', { params });
    return data;
  },

  createCompany: async (companyData) => {
    const { data } = await axiosApi.post('/companies', companyData);
    return data;
  },

  updateCompany: async (id, companyData) => {
    const { data } = await axiosApi.put(`/companies/${id}`, companyData);
    return data;
  },

  updateCompanyStatus: async (id, status) => {
    const { data } = await axiosApi.put(`/companies/${id}`, { status });
    return data;
  },

  deleteCompany: async (id) => {
    const { data } = await axiosApi.delete(`/companies/${id}`);
    return data;
  },

  getCompanyById: async (id) => {
    const { data } = await axiosApi.get(`/companies/${id}`);
    return data;
  },

  getCardPrograms: async (params = {}) => {
    const { data } = await axiosApi.get(`/card-programs`, { params });
    return data;
  },

  getProgramById: async (programId) => {
    const { data } = await axiosApi.get(`/card-programs/${programId}`);
    return data;
  },

  createCardProgram: async (programData) => {
    const { data } = await axiosApi.post('/card-programs', programData);
    return data;
  },

  getCards: async (params = {}) => {
    const { data } = await axiosApi.get('/cards', { params });
    return data;
  },

  getUniqueCustomers: async (params = {}) => {
    const { data } = await axiosApi.get('/cards/unique-customers', { params });
    return data;
  },

  updateCard: async (id, cardData) => {
    const { data } = await axiosApi.put(`/cards/${id}`, cardData);
    return data;
  },

  deleteCard: async (id) => {
    const { data } = await axiosApi.delete(`/cards/${id}`);
    return data;
  },

  createCard: async (cardData) => {
    const { data } = await axiosApi.post('/cards', cardData);
    return data;
  },

  awardPoints: async (cardId, amount, note) => {
    const { data } = await axiosApi.post('/transactions', {
      cardId,
      type: 'award',
      amount: parseInt(amount),
      note
    });
    return data;
  },

  redeemPoints: async (cardId, amount, note) => {
    const { data } = await axiosApi.post('/transactions', {
      cardId,
      type: 'redeem',
      amount: parseInt(amount),
      note
    });
    return data;
  },

  getTransactions: async (params = {}) => {
    const { data } = await axiosApi.get('/transactions', { params });
    return data;
  },

  getCompanyStats: async (companyId) => {
    const txData = await axiosApi.get('/transactions', { params: { companyId } });
    const cardsData = await axiosApi.get('/cards', { params: { companyId, limit: 1 } });
    const transactions = txData.data.data;

    const totalAwarded = transactions.filter(tx => tx.type === 'award').reduce((acc, tx) => acc + tx.amount, 0);
    const totalRedeemed = transactions.filter(tx => tx.type === 'redeem').reduce((acc, tx) => acc + tx.amount, 0);
    const totalBalance = transactions.filter(tx => tx.type === 'award').reduce((acc, tx) => acc + tx.amount, 0)
      - transactions.filter(tx => tx.type === 'redeem').reduce((acc, tx) => acc + tx.amount, 0);

    return {
      totalCustomers: cardsData.data.uniqueCustomers,
      totalCards: cardsData.data.total,
      totalPointsIssued: totalAwarded,
      totalPointsRedeemed: totalRedeemed,
      currentLiability: totalBalance
    };
  },

  adminGetAllCards: async (params = {}) => {
    const { data } = await axiosApi.get('/cards', { params });
    return data;
  },

  getGlobalStats: async () => {
    const { data: companiesResp } = await axiosApi.get('/companies');
    const { data: transactionsResp } = await axiosApi.get('/transactions');
    const { data: cardsResp } = await axiosApi.get('/cards');

    const companies = companiesResp.data;
    const transactions = transactionsResp.data;
    const cards = cardsResp.data;

    const totalPointsIssued = transactions.filter(tx => tx.type === 'award').reduce((acc, tx) => acc + tx.amount, 0);
    const uniqueCustomers = new Set(cards.map(c => c.userId)).size;

    return {
      totalCompanies: companies.length,
      totalCustomers: uniqueCustomers,
      totalPointsIssued
    };
  },

  generateSaveLink: async (cardId) => {
    const card = await api.findOneCard(cardId);
    return { saveUrl: card.walletIds?.jwtLink || null };
  },
  
  findOneCard: async (cardId) => {
    const { data } = await axiosApi.get(`/cards/${cardId}`);
    return data;
  },

  generateProgramShareLink: async (programId) => {
    return {
      shareUrl: `${window.location.origin}/enroll/${programId}`
    };
  },

  enrollCustomerInProgram: async (programId, customerData) => {
    const { data } = await axiosApi.post('/cards', {
      programId,
      ...customerData
    });
    return {
      card: data,
      saveUrl: data.walletIds?.jwtLink || null
    };
  },

  getCardsByUserId: async (userId) => {
    const { data } = await axiosApi.get('/cards', { params: { userId } });
    return data.data;
  },

  getSubscriptionPlans: async () => {
    // In a real app this comes from backend, proxying the hardcoded array from DB for compatibility
    return subscription_plan;
  },

  createCheckoutSession: async (planId) => {
    const { data } = await axiosApi.post('/stripe/create-checkout-session', { planId });
    return data;
  },

  getMySubscription: async () => {
    const { data } = await axiosApi.get('/stripe/my-subscription');
    return data;
  },

  getPlanConfig: async () => {
    const { data } = await axiosApi.get('/stripe/plan-config');
    return data;
  },

  updatePlanConfig: async (config) => {
    const { data } = await axiosApi.put('/stripe/admin/plan-config', config);
    return data;
  }
};

