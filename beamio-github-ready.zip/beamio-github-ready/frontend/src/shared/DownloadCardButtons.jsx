
import { Image as ImageIcon, FileText, Loader2 } from 'lucide-react';

export function DownloadCardButtons({
  onDownloadImage,
  onDownloadPDF,
  isLoading    = false,
  loadingType  = null,
  labelImage   = 'Download as Image',
  labelPDF     = 'Download as PDF',
  className    = '',
}) {
  return (
    <div className={`flex items-center gap-1 ${className}`}>
      {/* ── Image button ── */}
      <div className="relative group">
        <button
          onClick={onDownloadImage}
          disabled={isLoading}
          aria-label={labelImage}
          className="p-2 rounded-full transition-colors cursor-pointer
                     hover:bg-gray-100 dark:hover:bg-gray-800
                     disabled:opacity-50 disabled:cursor-not-allowed
                     flex items-center justify-center"
        >
          {isLoading && loadingType === 'image' ? (
            <Loader2 className="w-5 h-5 text-indigo-500 animate-spin" />
          ) : (
            <ImageIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          )}
        </button>
        {/* Tooltip */}
        <span
          className="pointer-events-none absolute top-full left-1/2 -translate-x-1/2 mt-2
                     whitespace-nowrap rounded-lg bg-gray-900 dark:bg-gray-700
                     px-2.5 py-1 text-[11px] font-medium text-white shadow-lg
                     opacity-0 group-hover:opacity-100 transition-opacity duration-150 z-50"
        >
          {labelImage}
          <span className="absolute bottom-full left-1/2 -translate-x-1/2 border-4
                           border-transparent border-b-gray-900 dark:border-b-gray-700" />
        </span>
      </div>

      {/* ── PDF button ── */}
      <div className="relative group">
        <button
          onClick={onDownloadPDF}
          disabled={isLoading}
          aria-label={labelPDF}
          className="p-2 rounded-full transition-colors cursor-pointer
                     hover:bg-gray-100 dark:hover:bg-gray-800
                     disabled:opacity-50 disabled:cursor-not-allowed
                     flex items-center justify-center"
        >
          {isLoading && loadingType === 'pdf' ? (
            <Loader2 className="w-5 h-5 text-indigo-500 animate-spin" />
          ) : (
            <FileText className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          )}
        </button>
        {/* Tooltip */}
        <span
          className="pointer-events-none absolute top-full left-1/2 -translate-x-1/2 mt-2
                     whitespace-nowrap rounded-lg bg-gray-900 dark:bg-gray-700
                     px-2.5 py-1 text-[11px] font-medium text-white shadow-lg
                     opacity-0 group-hover:opacity-100 transition-opacity duration-150 z-50"
        >
          {labelPDF}
          <span className="absolute bottom-full left-1/2 -translate-x-1/2 border-4
                           border-transparent border-b-gray-900 dark:border-b-gray-700" />
        </span>
      </div>
    </div>
  );
}
