import { toPng } from 'html-to-image';
import { jsPDF } from 'jspdf';
import { useRef, useState } from 'react';


export function useDownloadCard({ filename = 'card' } = {}) {
  const ref = useRef(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingType, setLoadingType] = useState(null); 

  const capture = async () => {
    if (!ref.current) throw new Error('ref not attached');
    return toPng(ref.current, { cacheBust: true, pixelRatio: 2 });
  };

  const downloadImage = async () => {
    if (isLoading || !ref.current) return;
    setIsLoading(true);
    setLoadingType('image');
    try {
      const dataUrl = await capture();
      const link = document.createElement('a');
      link.download = `${filename}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('[useDownloadCard] Image export failed:', err);
    } finally {
      setIsLoading(false);
      setLoadingType(null);
    }
  };

  const downloadPDF = async () => {
    if (isLoading || !ref.current) return;
    setIsLoading(true);
    setLoadingType('pdf');
    try {
      const node = ref.current;
      const dataUrl = await capture();
      const width  = node.offsetWidth  * 2;
      const height = node.offsetHeight * 2;
      const pdf = new jsPDF({
        orientation: width >= height ? 'landscape' : 'portrait',
        unit: 'px',
        format: [width, height],
      });
      pdf.addImage(dataUrl, 'PNG', 0, 0, width, height);
      pdf.save(`${filename}.pdf`);
    } catch (err) {
      console.error('[useDownloadCard] PDF export failed:', err);
    } finally {
      setIsLoading(false);
      setLoadingType(null);
    }
  };

  return { ref, downloadImage, downloadPDF, isLoading, loadingType };
}
