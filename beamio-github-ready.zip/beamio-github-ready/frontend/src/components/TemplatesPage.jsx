import moment from 'moment';
import {
  Briefcase, CheckCircle2, ChevronLeft, ChevronRight, CreditCard,
  Eye, Facebook, Globe, Instagram, Layers, Linkedin, Loader2, Mail, Phone, Plus, Search, Star, X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useCardPrograms } from '../api/hooks/usePrograms';
import { useDebounce } from '../hooks/useDebounce';
import { getProgramEnrollUrl } from './ProgramQRShare';
import { useAuthStore } from '../store/authStore';
import { CreateTemplatePage } from './Tenant';
import { useDownloadCard } from '../shared/useDownloadCard';
import { DownloadCardButtons } from '../shared/DownloadCardButtons';

const AVATAR_GRADIENTS = [
  'from-indigo-500 to-purple-600',
  'from-rose-500 to-pink-600',
  'from-amber-500 to-orange-600',
  'from-emerald-500 to-teal-600',
  'from-sky-500 to-blue-600',
];

const TYPE_STYLES = {
  loyalty:       'bg-indigo-50 text-indigo-700 ring-indigo-200 dark:bg-indigo-900/30 dark:text-indigo-300 dark:ring-indigo-800',
  business_card: 'bg-purple-50 text-purple-700 ring-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:ring-purple-800',
  flight:        'bg-sky-50 text-sky-700 ring-sky-200 dark:bg-sky-900/30 dark:text-sky-300 dark:ring-sky-800',
  offer:         'bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:ring-amber-800',
};

/* ─── Card visual preview ─────────────────────────────────────────────────── */
const CardVisual = ({ template, t }) => {
  const bg        = template.backgroundColor || '#4f46e5';
  const enrollUrl = getProgramEnrollUrl(template._id);
  const isLoyalty = template.type === 'loyalty';
  const isBiz     = template.type === 'business_card';

  return (
    <div
      className="rounded-2xl shadow-lg min-h-[190px] flex flex-col justify-between relative overflow-hidden w-full"
      style={{ backgroundColor: bg, color: '#ffffff' }}
    >
      {/* Hero */}
      <div className="absolute top-0 left-0 w-full h-20 pointer-events-none">
        {template.heroImage ? (
          <>
            <img src={template.heroImage} alt="" className="w-full h-full object-cover opacity-90" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-transparent" />
          </>
        ) : <div className="w-full h-full bg-black/5" />}
      </div>
      <div className="absolute top-0 right-0 w-36 h-36 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl pointer-events-none" />

      {/* Header row */}
      <div className="flex justify-between items-start relative z-10 p-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-white/90 backdrop-blur-md rounded-xl flex items-center justify-center overflow-hidden shadow-sm shrink-0">
            {template.logo
              ? <img src={template.logo} className="w-full h-full object-contain p-1" referrerPolicy="no-referrer" />
              : <CreditCard className="w-5 h-5 text-gray-500" />}
          </div>
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest opacity-90 drop-shadow-md"
               style={{ color: template.heroImage ? '#fff' : '#ffffff' }}>
              {template.issuerName || 'Issuer'}
            </p>
            <p className="text-sm font-bold drop-shadow-md"
               style={{ color: template.heroImage ? '#fff' : '#ffffff' }}>
              {template.programName}
            </p>
          </div>
        </div>
        <CheckCircle2 className="w-5 h-5 opacity-80 drop-shadow-md shrink-0"
                      style={{ color: template.heroImage ? '#fff' : '#ffffff' }} />
      </div>

      {/* Body */}
      <div className="relative z-10 px-4 py-2 flex-1">
        {isLoyalty && (
          <>
            <p className="text-[10px] uppercase tracking-wider font-semibold opacity-70 mb-0.5" style={{ color: '#ffffff' }}>Balance</p>
            <h2 className="text-3xl font-extrabold tracking-tight" style={{ color: '#ffffff' }}>
              {template.rules?.welcomeBonus || 0} <span className="text-sm font-normal opacity-70">pts</span>
            </h2>
          </>
        )}
        {isBiz && (
          <div className="space-y-2 px-1">
            {(template.config?.jobTitle || template.jobTitle) && (
              <p className="text-sm font-semibold opacity-90" style={{ color: '#ffffff' }}>
                {template.config?.jobTitle || template.jobTitle}
              </p>
            )}
            <div className="flex flex-col gap-1">
              {(template.config?.email || template.contactEmail) && (
                <a href={`mailto:${template.config?.email || template.contactEmail}`}
                  className="flex items-center gap-1.5 text-[11px] opacity-80 hover:opacity-100 transition-opacity"
                  style={{ color: '#ffffff' }}>
                  <Mail className="w-3 h-3 shrink-0" />
                  <span className="truncate">{template.config?.email || template.contactEmail}</span>
                </a>
              )}
              {(template.config?.phone || template.contactPhone) && (
                <a href={`tel:${template.config?.phone || template.contactPhone}`}
                  className="flex items-center gap-1.5 text-[11px] opacity-80 hover:opacity-100 transition-opacity"
                  style={{ color: '#ffffff' }}>
                  <Phone className="w-3 h-3 shrink-0" />
                  <span>{template.config?.phone || template.contactPhone}</span>
                </a>
              )}
              {(template.config?.website || template.website) && (
                <a href={template.config?.website || template.website} target="_blank" rel="noreferrer"
                  className="flex items-center gap-1.5 text-[11px] opacity-80 hover:opacity-100 transition-opacity"
                  style={{ color: '#ffffff' }}>
                  <Globe className="w-3 h-3 shrink-0" />
                  <span className="truncate">{template.config?.website || template.website}</span>
                </a>
              )}
            </div>
            <div className="flex items-center gap-3 pt-1">
              {(template.config?.linkedin || template.linkedin) && (
                <a href={template.config?.linkedin || template.linkedin} target="_blank" rel="noreferrer"
                  className="opacity-80 hover:opacity-100 transition-opacity" style={{ color: '#ffffff' }}>
                  <Linkedin className="w-4 h-4" />
                </a>
              )}
              {(template.config?.instagram || template.instagram) && (
                <a href={template.config?.instagram || template.instagram} target="_blank" rel="noreferrer"
                  className="opacity-80 hover:opacity-100 transition-opacity" style={{ color: '#ffffff' }}>
                  <Instagram className="w-4 h-4" />
                </a>
              )}
              {(template.config?.facebook || template.facebook) && (
                <a href={template.config?.facebook || template.facebook} target="_blank" rel="noreferrer"
                  className="opacity-80 hover:opacity-100 transition-opacity" style={{ color: '#ffffff' }}>
                  <Facebook className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="flex justify-between items-end relative z-10 p-4 pt-0">
        {isBiz ? (
          <>
            <div className="flex flex-col items-center gap-1.5">
              <div className="bg-white rounded-xl p-2 shadow-lg">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(enrollUrl)}`}
                  alt="Add to Wallet"
                  className="w-20 h-20 object-contain"
                />
              </div>
              <span className="text-[9px] font-bold uppercase tracking-wider opacity-70" style={{ color: '#ffffff' }}>{t('add_card')}</span>
            </div>
            <div className="flex flex-col items-center gap-1.5">
              <div className="bg-white rounded-xl p-2 shadow-lg">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(
                    `${window.location.origin}/profile/template/${template._id}`
                  )}`}
                  alt="Profile Link"
                  className="w-20 h-20 object-contain"
                />
              </div>
              <span className="text-[9px] font-bold uppercase tracking-wider opacity-70" style={{ color: '#ffffff' }}>{t('profile')}</span>
            </div>
          </>
        ) : (
          <>
            <div className="space-y-0.5">
              {isLoyalty && template.rules?.pointsPerPurchase != null && (
                <p className="text-[10px] font-medium opacity-80" style={{ color: '#ffffff' }}>
                  <span className="font-bold">{t('earning')}:</span> {template.rules.pointsPerPurchase} {t('pts')} / {t('purchase')}
                </p>
              )}
              {template.googleClassId && (
                <p className="text-[10px] font-mono opacity-50" style={{ color: '#ffffff' }}>{template.googleClassId}</p>
              )}
            </div>
            {isLoyalty && (
              <div className="flex flex-col items-center gap-1">
                <div className="bg-white rounded-xl p-1.5 shadow-lg">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${encodeURIComponent(enrollUrl)}`}
                    alt="QR"
                    className="w-14 h-14 object-contain"
                  />
                </div>
                <span className="text-[8px] font-bold uppercase tracking-wider opacity-60" style={{ color: '#ffffff' }}>{t('scan_to_add')}</span>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

/* ─── Info row helper ─────────────────────────────────────────────────────── */
const InfoRow = ({ icon: Icon, label, value, mono = false }) => {
  if (!value && value !== 0) return null;
  return (
    <div className="flex items-start gap-3">
      <div className="p-1.5 bg-gray-100 dark:bg-gray-700 rounded-lg shrink-0 mt-0.5">
        <Icon className="w-3.5 h-3.5 text-gray-500 dark:text-gray-400" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-widest text-gray-400 mb-0.5">{label}</p>
        <p className={`text-sm font-semibold dark:text-white truncate ${mono ? 'font-mono text-xs' : ''}`}>{value}</p>
      </div>
    </div>
  );
};

/* ─── Template preview modal ──────────────────────────────────────────────── */
const TemplatePreviewModal = ({ template, onClose }) => {
  const { t } = useTranslation();
  const isLoyalty = template.type === 'loyalty';
  const isBiz     = template.type === 'business_card';
  const typeStyle = TYPE_STYLES[template.type] || TYPE_STYLES.loyalty;

  const { ref: cardRef, downloadImage, downloadPDF, isLoading, loadingType } = useDownloadCard({
    filename: template.programName || 'template',
  });

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }}
        transition={{ type: 'spring', stiffness: 300, damping: 28 }}
        className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-md w-full max-h-[90vh] border border-gray-100 dark:border-gray-800 flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-800 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base dark:text-white truncate">{template.programName}</h3>
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ring-1 capitalize shrink-0 ${typeStyle}`}>
                  {template.type?.replace('_', ' ')}
                </span>
              </div>
              {template.issuerName && <p className="text-xs text-gray-400 mt-0.5">{template.issuerName}</p>}
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0 ml-2">
            <DownloadCardButtons
              onDownloadImage={downloadImage}
              onDownloadPDF={downloadPDF}
              isLoading={isLoading}
              loadingType={loadingType}
              labelImage={t('download_image', 'Download as Image')}
              labelPDF={t('download_pdf', 'Download as PDF')}
            />
            <div className="w-px h-5 bg-gray-200 dark:bg-gray-700 mx-1" />
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors cursor-pointer flex items-center justify-center"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>

        {/* Scrollable body */}
        <div className="overflow-y-auto flex-1 p-5 space-y-4">
          {/* Card visual */}
          <div ref={cardRef} className="rounded-2xl overflow-hidden">
            <CardVisual template={template} t={t} />
          </div>

          {/* Type-aware details */}
          {isLoyalty && (
            <div className="bg-gray-50 dark:bg-gray-800/60 rounded-2xl p-4 space-y-3">
              <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">{t('loyalty_program')}</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white dark:bg-gray-700/50 rounded-xl p-3 text-center">
                  <p className="text-[10px] uppercase tracking-widest text-gray-400 mb-1">{t('pts_purchase')}</p>
                  <p className="text-xl font-extrabold text-indigo-600 dark:text-indigo-400">{template.rules?.pointsPerPurchase ?? '—'}</p>
                </div>
                <div className="bg-white dark:bg-gray-700/50 rounded-xl p-3 text-center">
                  <p className="text-[10px] uppercase tracking-widest text-gray-400 mb-1">{t('welcome_bonus')}</p>
                  <p className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400">{template.rules?.welcomeBonus ?? '—'}</p>
                </div>
              </div>
              {template.googleClassId && (
                <InfoRow icon={CreditCard} label={t('google_class_id_label')} value={template.googleClassId} mono />
              )}
              {template.applePassTypeIdentifier && (
                <InfoRow icon={CreditCard} label={t('apple_pass_type_label')} value={template.applePassTypeIdentifier} mono />
              )}
            </div>
          )}

          {isBiz && (
            <div className="bg-gray-50 dark:bg-gray-800/60 rounded-2xl p-4 space-y-4">
              {/* Logo + name header */}
              <div className="flex items-center gap-3">
                {template.logo ? (
                  <img src={template.logo} className="w-12 h-12 rounded-xl object-contain bg-white p-1 shadow-sm border border-gray-100 dark:border-gray-700" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-gray-400" />
                  </div>
                )}
                <div>
                  <p className="font-bold text-sm dark:text-white">
                    {template.config?.firstName || template.issuerName || '—'}{' '}
                    {template.config?.lastName || ''}
                  </p>
                  {(template.config?.jobTitle || template.jobTitle) && (
                    <p className="text-xs text-gray-400">{template.config?.jobTitle || template.jobTitle}</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Meta */}
          <div className="bg-gray-50 dark:bg-gray-800/60 rounded-2xl p-4 space-y-3">
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">{t('meta')}</p>
            <InfoRow icon={Star}  label={t('created_by')} value={template.createdBy ? `${template.createdBy.firstName} ${template.createdBy.lastName}` : null} />
            <InfoRow icon={CreditCard} label={t('created')} value={template.createdAt ? moment(template.createdAt).format('MMM D, YYYY · HH:mm') : null} />
            {template.companyId?.name && (
              <InfoRow icon={Briefcase} label={t('company')} value={template.companyId.name} />
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

/* ─── Main page ───────────────────────────────────────────────────────────── */
export const TemplatesPage = ({ companyId, showCompanyCol = false }) => {
  const { t } = useTranslation();
  const { user } = useAuthStore();
  const [page, setPage]           = useState(1);
  const [search, setSearch]       = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [selected, setSelected]   = useState(null);
  const [createOpen, setCreateOpen] = useState(false);
  const debouncedSearch = useDebounce(search, 400);

  const TYPE_TABS = [
    { key: 'all',           label: 'All' },
    { key: 'loyalty',       label: 'Loyalty' },
    { key: 'business_card', label: 'Business Card' },
  ];

  const { data, isLoading } = useCardPrograms(
    { 
      companyId, 
      page, 
      limit: 10, 
      search: debouncedSearch || undefined,
      type: typeFilter === 'all' ? undefined : typeFilter,
    },
    { enabled: true }
  );

  const templates = data?.data || [];
  const total        = data?.total || 0;
  const lastPage     = data?.lastPage || 1;
  const showPoints   = typeFilter === 'all' || typeFilter === 'loyalty';

  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-950 min-h-full">
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">

        {/* Header */}
        <div className="p-6 border-b border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl">
              <Layers className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold dark:text-white">{t('templates')}</h2>
              <p className="text-xs text-gray-400">{total} {t('programs')}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            {/* Type tabs */}
            <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl">
              {TYPE_TABS.map(tab => (
                <button
                  key={tab.key}
                  onClick={() => { setTypeFilter(tab.key); setPage(1); }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    typeFilter === tab.key
                      ? 'bg-white dark:bg-gray-700 text-indigo-600 dark:text-indigo-400 shadow-sm'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  {tab.label === 'All' ? t('all') : tab.label === 'Loyalty' ? t('loyalty') : t('business_card')}
                </button>
              ))}
            </div>
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder={t('search_templates')}
                value={search}
                onChange={e => { setSearch(e.target.value); setPage(1); }}
                className="pl-9 pr-8 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white w-52 transition-all"
              />
              {search && (
                <button onClick={() => { setSearch(''); setPage(1); }} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            {/* Create button — tenant only */}
            {user?.companyId && (
              <button
                onClick={() => setCreateOpen(true)}
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-xl transition-colors shadow-sm shadow-indigo-500/20"
              >
                <Plus className="w-4 h-4" />
                {t('create_template')}
              </button>
            )}
          </div>
        </div>

        {/* Table */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
          </div>
        ) : templates.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <Layers className="w-12 h-12 mb-3 opacity-30" />
            <p className="font-medium">{t('no_templates')}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 dark:bg-gray-800/50 text-[11px] uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400 sticky top-0 z-10">
                <tr>
                  <th className="px-6 py-3">{t('program')}</th>
                  <th className="px-6 py-3">{t('type')}</th>
                  {showCompanyCol && <th className="px-6 py-3">{t('company')}</th>}
                  {showPoints && <th className="px-6 py-3">{t('points_per_purchase')}</th>}
                  {showPoints && <th className="px-6 py-3">{t('welcome_bonus')}</th>}
                  <th className="px-6 py-3">{t('created_by')}</th>
                  <th className="px-6 py-3">{t('created')}</th>
                  <th className="px-6 py-3">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {templates.map((tpl, i) => {
                  const initials  = (tpl.programName || '?').slice(0, 2).toUpperCase();
                  const gradient  = AVATAR_GRADIENTS[i % AVATAR_GRADIENTS.length];
                  const typeStyle = TYPE_STYLES[tpl.type] || TYPE_STYLES.loyalty;
                  const isLoyalty = tpl.type === 'loyalty';
                  return (
                    <tr key={tpl._id || tpl.id} className="hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center text-white text-xs font-bold shadow-sm shrink-0`}>
                            {tpl.logo
                              ? <img src={tpl.logo} className="w-full h-full object-contain rounded-xl p-0.5" referrerPolicy="no-referrer" />
                              : initials}
                          </div>
                          <div>
                            <p className="font-semibold text-sm dark:text-white">{tpl.programName}</p>
                            <p className="text-xs text-gray-400">{tpl.issuerName || '—'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold ring-1 capitalize ${typeStyle}`}>
                          {tpl.type?.replace('_', ' ')}
                        </span>
                      </td>
                      {showCompanyCol && (
                        <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                          {tpl.companyId?.name || '—'}
                        </td>
                      )}
                      {showPoints && (
                        <td className="px-6 py-4 text-sm font-medium dark:text-gray-200">
                          {isLoyalty ? (tpl.rules?.pointsPerPurchase ?? '—') : <span className="text-gray-300 dark:text-gray-600">—</span>}
                        </td>
                      )}
                      {showPoints && (
                        <td className="px-6 py-4 text-sm font-medium dark:text-gray-200">
                          {isLoyalty ? (tpl.rules?.welcomeBonus ?? '—') : <span className="text-gray-300 dark:text-gray-600">—</span>}
                        </td>
                      )}
                      <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                        {tpl.createdBy ? `${tpl.createdBy.firstName} ${tpl.createdBy.lastName}` : '—'}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-400">
                        {tpl.createdAt ? (
                          <div className="flex flex-col">
                            <span>{moment(tpl.createdAt).format('MMM D, YYYY')}</span>
                            <span className="text-[11px]">{moment(tpl.createdAt).format('HH:mm')}</span>
                          </div>
                        ) : '—'}
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => setSelected(tpl)}
                          className="inline-flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 hover:text-indigo-900 dark:hover:text-indigo-200 text-sm font-medium transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                          {t('preview')}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {total > 0 && (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-6 py-4 border-t border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/20">
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {t('showing')} <span className="font-semibold text-gray-700 dark:text-gray-300">{(page - 1) * 10 + 1}</span>–
              <span className="font-semibold text-gray-700 dark:text-gray-300">{Math.min(page * 10, total)}</span> {t('of')}{' '}
              <span className="font-semibold text-gray-700 dark:text-gray-300">{total}</span>
            </p>
            <div className="flex items-center gap-1">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800 disabled:opacity-40 transition-colors">
                <ChevronLeft className="w-4 h-4 text-gray-500 dark:text-gray-400" />
              </button>
              {[...Array(lastPage)].map((_, i) => (
                <button key={i + 1} onClick={() => setPage(i + 1)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
                    page === i + 1
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
                      : 'text-gray-500 dark:text-gray-400 hover:bg-white dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700'
                  }`}>
                  {i + 1}
                </button>
              ))}
              <button onClick={() => setPage(p => Math.min(lastPage, p + 1))} disabled={page === lastPage}
                className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800 disabled:opacity-40 transition-colors">
                <ChevronRight className="w-4 h-4 text-gray-500 dark:text-gray-400" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Create Template full-screen modal */}
      <AnimatePresence>
        {createOpen && user && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] bg-gray-50 dark:bg-gray-950 overflow-y-auto"
          >
            <div className="sticky top-0 z-10 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 px-6 py-4 flex items-center justify-between">
              <h2 className="text-lg font-bold dark:text-white">{t('create_template')}</h2>
              <button onClick={() => setCreateOpen(false)} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>
            <CreateTemplatePage user={user} onSuccess={() => setCreateOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Preview modal */}
      <AnimatePresence>
        {selected && (
          <TemplatePreviewModal template={selected} onClose={() => setSelected(null)} />
        )}
      </AnimatePresence>
    </div>
  );
};
