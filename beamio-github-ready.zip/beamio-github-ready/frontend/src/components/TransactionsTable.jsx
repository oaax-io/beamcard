import moment from 'moment';
import { ArrowDownRight, ArrowUpRight, ChevronLeft, ChevronRight, Loader2, Receipt, Search, X } from 'lucide-react';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useTransactions } from '../api/hooks/useCards';
import { useDebounce } from '../hooks/useDebounce';

const AVATAR_GRADIENTS = [
  'from-indigo-400 to-violet-500',
  'from-sky-400 to-blue-500',
  'from-emerald-400 to-teal-500',
  'from-amber-400 to-orange-500',
  'from-rose-400 to-pink-500',
];

const Pagination = ({ page, lastPage, total, limit, onPageChange, t }) => (
  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-6 py-4 border-t border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/20">
    <p className="text-xs text-gray-500 dark:text-gray-400">
      {t('showing')} <span className="font-semibold text-gray-700 dark:text-gray-300">{(page - 1) * limit + 1}</span>–
      <span className="font-semibold text-gray-700 dark:text-gray-300">{Math.min(page * limit, total)}</span> {t('of')}{' '}
      <span className="font-semibold text-gray-700 dark:text-gray-300">{total}</span>
    </p>
    <div className="flex items-center gap-1">
      <button
        onClick={() => onPageChange(p => Math.max(1, p - 1))}
        disabled={page === 1}
        className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800 disabled:opacity-40 transition-colors"
      >
        <ChevronLeft className="w-4 h-4 text-gray-500 dark:text-gray-400" />
      </button>
      {[...Array(lastPage)].map((_, i) => (
        <button
          key={i + 1}
          onClick={() => onPageChange(() => i + 1)}
          className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
            page === i + 1
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
              : 'text-gray-500 dark:text-gray-400 hover:bg-white dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700'
          }`}
        >
          {i + 1}
        </button>
      ))}
      <button
        onClick={() => onPageChange(p => Math.min(lastPage, p + 1))}
        disabled={page === lastPage}
        className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800 disabled:opacity-40 transition-colors"
      >
        <ChevronRight className="w-4 h-4 text-gray-500 dark:text-gray-400" />
      </button>
    </div>
  </div>
);

export const TransactionsTable = ({ companyId, showCompanyCol = false, limit = 10 }) => {
  const { t } = useTranslation();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 400);

  const params = { page, limit, search: debouncedSearch || undefined, ...(companyId ? { companyId } : {}) };
  const { data, isLoading } = useTransactions(params);

  const transactions = data?.data || [];
  const total = data?.total ?? 0;
  const lastPage = data?.lastPage ?? 1;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-6 py-5 border-b border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-white to-gray-50 dark:from-gray-900 dark:to-gray-900">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl">
            <Receipt className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <div>
            <h2 className="text-base font-bold dark:text-white">{t('transactions')}</h2>
            <p className="text-xs text-gray-400 dark:text-gray-500">{total} {t('transactions')}</p>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
          <input
            type="text"
            placeholder={t('search_users')}
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="pl-8 pr-7 py-1.5 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white w-48 transition-all"
          />
          {search && (
            <button onClick={() => { setSearch(''); setPage(1); }} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto max-h-[50vh] overflow-y-auto custom-scrollbar border border-gray-100 dark:border-gray-800 rounded-xl">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-50/90 dark:bg-gray-800/90 backdrop-blur-sm border-b border-gray-100 dark:border-gray-800 sticky top-0 z-10">
              {[
                t('date'),
                t('customer'),
                ...(showCompanyCol ? [t('company')] : []),
                t('program'),
                t('done_by'),
                t('type'),
                t('amount'),
                t('before'),
                t('after'),
                t('note'),
              ].map(h => (
                <th key={h} className="px-6 py-3.5 text-[11px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 whitespace-nowrap bg-inherit">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {transactions.length === 0 ? (
              <tr>
                <td colSpan={10 + (showCompanyCol ? 1 : 0)} className="px-6 py-16 text-center">
                  <Receipt className="w-8 h-8 mx-auto mb-2 text-gray-300 dark:text-gray-700" />
                  <p className="text-sm text-gray-400">{t('no_data')}</p>
                </td>
              </tr>
            ) : transactions.map((tx, idx) => {
              const card = tx.cardId;
              const user = card?.userId;
              const program = card?.programId;
              const company = tx.companyId;

              const userName = user?.firstName
                ? `${user.firstName} ${user.lastName}`
                : (tx.customerName || '—');
              const initials = userName !== '—'
                ? userName.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
                : '?';
              const gradient = AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length];

              return (
                <tr key={tx._id || tx.id} className="border-b border-gray-50 dark:border-gray-800/60 hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors duration-150">

                  {/* Date */}
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap">
                    <div>{moment(tx.date || tx.createdAt).format('MMM D, YYYY')}</div>
                    <div className="text-[11px] text-gray-400 dark:text-gray-600">
                      {moment(tx.date || tx.createdAt).format('HH:mm')}
                    </div>
                  </td>

                  {/* Customer */}
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center shrink-0`}>
                        <span className="text-[10px] font-bold text-white">{initials}</span>
                      </div>
                      <div>
                        <p className="font-semibold text-sm text-gray-800 dark:text-gray-100 whitespace-nowrap">{userName}</p>
                        <p className="text-[11px] text-gray-400">{user?.email || '—'}</p>
                      </div>
                    </div>
                  </td>

                  {/* Company (admin only) */}
                  {showCompanyCol && (
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 shrink-0" />
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300 whitespace-nowrap">
                          {company?.name || '—'}
                        </span>
                      </div>
                    </td>
                  )}

                  {/* Program */}
                  <td className="px-6 py-4">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300 whitespace-nowrap">
                      {program?.programName || '—'}
                    </span>
                  </td>

                  {/* Done By */}
                  <td className="px-6 py-4">
                    {tx.performedBy ? (
                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300 whitespace-nowrap">
                          {tx.performedBy.firstName} {tx.performedBy.lastName}
                        </p>
                        <p className="text-[11px] text-gray-400 capitalize">{tx.performedBy.role?.toLowerCase() || '—'}</p>
                      </div>
                    ) : (
                      <span className="text-gray-400 text-sm">—</span>
                    )}
                  </td>

                  {/* Tx Type */}
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                      tx.type === 'award'
                        ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400 ring-1 ring-emerald-200 dark:ring-emerald-800'
                        : 'bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400 ring-1 ring-red-200 dark:ring-red-800'
                    }`}>
                      {tx.type === 'award' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                      {t(tx.type)}
                    </span>
                  </td>

                  {/* Amount */}
                  <td className={`px-6 py-4 font-bold text-sm ${tx.type === 'award' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                    {tx.type === 'award' ? '+' : '-'}{tx.amount}
                  </td>

                  {/* Balance Before */}
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-500 dark:text-gray-400 font-medium">
                      {tx.balanceBefore ?? '—'} <span className="text-[11px] text-gray-400">pts</span>
                    </span>
                  </td>

                  {/* Balance After */}
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 ring-1 ring-indigo-200 dark:ring-indigo-800">
                      {tx.balanceAfter ?? '—'} pts
                    </span>
                  </td>

                  {/* Note */}
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 max-w-[160px] truncate">
                    {tx.note || '—'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {total > 0 && (
        <Pagination page={page} lastPage={lastPage} total={total} limit={limit} onPageChange={setPage} t={t} />
      )}
    </div>
  );
};
