import { useFormik } from 'formik';
import { AlertCircle, CreditCard, Eye, EyeOff, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import React from 'react';
import toast from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import * as Yup from 'yup';
import { useLogin } from '../api/hooks/useAuth';
import { ROLES } from '../db';
import { useAuthStore } from '../store/authStore';

export const LoginPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const loginToStore = useAuthStore((state) => state.login);
  const [showPassword, setShowPassword] = React.useState(false);

  const loginMutation = useLogin(({ user, accessToken }) => {
    toast.success(t('welcome_back', { name: user.name }));
    loginToStore(user, accessToken);

    // Redirect logic moved here
    const role = user.role;
    if (role === ROLES.SUPERADMIN) navigate('/admin');
    else if (role === ROLES.TENANT || role === ROLES.ADMIN) navigate('/tenant');
    else if (role === ROLES.CUSTOMER) navigate('/customer');
    else navigate('/');
  });

  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema: Yup.object({
      email: Yup.string().email(t('invalid_email')).required(t('required')),
      password: Yup.string().required(t('required')),
    }),
    onSubmit: (values) => {
      loginMutation.mutate(values);
    },
  });

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 bg-gray-50 dark:bg-gray-950 transition-colors duration-300">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white dark:bg-gray-900 rounded-3xl shadow-2xl p-8 border border-gray-100 dark:border-gray-800"
      >
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl mb-4">
            <CreditCard className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{t('login')}</h2>
          <p className="text-gray-500 dark:text-gray-400 mt-2">{t('login_access')}</p>
        </div>

        <form onSubmit={formik.handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('email')}</label>
            <input
              name="email"
              type="email"
              className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border ${formik.touched.email && formik.errors.email ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white`}
              {...formik.getFieldProps('email')}
              placeholder="admin@beamcard.com"
            />
            {formik.touched.email && formik.errors.email ? (
              <div className="text-red-500 text-xs mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> {formik.errors.email}
              </div>
            ) : null}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('password')}</label>
            <div className="relative">
              <input
                name="password"
                type={showPassword ? 'text' : 'password'}
                className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border ${formik.touched.password && formik.errors.password ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white pr-12`}
                {...formik.getFieldProps('password')}
                placeholder="••••••••"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            {formik.touched.password && formik.errors.password ? (
              <div className="text-red-500 text-xs mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> {formik.errors.password}
              </div>
            ) : null}
          </div>
          <button
            type="submit"
            disabled={loginMutation.isPending}
            className="w-full py-4 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/20 transition-all transform hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-2"
          >
            {loginMutation.isPending && <Loader2 className="w-5 h-5 animate-spin" />}
            {t('login')}
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-gray-100 dark:border-gray-800 text-center">
          <p className="text-xs text-gray-400 dark:text-gray-500 uppercase tracking-widest font-semibold mb-4">{t('demo_accounts')}</p>
          <div className="grid grid-cols-1 gap-2 text-xs text-gray-500 dark:text-gray-400">
            <p>{t('superadmin')}: admin@beamcard.com / admin</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
