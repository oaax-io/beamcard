import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { toast } from 'react-hot-toast';
import { Loader2, Save } from 'lucide-react';
import { usePlanConfig, useUpdatePlanConfig } from '../api/hooks/useSubscription';

export const PricingConfig = () => {
    const { t } = useTranslation();
    const { data: config, isLoading } = usePlanConfig();
    const updateConfig = useUpdatePlanConfig();

    const [formData, setFormData] = useState({
        currency: 'EUR',
        proPrice: '',
        teamPrice: '',
    });

    useEffect(() => {
        if (config) {
            setFormData({
                currency: config.currency?.toUpperCase() || 'EUR',
                proPrice: config.plans?.proPrice || '',
                teamPrice: config.plans?.teamPrice || '',
            });
        }
    }, [config]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await updateConfig.mutateAsync({
                currency: formData.currency.toLowerCase(),
                plans: {
                    proPrice: Number(formData.proPrice),
                    proName: 'Pro Plan',
                    teamPrice: Number(formData.teamPrice),
                    teamName: 'Team Plan',
                }
            });
            toast.success(t('config_saved') || 'Pricing config saved successfully');
        } catch (error) {
            toast.error(t('config_error') || 'Error saving config');
        }
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center p-12 h-64">
                <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
            </div>
        );
    }

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                {t('pricing_config_title')}
            </h1>
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            {t('currency')}
                        </label>
                        <select
                            name="currency"
                            value={formData.currency}
                            onChange={handleChange}
                            className="w-full sm:w-64 px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="EUR">EUR (€)</option>
                            <option value="USD">USD ($)</option>
                            <option value="GBP">GBP (£)</option>
                            <option value="CHF">CHF</option>
                        </select>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* Pro Plan */}
                        <div className="space-y-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <h3 className="text-lg font-bold text-indigo-600 dark:text-indigo-400">Pro Plan</h3>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                    {t('price_monthly')}
                                </label>
                                <input
                                    type="number"
                                    step="0.01"
                                    name="proPrice"
                                    value={formData.proPrice}
                                    onChange={handleChange}
                                    required
                                    className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500"
                                />
                            </div>
                        </div>

                        {/* Team Plan */}
                        <div className="space-y-4 p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <h3 className="text-lg font-bold text-purple-600 dark:text-purple-400">Team Plan</h3>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                                    {t('price_monthly')}
                                </label>
                                <input
                                    type="number"
                                    step="0.01"
                                    name="teamPrice"
                                    value={formData.teamPrice}
                                    onChange={handleChange}
                                    required
                                    className="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500"
                                />
                            </div>
                        </div>
                    </div>

                    <div className="pt-4 flex items-center justify-end">
                        <button
                            type="submit"
                            disabled={updateConfig.isPending}
                            className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 flex items-center gap-2 transition-colors disabled:opacity-50"
                        >
                            {updateConfig.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                            {updateConfig.isPending ? t('saving') : t('save_config')}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
