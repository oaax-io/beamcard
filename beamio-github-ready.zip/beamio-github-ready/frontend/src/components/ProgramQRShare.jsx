import { Copy } from 'lucide-react';
import toast from 'react-hot-toast';
import { useTranslation } from 'react-i18next';

export const getProgramEnrollUrl = (programId) =>
  `${window.location.origin}/enroll/${programId}`;

export const ProgramQRShare = ({ programId, size = 200 }) => {
  const { t } = useTranslation();
  const url = getProgramEnrollUrl(programId);

  return (
    <div className="flex flex-col items-center p-6 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl shadow-sm space-y-4">
      <p className="text-sm font-bold uppercase tracking-widest text-gray-400">{t('scan_to_add')}</p>
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
        <img
          src={`https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(url)}`}
          alt="QR Code to add Google Wallet card"
          style={{ width: size, height: size }}
          className="object-contain"
        />
      </div>
      <p className="text-xs text-gray-500 text-center max-w-[200px]">
        {t('scan_camera_desc')}
      </p>
      <div className="flex w-full items-center gap-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl p-2">
        <input
          type="text"
          readOnly
          value={url}
          className="flex-1 bg-transparent px-3 text-sm outline-none dark:text-white truncate font-mono"
        />
        <button
          type="button"
          onClick={() => { navigator.clipboard.writeText(url); toast.success(t('link_copied')); }}
          className="px-4 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors flex items-center gap-1.5 text-sm shrink-0"
        >
          <Copy className="w-3.5 h-3.5" />
          {t('copy')}
        </button>
      </div>
    </div>
  );
};
