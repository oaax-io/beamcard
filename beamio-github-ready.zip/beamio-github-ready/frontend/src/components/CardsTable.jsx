import {
  ArrowDownRight,
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  Eye,
  Loader2,
  Plus,
  User,
} from 'lucide-react';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAdminAllCards, useCards } from '../api/hooks/useCards';

const TYPE_FILTER_OPTIONS = [
  { key: 'all', label: 'all' },
  { key: 'loyalty', label: 'loyalty' },
  { key: 'business_card', label: 'business_card' },
];

const AVATAR_GRADIENTS = [
  'from-indigo-400 to-violet-500',
  'from-sky-400 to-blue-500',
  'from-emerald-400 to-teal-500',
  'from-amber-400 to-orange-500',
  'from-rose-400 to-pink-500',
];

const TYPE_CONFIG = {
  loyalty:       { cls: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300 ring-1 ring-indigo-200 dark:ring-indigo-800' },
  business_card: { cls: 'bg-violet-50 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300 ring-1 ring-violet-200 dark:ring-violet-800' },
  flight:        { cls: 'bg-sky-50 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300 ring-1 ring-sky-200 dark:ring-sky-800' },
  offer:         { cls: 'bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300 ring-1 ring-amber-200 dark:ring-amber-800' },
  _unknown:      { cls: 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400 ring-1 ring-gray-200 dark:ring-gray-700' },
};

const Pagination = ({ page, lastPage, total, limit, onPageChange }) => {
  const { t } = useTranslation();
  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-6 py-4 border-t border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/20">
      <p className="text-xs text-gray-500 dark:text-gray-400">
        {t('showing_text')} <span className="font-semibold text-gray-700 dark:text-gray-300">{(page - 1) * limit + 1}</span>–
        <span className="font-semibold text-gray-700 dark:text-gray-300">{Math.min(page * limit, total)}</span> {t('of')}{' '}
        <span className="font-semibold text-gray-700 dark:text-gray-300">{total}</span>
      </p>
      <div className="flex items-center gap-1">
        <button
          onClick={() => onPageChange(p => Math.max(1, p - 1))}
          disabled={page === 1}
          className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800 disabled:opacity-40 transition-colors"
        >
          <ChevronLeft className="w-4 h-4 text-gray-500 dark:text-gray-400" />
        </button>
        {[...Array(lastPage)].map((_, i) => (
          <button
            key={i + 1}
            onClick={() => onPageChange(() => i + 1)}
            className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
              page === i + 1
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
                : 'text-gray-500 dark:text-gray-400 hover:bg-white dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700'
            }`}
          >
            {i + 1}
          </button>
        ))}
        <button
          onClick={() => onPageChange(p => Math.min(lastPage, p + 1))}
          disabled={page === lastPage}
          className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800 disabled:opacity-40 transition-colors"
        >
          <ChevronRight className="w-4 h-4 text-gray-500 dark:text-gray-400" />
        </button>
      </div>
    </div>
  );
};

/**
 * Shared cards table used by SuperAdmin (/admin/cards) and Tenant (/tenant/cards-list).
 *
 * Props:
 *  - companyId        : string | undefined  — if set, filters cards by company (Tenant view)
 *  - showCompanyCol   : boolean             — show/hide the Company column (SuperAdmin only)
 *  - onViewCard       : (card) => void      — optional row action handler
 *  - onAddCard        : () => void          — optional header button handler
 *  - headerTitle      : string              — override header title
 *  - limit            : number              — page size (default 10)
 */
export const CardsTable = ({
  companyId,
  showCompanyCol = false,
  onViewCard,
  onAddCard,
  headerTitle,
  limit = 10,
}) => {
  const { t } = useTranslation();
  const [page, setPage] = useState(1);
  const [typeFilter, setTypeFilter] = useState('all');

  const isAdmin = !companyId;

  const adminQuery = useAdminAllCards(
    { page, limit, type: typeFilter === 'all' ? undefined : typeFilter },
    { enabled: isAdmin }
  );
  const tenantQuery = useCards(
    { companyId, page, limit, type: typeFilter === 'all' ? undefined : typeFilter },
    { enabled: !isAdmin }
  );

  const query = isAdmin ? adminQuery : tenantQuery;
  const cards = query.data?.data || [];
  const total = query.data?.total || 0;
  const lastPage = query.data?.lastPage || 1;

  const columns = [
    t('customer'),
    t('email'),
    ...(showCompanyCol ? [t('company')] : []),
    t('type'),
    t('points_per_purchase'),
    t('balance'),
    t('status'),
    ...(onViewCard ? [t('actions')] : []),
  ];

  if (query.isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-6 py-5 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center bg-gradient-to-r from-white to-gray-50 dark:from-gray-900 dark:to-gray-900">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl">
            <CreditCard className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <div>
            <h2 className="text-base font-bold dark:text-white">{headerTitle || t('cards')}</h2>
            <p className="text-xs text-gray-400 dark:text-gray-500">{total} {t('cards')}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          {/* Type filter chips */}
          <div className="flex items-center gap-1.5 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl">
            {TYPE_FILTER_OPTIONS.map(opt => (
              <button
                key={opt.key}
                onClick={() => { setTypeFilter(opt.key); setPage(1); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  typeFilter === opt.key
                    ? 'bg-white dark:bg-gray-700 text-indigo-600 dark:text-indigo-400 shadow-sm'
                    : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                }`}
              >
                {t(opt.label)}
              </button>
            ))}
          </div>
          {onAddCard && (
            <button
              onClick={onAddCard}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 px-3 py-1.5 rounded-lg transition-colors shadow-sm shadow-indigo-500/20"
            >
              <Plus className="w-3.5 h-3.5" />
              {t('add_customer')}
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto max-h-[50vh] overflow-y-auto custom-scrollbar border border-gray-100 dark:border-gray-800 rounded-xl">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-50/90 dark:bg-gray-800/90 backdrop-blur-sm border-b border-gray-100 dark:border-gray-800 sticky top-0 z-10">
              {columns.map(h => (
                <th key={h} className="px-6 py-3.5 text-[11px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 whitespace-nowrap bg-inherit">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {cards.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="px-6 py-16 text-center">
                  <CreditCard className="w-8 h-8 mx-auto mb-2 text-gray-300 dark:text-gray-700" />
                  <p className="text-sm text-gray-400">{t('no_cards') || 'No cards found'}</p>
                </td>
              </tr>
            ) : cards.map((card, idx) => {
              const userName = card.userId?.firstName
                ? `${card.userId.firstName} ${card.userId.lastName}`
                : (card.name || t('unknown'));
              const userEmail = card.userId?.email || card.email || '—';
              const initials = userName.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
              const gradient = AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length];
              const cardType = card.programId?.type;
              const typeConf = TYPE_CONFIG[cardType] || TYPE_CONFIG._unknown;

              return (
                <tr
                  key={card._id || card.id}
                  className="group border-b border-gray-50 dark:border-gray-800/60 hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors duration-150"
                >
                  {/* Customer */}
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center shadow-sm shrink-0`}>
                        <span className="text-[11px] font-bold text-white">{initials}</span>
                      </div>
                      <span className="font-semibold text-sm text-gray-800 dark:text-gray-100">{userName}</span>
                    </div>
                  </td>

                  {/* Email */}
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{userEmail}</td>

                  {/* Company (optional) */}
                  {showCompanyCol && (
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 dark:bg-indigo-500 shrink-0" />
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          {card.companyId?.name || card.companyName || '—'}
                        </span>
                      </div>
                    </td>
                  )}

                  {/* Type */}
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-[11px] font-bold capitalize ${typeConf.cls}`}>
                      {cardType ? t(cardType) : '—'}
                    </span>
                  </td>

                  {/* Pts Per Purchase */}
                  <td className="px-6 py-4 text-sm font-medium dark:text-gray-200">
                    {cardType === 'loyalty' ? (card.programId?.rules?.pointsPerPurchase ?? '—') : <span className="text-gray-300 dark:text-gray-600">—</span>}
                  </td>

                  {/* Balance */}
                  <td className="px-6 py-4">
                    {cardType === 'business_card' ? (
                      <span className="text-gray-400 dark:text-gray-600 text-sm">—</span>
                    ) : (
                      <div className="flex items-baseline gap-1">
                        <span className="text-base font-bold text-gray-900 dark:text-white">{card.currentBalance}</span>
                        <span className="text-xs text-gray-400 dark:text-gray-500">{t('points')}</span>
                      </div>
                    )}
                  </td>

                  {/* Status */}
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold uppercase tracking-wide ${
                      card.status === 'active'
                        ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400 ring-1 ring-emerald-200 dark:ring-emerald-800'
                        : 'bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400 ring-1 ring-red-200 dark:ring-red-800'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${card.status === 'active' ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
                      {t(card.status || 'active')}
                    </span>
                  </td>

                  {/* Actions (optional) */}
                  {onViewCard && (
                    <td className="px-6 py-4">
                      <button
                        onClick={() => onViewCard(card)}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        {t('view')}
                      </button>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {total > 0 && (
        <Pagination page={page} lastPage={lastPage} total={total} limit={limit} onPageChange={setPage} />
      )}
    </div>
  );
};
