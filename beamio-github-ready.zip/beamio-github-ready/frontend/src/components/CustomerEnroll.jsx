import { Loader2, AlertCircle } from 'lucide-react';
import { useParams } from 'react-router-dom';
import { useProgramById } from '../api/hooks/usePrograms';
import { CustomerEnrollLoyalty } from './CustomerEnrollLoyalty';
import { CustomerEnrollBusiness } from './CustomerEnrollBusiness';

export const CustomerEnroll = () => {
    const { programId } = useParams();
    const { data: program, isLoading: loading, error: programError } = useProgramById(programId);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950">
                <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
            </div>
        );
    }

    if (programError || !program) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950">
                <div className="bg-white dark:bg-gray-900 p-8 rounded-3xl shadow-xl text-center max-w-sm w-full mx-4 border border-gray-100 dark:border-gray-800">
                    <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                    <h2 className="text-xl font-bold dark:text-white mb-2">Oops!</h2>
                    <p className="text-gray-500 dark:text-gray-400">{(programError && 'Failed to load program details.') || 'Program not found.'}</p>
                </div>
            </div>
        );
    }

    if (program.type === 'business_card') {
        return <CustomerEnrollBusiness program={program} programId={programId} />;
    }

    return <CustomerEnrollLoyalty program={program} programId={programId} />;
};
