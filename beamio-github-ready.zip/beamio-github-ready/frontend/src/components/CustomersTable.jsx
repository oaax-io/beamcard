import {
  ArrowDownRight,
  ArrowUpRight,
  Briefcase,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  Edit2,
  Eye,
  Globe,
  Linkedin,
  Loader2,
  Mail,
  Phone,
  Plus,
  Search,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import { useAwardPoints, useDeleteCustomer, useRedeemPoints, useUniqueCustomers, useUpdateCustomer } from '../api/hooks/useCards';
import { useDebounce } from '../hooks/useDebounce';
import toast from 'react-hot-toast';

const AVATAR_GRADIENTS = [
  'from-indigo-400 to-violet-500',
  'from-sky-400 to-blue-500',
  'from-emerald-400 to-teal-500',
  'from-amber-400 to-orange-500',
  'from-rose-400 to-pink-500',
];

const Pagination = ({ page, lastPage, total, onPageChange }) => (
  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 px-6 py-4 border-t border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/20">
    <p className="text-xs text-gray-500 dark:text-gray-400">
      Showing <span className="font-semibold text-gray-700 dark:text-gray-300">{(page - 1) * 10 + 1}</span>–
      <span className="font-semibold text-gray-700 dark:text-gray-300">{Math.min(page * 10, total)}</span> of{' '}
      <span className="font-semibold text-gray-700 dark:text-gray-300">{total}</span>
    </p>
    <div className="flex items-center gap-1">
      <button
        onClick={() => onPageChange(p => Math.max(1, p - 1))}
        disabled={page === 1}
        className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800 disabled:opacity-40 transition-colors"
      >
        <ChevronLeft className="w-4 h-4 text-gray-500 dark:text-gray-400" />
      </button>
      {[...Array(lastPage)].map((_, i) => (
        <button
          key={i + 1}
          onClick={() => onPageChange(() => i + 1)}
          className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
            page === i + 1
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
              : 'text-gray-500 dark:text-gray-400 hover:bg-white dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700'
          }`}
        >
          {i + 1}
        </button>
      ))}
      <button
        onClick={() => onPageChange(p => Math.min(lastPage, p + 1))}
        disabled={page === lastPage}
        className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-800 disabled:opacity-40 transition-colors"
      >
        <ChevronRight className="w-4 h-4 text-gray-500 dark:text-gray-400" />
      </button>
    </div>
  </div>
);


const getCardType = (card) => card.type || card.programId?.type || 'loyalty';

const CardItem = ({ card, onAward, onRedeem, t }) => {
  const prog      = card.programId;
  const bgColor   = prog?.backgroundColor || '#4f46e5';
  const heroImage = prog?.heroImage;
  const logo      = prog?.logo;
  const cardType  = getCardType(card);
  const isLoyalty = cardType !== 'business_card';
  const isBiz     = cardType === 'business_card';
  const status    = card.status || 'active';

  return (
    <div className="space-y-4">
      {/* Card visual */}
      <div
        className="rounded-2xl shadow-xl min-h-[200px] flex flex-col justify-between relative overflow-hidden w-full"
        style={{ backgroundColor: bgColor, color: '#ffffff' }}
      >
        <div className="absolute top-0 left-0 w-full h-20 pointer-events-none">
          {heroImage ? (
            <>
              <img src={heroImage} alt="cover" className="w-full h-full object-cover opacity-90" />
              <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-transparent" />
            </>
          ) : <div className="w-full h-full bg-black/5" />}
        </div>
        <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl pointer-events-none" />
        <div className="flex justify-between items-start relative z-10 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/90 backdrop-blur-md rounded-xl flex items-center justify-center overflow-hidden shadow-sm shrink-0">
              {logo ? <img src={logo} className="w-full h-full object-contain p-1" referrerPolicy="no-referrer" /> : <CreditCard className="w-5 h-5 text-gray-500" />}
            </div>
            <div>
              {prog?.issuerName && (
                <p className="text-[10px] font-bold uppercase tracking-widest opacity-80 drop-shadow-md"
                   style={{ color: heroImage ? '#fff' : '#ffffff' }}>{prog.issuerName}</p>
              )}
              <p className="text-sm font-bold drop-shadow-md" style={{ color: heroImage ? '#fff' : '#ffffff' }}>
                {prog?.programName || t(card.type || 'loyalty')}
              </p>
            </div>
          </div>
          <span className={`text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full ${
            status === 'active' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'
          }`}>{status}</span>
        </div>
        {isLoyalty && (
          <div className="relative z-10 px-5 py-3">
            <p className="text-[10px] uppercase tracking-wider font-semibold opacity-70 mb-1" style={{ color: '#ffffff' }}>{t('balance')}</p>
            <h2 className="text-4xl font-extrabold tracking-tight" style={{ color: '#ffffff' }}>
              {card.currentBalance ?? 0} <span className="text-lg font-normal opacity-70">{t('points')}</span>
            </h2>
          </div>
        )}
        {isBiz && (
          <div className="relative z-10 px-5 py-3 space-y-0.5">
            {card.jobTitle && <p className="text-sm font-semibold opacity-90" style={{ color: '#ffffff' }}>{card.jobTitle}</p>}
            {card.website  && <p className="text-[11px] opacity-60 font-mono" style={{ color: '#ffffff' }}>{card.website}</p>}
          </div>
        )}
        <div className="flex justify-between items-end relative z-10 px-5 pb-5">
          <div>
            <p className="text-[8px] uppercase tracking-widest opacity-40 mb-0.5" style={{ color: '#ffffff' }}>Card ID</p>
            <p className="text-[10px] font-mono opacity-60" style={{ color: '#ffffff' }}>{String(card._id || card.id).slice(-12)}</p>
          </div>
          <div className="px-3 py-1.5 bg-white/10 border border-white/20 backdrop-blur-md rounded-full text-[10px] font-bold uppercase tracking-widest" style={{ color: '#ffffff' }}>
            {t(cardType)}
          </div>
        </div>
      </div>

      {/* Details panel */}
      {isLoyalty && (
        <div className="bg-gray-50 dark:bg-gray-800/60 rounded-2xl p-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {prog?.rules?.pointsPerPurchase != null && (
              <div className="bg-white dark:bg-gray-700/50 rounded-xl p-3 text-center">
                <p className="text-[10px] uppercase tracking-widest text-gray-400 mb-1">{t('points_per_purchase')}</p>
                <p className="text-xl font-extrabold text-indigo-600 dark:text-indigo-400">{prog.rules.pointsPerPurchase}</p>
              </div>
            )}
            {prog?.rules?.welcomeBonus != null && (
              <div className="bg-white dark:bg-gray-700/50 rounded-xl p-3 text-center">
                <p className="text-[10px] uppercase tracking-widest text-gray-400 mb-1">Welcome Bonus</p>
                <p className="text-xl font-extrabold text-emerald-600 dark:text-emerald-400">{prog.rules.welcomeBonus}</p>
              </div>
            )}
          </div>
          {card.walletIds?.jwtLink && (
            <div>
              <p className="text-[10px] uppercase tracking-widest text-gray-400 mb-1">Google Wallet</p>
              <a href={card.walletIds.jwtLink} target="_blank" rel="noreferrer"
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-medium">Add to Wallet ↗</a>
            </div>
          )}
        </div>
      )}
      {isBiz && (
        <div className="bg-gray-50 dark:bg-gray-800/60 rounded-2xl p-4 space-y-3">
          <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Contact</p>
          {card.jobTitle && (
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-gray-200 dark:bg-gray-700 rounded-lg"><Briefcase className="w-3.5 h-3.5 text-gray-500" /></div>
              <div><p className="text-[10px] text-gray-400">Job Title</p><p className="text-sm font-semibold dark:text-white">{card.jobTitle}</p></div>
            </div>
          )}
          {card.website && (
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-gray-200 dark:bg-gray-700 rounded-lg"><Globe className="w-3.5 h-3.5 text-gray-500" /></div>
              <div><p className="text-[10px] text-gray-400">Website</p>
                <a href={card.website} target="_blank" rel="noreferrer" className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:underline">{card.website}</a>
              </div>
            </div>
          )}
          {card.linkedin && (
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-gray-200 dark:bg-gray-700 rounded-lg"><Linkedin className="w-3.5 h-3.5 text-gray-500" /></div>
              <div><p className="text-[10px] text-gray-400">LinkedIn</p>
                <a href={card.linkedin} target="_blank" rel="noreferrer" className="text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:underline truncate block max-w-[220px]">{card.linkedin}</a>
              </div>
            </div>
          )}
        </div>
      )}
      {isLoyalty && (
        <div className="flex gap-3">
          <button onClick={() => onAward(card)}
            className="flex-1 py-2.5 px-4 bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 font-semibold rounded-xl hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors flex items-center justify-center gap-2 text-sm">
            <ArrowUpRight className="w-4 h-4" />{t('award')}
          </button>
          <button onClick={() => onRedeem(card)}
            className="flex-1 py-2.5 px-4 bg-red-50 text-red-700 dark:bg-red-900/30 dark:text-red-400 font-semibold rounded-xl hover:bg-red-100 dark:hover:bg-red-900/50 transition-colors flex items-center justify-center gap-2 text-sm">
            <ArrowDownRight className="w-4 h-4" />{t('redeem')}
          </button>
        </div>
      )}
    </div>
  );
};

const CustomerDetailModal = ({ customer, onClose, onAward, onRedeem }) => {
  const { t } = useTranslation();
  const allCards = customer?.cards || [];
  const hasLoyaltyCards  = allCards.some(c => getCardType(c) !== 'business_card');
  const hasBusinessCards = allCards.some(c => getCardType(c) === 'business_card');
  const [activeType, setActiveType] = useState(hasLoyaltyCards ? 'loyalty' : 'business_card');

  if (!customer) return null;

  const filteredCards = activeType === 'loyalty'
    ? allCards.filter(c => getCardType(c) !== 'business_card')
    : allCards.filter(c => getCardType(c) === 'business_card');

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-lg w-full border border-gray-100 dark:border-gray-800 flex flex-col max-h-[90vh] overflow-hidden"
      >
        {/* Header */}
        <div className="flex justify-between items-start px-6 py-5 border-b border-gray-100 dark:border-gray-800 shrink-0">
          <div>
            <h2 className="text-lg font-bold dark:text-white">
              {`${customer.firstName || ''} ${customer.lastName || ''}`.trim() || '—'}
            </h2>
            <div className="flex items-center gap-2 mt-0.5 flex-wrap">
              {customer.email && customer.email !== '—' && (
                <span className="text-xs text-gray-400 flex items-center gap-1"><Mail className="w-3 h-3" />{customer.email}</span>
              )}
              {customer.phone && customer.phone !== '—' && (
                <span className="text-xs text-gray-400 flex items-center gap-1"><Phone className="w-3 h-3" />{customer.phone}</span>
              )}
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors shrink-0">
            <X className="w-5 h-5 dark:text-gray-400" />
          </button>
        </div>

        {/* Type tabs */}
        <div className="flex gap-1 px-6 pt-4 pb-2 shrink-0">
          {hasLoyaltyCards && (
            <button
              onClick={() => setActiveType('loyalty')}
              className={`px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeType === 'loyalty'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              Loyalty
            </button>
          )}
          {hasBusinessCards && (
            <button
              onClick={() => setActiveType('business_card')}
              className={`px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                activeType === 'business_card'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              Business Card
            </button>
          )}
        </div>

        {/* Scrollable body — all cards of selected type, vertical scroll */}
        <div className="overflow-y-auto flex-1 px-6 pb-6 space-y-6">
          {filteredCards.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-8">No cards of this type.</p>
          ) : filteredCards.map(card => (
            <CardItem key={card._id || card.id} card={card} onAward={onAward} onRedeem={onRedeem} t={t} />
          ))}
        </div>
      </motion.div>
    </div>
  );
};

const EditCustomerModal = ({ customer, onClose }) => {
  const { t } = useTranslation();
  const updateMutation = useUpdateCustomer();
  const userId = customer.userId || customer.cards[0]?.userId?._id || customer.cards[0]?.userId;

  const [form, setForm] = useState({
    firstName: customer.firstName === '—' ? '' : (customer.firstName || ''),
    lastName: customer.lastName === '—' ? '' : (customer.lastName || ''),
    email: customer.email === '—' ? '' : customer.email,
    phone: customer.phone === '—' ? '' : customer.phone,
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    updateMutation.mutate({ userId, data: form }, {
      onSuccess: () => { toast.success(t('user_updated')); onClose(); },
      onError: () => toast.error(t('user_update_fail')),
    });
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-md w-full p-8 border border-gray-100 dark:border-gray-800"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold dark:text-white">{t('edit_user')}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('first_name')}</label>
              <input value={form.firstName} onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))} required
                className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('last_name')}</label>
              <input value={form.lastName} onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))} required
                className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('email')}</label>
            <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('phone')}</label>
            <PhoneInput international defaultCountry="CH"
              value={form.phone} onChange={val => setForm(f => ({ ...f, phone: val || '' }))}
              className="phone-input-container" />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 py-3 border border-gray-300 dark:border-gray-700 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">{t('cancel')}</button>
            <button type="submit" disabled={updateMutation.isPending}
              className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2">
              {updateMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
              {t('save')}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

const DeleteConfirmModal = ({ customer, onClose }) => {
  const { t } = useTranslation();
  const deleteMutation = useDeleteCustomer();
  const userId = customer.userId || customer.cards[0]?.userId?._id || customer.cards[0]?.userId;
  const cardIds = customer.cards.map(c => c._id || c.id);

  const handleConfirm = () => {
    deleteMutation.mutate({ cardIds, userId }, {
      onSuccess: () => { toast.success(t('user_deleted')); onClose(); },
      onError: () => toast.error(t('user_delete_fail')),
    });
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-sm w-full p-8 border border-gray-100 dark:border-gray-800"
      >
        <div className="flex items-center gap-4 mb-6">
          <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-2xl shrink-0">
            <Trash2 className="w-6 h-6 text-red-600 dark:text-red-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold dark:text-white">{t('confirm_delete')}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{`${customer.firstName || ''} ${customer.lastName || ''}`.trim() || customer.email}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <button onClick={onClose} className="flex-1 py-3 border border-gray-300 dark:border-gray-700 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors font-medium">{t('cancel')}</button>
          <button onClick={handleConfirm} disabled={deleteMutation.isPending}
            className="flex-1 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-500/20 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2">
            {deleteMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            {t('delete')}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

const AwardRedeemModal = ({ card, type, onClose }) => {
  const { t } = useTranslation();
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const awardMutation = useAwardPoints();
  const redeemMutation = useRedeemPoints();
  const isPending = awardMutation.isPending || redeemMutation.isPending;

  const handleSubmit = (e) => {
    e.preventDefault();
    const mutation = type === 'award' ? awardMutation : redeemMutation;
    mutation.mutate({ cardId: card._id || card.id, amount, note }, {
      onSuccess: () => { toast.success(t(type === 'award' ? 'award_success' : 'redeem_success')); onClose(); },
      onError: (err) => toast.error(err.message || t('tx_fail')),
    });
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-md w-full p-8 border border-gray-100 dark:border-gray-800"
      >
        <h2 className="text-2xl font-bold mb-2 dark:text-white">{type === 'award' ? t('award') : t('redeem')} {t('points')}</h2>
        <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">{t('balance')}: {card.currentBalance ?? 0}</p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('amount')}</label>
            <input type="number" required min="1" value={amount} onChange={e => setAmount(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('note')}</label>
            <input type="text" required value={note} onChange={e => setNote(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" />
          </div>
          <div className="flex gap-3 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-3 px-4 border border-gray-300 dark:border-gray-700 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">{t('cancel')}</button>
            <button type="submit" disabled={isPending}
              className={`flex-1 py-3 px-4 text-white font-bold rounded-xl shadow-lg transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 ${
                type === 'award' ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20' : 'bg-red-600 hover:bg-red-700 shadow-red-500/20'
              }`}>
              {isPending && <Loader2 className="w-4 h-4 animate-spin" />}
              {type === 'award' ? t('award') : t('redeem')}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

const TYPE_TABS = [
  { key: 'all', label: 'All' },
  { key: 'loyalty', label: 'Loyalty' },
  { key: 'business_card', label: 'Business Card' },
];

export const CustomersTable = ({ companyId, onAddCard, showCompanyCol = false }) => {
  const { t } = useTranslation();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 400);

  const params = { page, limit: 10, search: debouncedSearch || undefined, ...(companyId ? { companyId } : {}) };
  const { data, isLoading } = useUniqueCustomers(params);

  const customers = data?.data || [];
  const total = data?.total ?? 0;
  const lastPage = data?.lastPage ?? 1;

  const [detailCustomer, setDetailCustomer] = useState(null);
  const [awardCard, setAwardCard] = useState(null);
  const [awardType, setAwardType] = useState('award');
  const [editCustomer, setEditCustomer] = useState(null);
  const [deleteCustomer, setDeleteCustomer] = useState(null);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-6 py-5 border-b border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-white to-gray-50 dark:from-gray-900 dark:to-gray-900">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-50 dark:bg-indigo-900/30 rounded-xl">
            <Users className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <div>
            <h2 className="text-base font-bold dark:text-white">{t('customers')}</h2>
            <p className="text-xs text-gray-400 dark:text-gray-500">{total} {t('customers')}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
            <input
              type="text"
              placeholder={t('search_users')}
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="pl-8 pr-7 py-1.5 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white w-48 transition-all"
            />
            {search && (
              <button onClick={() => { setSearch(''); setPage(1); }} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
          {onAddCard && (
            <button
              onClick={onAddCard}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 px-3 py-1.5 rounded-lg transition-colors shadow-sm shadow-indigo-500/20"
            >
              <Plus className="w-3.5 h-3.5" />
              {t('add_customer')}
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto max-h-[50vh] overflow-y-auto custom-scrollbar border border-gray-100 dark:border-gray-800 rounded-xl">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-50/90 dark:bg-gray-800/90 backdrop-blur-sm border-b border-gray-100 dark:border-gray-800 sticky top-0 z-10">
              {[t('first_name'), t('last_name'), t('email'), t('phone'), ...(showCompanyCol ? [t('company')] : []), t('cards'), t('balance'), t('actions')].map(h => (
                <th key={h} className="px-6 py-3.5 text-[11px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 whitespace-nowrap bg-inherit">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {customers.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-16 text-center">
                  <Users className="w-8 h-8 mx-auto mb-2 text-gray-300 dark:text-gray-700" />
                  <p className="text-sm text-gray-400">{t('no_data')}</p>
                </td>
              </tr>
            ) : customers.map((customer, idx) => {
              const gradient = AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length];
              const totalBalance = customer.cards.reduce((sum, c) => sum + (c.currentBalance || 0), 0);
              const initials = [
                (customer.firstName || '').charAt(0),
                (customer.lastName || '').charAt(0)
              ].filter(Boolean).join('').toUpperCase() || '?';
              return (
                <tr
                  key={customer.userId || customer.id || idx}
                  className="group border-b border-gray-50 dark:border-gray-800/60 hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-colors duration-150"
                >
                  {/* First Name */}
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center shadow-sm shrink-0`}>
                        <span className="text-[11px] font-bold text-white">{initials}</span>
                      </div>
                      <span className="font-semibold text-sm text-gray-800 dark:text-gray-100">{customer.firstName}</span>
                    </div>
                  </td>

                  {/* Last Name */}
                  <td className="px-6 py-4 text-sm font-semibold text-gray-800 dark:text-gray-100">{customer.lastName}</td>

                  {/* Email */}
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{customer.email}</td>

                  {/* Phone */}
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{customer.phone}</td>

                  {/* Company (SuperAdmin only) */}
                  {showCompanyCol && (
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-indigo-400 dark:bg-indigo-500 shrink-0" />
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          {customer.cards[0]?.companyId?.name || '—'}
                        </span>
                      </div>
                    </td>
                  )}

                  {/* Cards count */}
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-[11px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300 ring-1 ring-indigo-200 dark:ring-indigo-800">
                      {customer.cards.length} {customer.cards.length === 1 ? t('card') : t('cards')}
                    </span>
                  </td>

                  {/* Total balance */}
                  <td className="px-6 py-4">
                    <div className="flex items-baseline gap-1">
                      <span className="text-base font-bold text-gray-900 dark:text-white">{totalBalance}</span>
                      <span className="text-xs text-gray-400 dark:text-gray-500">{t('points')}</span>
                    </div>
                  </td>

                  {/* Actions */}
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {customer.cards.some(c => c.programId) && (
                        <button
                          onClick={() => setDetailCustomer(customer)}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          {t('view')}
                        </button>
                      )}
                      <button
                        onClick={() => setEditCustomer(customer)}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                        title={t('edit')}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteCustomer(customer)}
                        className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                        title={t('delete')}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {total > 0 && lastPage > 1 && (
        <Pagination page={page} lastPage={lastPage} total={total} onPageChange={setPage} />
      )}

      {detailCustomer && (
        <CustomerDetailModal
          customer={detailCustomer}
          onClose={() => setDetailCustomer(null)}
          onAward={(card) => { setAwardCard(card); setAwardType('award'); setDetailCustomer(null); }}
          onRedeem={(card) => { setAwardCard(card); setAwardType('redeem'); setDetailCustomer(null); }}
        />
      )}
      {awardCard && (
        <AwardRedeemModal
          card={awardCard}
          type={awardType}
          onClose={() => setAwardCard(null)}
        />
      )}
      {editCustomer && (
        <EditCustomerModal
          customer={editCustomer}
          onClose={() => setEditCustomer(null)}
        />
      )}
      {deleteCustomer && (
        <DeleteConfirmModal
          customer={deleteCustomer}
          onClose={() => setDeleteCustomer(null)}
        />
      )}
    </div>
  );
};
