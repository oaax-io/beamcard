import { useFormik } from 'formik';
import { AlertCircle, CheckCircle2, Loader2, Search, User, Wallet, ArrowRight, ArrowLeft, Calendar, UserCircle, MapPin } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import { useEnrollCustomer } from '../api/hooks/useCards';
import { useUserSearch } from '../api/hooks/useUsers';

export const CustomerEnrollLoyalty = ({ program, programId }) => {
    const { t } = useTranslation();
    const [step, setStep] = useState(1); // 1: Search, 2: Found/Register, 3: Success
    const [foundUser, setFoundUser] = useState(null);
    const [saveUrl, setSaveUrl] = useState(null);

    const enrollMutation = useEnrollCustomer();
    const searchMutation = useUserSearch();

    const searchFormik = useFormik({
        initialValues: { contact: '' },
        validationSchema: Yup.object({
            contact: Yup.string().required(t('required')),
        }),
        onSubmit: (values) => {
            searchMutation.mutate(values.contact, {
                onSuccess: (user) => {
                    if (user) {
                        setFoundUser(user);
                        registerFormik.setValues({
                            firstName: user.firstName || '',
                            lastName: user.lastName || '',
                            email: user.email || '',
                            phone: user.phone || '',
                            birthday: user.birthday ? new Date(user.birthday).toISOString().split('T')[0] : '',
                            gender: user.gender || '',
                            city: user.city || '',
                        });
                    } else {
                        setFoundUser(null);
                        if (values.contact.includes('@')) {
                            registerFormik.setFieldValue('email', values.contact);
                        } else {
                            registerFormik.setFieldValue('phone', values.contact);
                        }
                    }
                    setStep(2);
                },
                onError: () => {
                    toast.error('Search failed. Please try again.');
                }
            });
        }
    });

    const registerFormik = useFormik({
        initialValues: {
            firstName: '',
            lastName: '',
            email: '',
            phone: '',
            birthday: '',
            gender: '',
            city: '',
        },
        validationSchema: Yup.object({
            firstName: Yup.string().required(t('required')),
            lastName: Yup.string().required(t('required')),
            email: Yup.string().email(t('invalid_email')).required(t('required')),
            phone: Yup.string().required(t('required')),
        }),
        onSubmit: (values) => {
            const customerData = {
                ...values,
                userId: foundUser?._id || null,
            };
            
            enrollMutation.mutate({ programId, customerData }, {
                onSuccess: (result) => {
                    setSaveUrl(result.saveUrl);
                    setStep(3);
                    toast.success('Successfully registered!');
                },
                onError: (err) => {
                    toast.error(err.message || 'Failed to register. Please try again.');
                }
            });
        },
    });

    return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50 dark:bg-gray-950 relative overflow-hidden">
            <div
                className="absolute top-0 right-0 w-96 h-96 rounded-full opacity-10 blur-3xl -translate-y-1/2 translate-x-1/3"
                style={{ backgroundColor: program.backgroundColor || '#4f46e5' }}
            />
            <div
                className="absolute bottom-0 left-0 w-96 h-96 rounded-full opacity-10 blur-3xl translate-y-1/3 -translate-x-1/3"
                style={{ backgroundColor: program.backgroundColor || '#4f46e5' }}
            />

            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full max-w-md bg-white dark:bg-gray-900 rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/20 dark:border-gray-800 relative z-10"
            >
                <div
                    className="h-32 relative flex items-center justify-center"
                    style={{ backgroundColor: program.backgroundColor || '#4f46e5' }}
                >
                    <div className="absolute inset-0 bg-black/10" />
                    {program.logo ? (
                        <img
                            src={program.logo}
                            alt={program.issuerName}
                            className="w-20 h-20 rounded-2xl shadow-xl object-cover border-4 border-white/20 bg-white"
                        />
                    ) : (
                        <div className="w-20 h-20 rounded-2xl shadow-xl bg-white/20 backdrop-blur-sm border-2 border-white/30 flex items-center justify-center">
                            <Wallet className="w-10 h-10 text-white" />
                        </div>
                    )}
                </div>

                <div className="p-8">
                    <div className="text-center mb-6">
                        <h1 className="text-2xl font-extrabold text-gray-900 dark:text-white mb-1">{program.programName}</h1>
                        <p className="text-gray-500 dark:text-gray-400 text-xs font-medium tracking-wide uppercase">{program.issuerName}</p>
                    </div>

                    <AnimatePresence mode="wait">
                        {step === 1 && (
                            <motion.div key="step-1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                                <div className="text-center pb-2">
                                    <h2 className="text-lg font-bold dark:text-white">Join the rewards</h2>
                                    <p className="text-sm text-gray-400">Enter your email or phone to start</p>
                                </div>
                                <form onSubmit={searchFormik.handleSubmit} className="space-y-4">
                                    <div className="relative">
                                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                                        <input
                                            placeholder="Email or Phone number"
                                            className={`w-full pl-12 pr-4 py-4 bg-gray-50 dark:bg-gray-800 border ${searchFormik.touched.contact && searchFormik.errors.contact ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white font-medium`}
                                            {...searchFormik.getFieldProps('contact')}
                                        />
                                    </div>
                                    <button
                                        type="submit"
                                        disabled={searchMutation.isPending}
                                        className="w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 disabled:opacity-50"
                                        style={{ backgroundColor: program.backgroundColor, color: '#ffffff' }}
                                    >
                                        {searchMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowRight className="w-5 h-5" />}
                                        Continue
                                    </button>
                                </form>
                            </motion.div>
                        )}

                        {step === 2 && (
                            <motion.div key="step-2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                                {foundUser ? (
                                    <div className="bg-green-50 dark:bg-green-900/20 p-5 rounded-2xl border border-green-100 dark:border-green-900/30 flex items-center gap-4">
                                        <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-800 flex items-center justify-center">
                                            <User className="w-6 h-6 text-green-600 dark:text-green-400" />
                                        </div>
                                        <div className="flex-1">
                                            <h3 className="font-bold text-green-900 dark:text-green-400">Welcome back, {foundUser.firstName}!</h3>
                                            <p className="text-xs text-green-700/70 dark:text-green-500/70">We found your profile. Ready to get your card?</p>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="text-center pb-2">
                                        <h2 className="text-lg font-bold dark:text-white">Almost there!</h2>
                                        <p className="text-sm text-gray-400">Please complete your profile details</p>
                                    </div>
                                )}
                                <form onSubmit={registerFormik.handleSubmit} className="space-y-4">
                                    <div className="grid grid-cols-2 gap-3">
                                        <div>
                                            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1 mb-1 block">First Name</label>
                                            <div className="relative">
                                                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                                <input
                                                    className={`w-full pl-9 pr-3 py-3 text-sm bg-gray-50 dark:bg-gray-800 border ${registerFormik.touched.firstName && registerFormik.errors.firstName ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white font-medium`}
                                                    {...registerFormik.getFieldProps('firstName')}
                                                />
                                            </div>
                                        </div>
                                        <div>
                                            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1 mb-1 block">Last Name</label>
                                            <input
                                                className={`w-full px-3 py-3 text-sm bg-gray-50 dark:bg-gray-800 border ${registerFormik.touched.lastName && registerFormik.errors.lastName ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white font-medium`}
                                                {...registerFormik.getFieldProps('lastName')}
                                            />
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 gap-3">
                                        {!foundUser && (
                                            <>
                                                <div>
                                                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1 mb-1 block">Email</label>
                                                    <input
                                                        type="email"
                                                        className={`w-full px-3 py-3 text-sm bg-gray-50 dark:bg-gray-800 border ${registerFormik.touched.email && registerFormik.errors.email ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white font-medium`}
                                                        {...registerFormik.getFieldProps('email')}
                                                    />
                                                </div>
                                                <div>
                                                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1 mb-1 block">Phone</label>
                                                    <input
                                                        className={`w-full px-3 py-3 text-sm bg-gray-50 dark:bg-gray-800 border ${registerFormik.touched.phone && registerFormik.errors.phone ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white font-medium`}
                                                        {...registerFormik.getFieldProps('phone')}
                                                    />
                                                </div>
                                            </>
                                        )}
                                        <div>
                                            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1 mb-1 block">Birthday (Optional)</label>
                                            <div className="relative">
                                                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                                <input
                                                    type="date"
                                                    className="w-full pl-9 pr-3 py-3 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white font-medium"
                                                    {...registerFormik.getFieldProps('birthday')}
                                                />
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-2 gap-3">
                                            <div>
                                                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1 mb-1 block">Gender (Optional)</label>
                                                <div className="relative">
                                                    <UserCircle className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                                    <select
                                                        className="w-full pl-9 pr-3 py-3 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white font-medium appearance-none"
                                                        {...registerFormik.getFieldProps('gender')}
                                                    >
                                                        <option value="">Select...</option>
                                                        <option value="male">Male</option>
                                                        <option value="female">Female</option>
                                                        <option value="other">Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div>
                                                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 ml-1 mb-1 block">City (Optional)</label>
                                                <div className="relative">
                                                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                                    <input
                                                        placeholder="City"
                                                        className="w-full pl-9 pr-3 py-3 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white font-medium"
                                                        {...registerFormik.getFieldProps('city')}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex gap-3 mt-6">
                                        <button type="button" onClick={() => setStep(1)} className="px-6 py-4 rounded-2xl font-bold bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-200 transition-all active:scale-95">
                                            <ArrowLeft className="w-5 h-5" />
                                        </button>
                                        <button type="submit" disabled={enrollMutation.isPending} className="flex-1 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 disabled:opacity-50" style={{ backgroundColor: program.backgroundColor, color: '#ffffff' }}>
                                            {enrollMutation.isPending && <Loader2 className="w-5 h-5 animate-spin" />}
                                            Get My Card
                                        </button>
                                    </div>
                                </form>
                            </motion.div>
                        )}

                        {step === 3 && (
                            <motion.div key="step-3" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center space-y-6 flex flex-col items-center py-4">
                                <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mb-2 animate-bounce">
                                    <CheckCircle2 className="w-10 h-10 text-green-600 dark:text-green-400" />
                                </div>
                                <div className="space-y-1">
                                    <h3 className="text-2xl font-extrabold dark:text-white">You're all set!</h3>
                                    <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">Your loyalty card has been created.</p>
                                </div>

                                <div className="w-full pt-4">
                                    {saveUrl ? (
                                        <a href={saveUrl} target="_blank" rel="noopener noreferrer" className="w-full py-4 bg-black text-white font-bold rounded-2xl hover:scale-[1.02] shadow-2xl transition-all active:scale-95 flex items-center justify-center gap-3 group">
                                            <Wallet className="w-6 h-6 group-hover:rotate-12 transition-transform" />
                                            Add to Google Wallet
                                        </a>
                                    ) : (
                                        <div className="p-4 bg-orange-50 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400 rounded-2xl text-xs font-bold border border-orange-100 dark:border-orange-900/30 flex items-center gap-3">
                                            <AlertCircle className="w-5 h-5 shrink-0" />
                                            <p>Wallet link generation failed. You can still use your card in-app.</p>
                                        </div>
                                    )}
                                </div>
                                
                                <button onClick={() => window.location.reload()} className="text-xs font-bold text-gray-400 uppercase tracking-widest hover:text-indigo-500 transition-colors">
                                    Finish
                                </button>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </motion.div>
        </div>
    );
};
