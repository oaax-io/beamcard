import { useFormik } from 'formik';
import {
  CheckCircle2,
  ChevronRight,
  CreditCard,
  Facebook,
  Globe,
  Instagram,
  Linkedin,
  Loader2,
  Lock,
  Mail,
  Phone,
  Plus,
  User,
  Wallet,
  X
} from 'lucide-react';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
// Globe kept for Google Wallet section label in step 2
import { AnimatePresence, motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { SketchPicker } from 'react-color';
import toast from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import * as Yup from 'yup';
import { useCards, useCreateCard } from '../api/hooks/useCards';
import { useCompanyById } from '../api/hooks/useCompanies';
import { useCardPrograms, useCreateCardProgram } from '../api/hooks/usePrograms';
import { CardsTable } from './CardsTable';
import { CustomersTable } from './CustomersTable';
import { ProgramQRShare } from './ProgramQRShare';
import { TransactionsTable } from './TransactionsTable';


export const AddCustomerModal = ({ onClose, user }) => {
  const { t } = useTranslation();
  const createCardMutation = useCreateCard();

  const { data: programsData } = useCardPrograms(
    { companyId: user?.companyId, limit: 100 },
    { enabled: !!user }
  );
  const programs = programsData?.data || [];

  const formik = useFormik({
    initialValues: {
      firstName: '', lastName: '', phone: '', email: '',
      programId: '', jobTitle: '', linkedin: '', instagram: '', facebook: ''
    },
    validationSchema: Yup.object({
      firstName: Yup.string().required(t('required')),
      lastName: Yup.string().required(t('required')),
      phone: Yup.string().required(t('required')),
      email: Yup.string().email(t('invalid_email')).required(t('required')),
    }),
    onSubmit: (values, { resetForm, setFieldError }) => {
      const isBusinessCard = programs.find(p => (p._id || p.id) === values.programId)?.type === 'business_card';
      const payload = {
        companyId: user.companyId,
        firstName: values.firstName,
        lastName: values.lastName,
        phone: values.phone,
        email: values.email,
        programId: values.programId || undefined,
      };

      if (isBusinessCard) {
        payload.jobTitle = values.jobTitle;
        payload.metadata = {
          linkedin: values.linkedin,
          instagram: values.instagram,
          facebook: values.facebook
        };
      }

      createCardMutation.mutate(payload, {
        onSuccess: () => {
          toast.success(t('customer_success'));
          onClose();
          resetForm();
        },
        onError: (err) => {
          const msg = err?.response?.data?.message;
          if (msg === 'email_exists') setFieldError('email', t('email_already_exists'));
          else if (msg === 'phone_exists') setFieldError('phone', t('phone_already_exists'));
          else toast.error(t('customer_fail'));
        }
      });
    },
  });

  const selectedProgram = programs.find(p => (p._id || p.id) === formik.values.programId);
  const selectedProgramType = selectedProgram?.type;
  const isBusinessCard = selectedProgramType === 'business_card';

  useEffect(() => {
    if (isBusinessCard && selectedProgram?.config) {
      const c = selectedProgram.config;
      if (c.jobTitle) formik.setFieldValue('jobTitle', c.jobTitle);
      if (c.phone) formik.setFieldValue('phone', c.phone);
      if (c.linkedin) formik.setFieldValue('linkedin', c.linkedin);
      if (c.instagram) formik.setFieldValue('instagram', c.instagram);
      if (c.facebook) formik.setFieldValue('facebook', c.facebook);
    } else {
      formik.setFieldValue('jobTitle', '');
      formik.setFieldValue('linkedin', '');
      formik.setFieldValue('instagram', '');
      formik.setFieldValue('facebook', '');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formik.values.programId, isBusinessCard]);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 16 }}
        className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-md w-full p-8 border border-gray-100 dark:border-gray-800 my-auto max-h-[90vh] overflow-y-auto"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold dark:text-white">{t('add_customer')}</h2>
          <button type="button" onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={formik.handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Select Template (Optional)</label>
            <select
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white appearance-none"
              {...formik.getFieldProps('programId')}
            >
              <option value="">No Template (Generic Card)</option>
              {programs.map(p => (
                <option key={p._id || p.id} value={p._id || p.id}>
                  {p.programName} ({p.type?.replace('_', ' ') || ''})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('first_name')}</label>
              <input type="text" className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border ${formik.touched.firstName && formik.errors.firstName ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white`} {...formik.getFieldProps('firstName')} />
              {formik.touched.firstName && formik.errors.firstName && <p className="text-red-500 text-xs mt-1">{formik.errors.firstName}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('last_name')}</label>
              <input type="text" className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border ${formik.touched.lastName && formik.errors.lastName ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white`} {...formik.getFieldProps('lastName')} />
              {formik.touched.lastName && formik.errors.lastName && <p className="text-red-500 text-xs mt-1">{formik.errors.lastName}</p>}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('phone')}</label>
            <PhoneInput
              international
              defaultCountry="CH"
              value={formik.values.phone}
              onChange={(val) => formik.setFieldValue('phone', val || '')}
              className={`phone-input-container ${formik.touched.phone && formik.errors.phone ? 'phone-input-error' : ''}`}
            />
            {formik.touched.phone && formik.errors.phone && <p className="text-red-500 text-xs mt-1">{formik.errors.phone}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('email')}</label>
            <input type="email" className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border ${formik.touched.email && formik.errors.email ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white`} {...formik.getFieldProps('email')} />
            {formik.touched.email && formik.errors.email && <p className="text-red-500 text-xs mt-1">{formik.errors.email}</p>}
          </div>

          {isBusinessCard && (
            <div className="space-y-4 pt-4 border-t border-gray-100 dark:border-gray-800">
              <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">Business Card Details</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Job Title</label>
                <input type="text" className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" {...formik.getFieldProps('jobTitle')} placeholder="e.g. Sales Manager" />
              </div>
              <div className="grid grid-cols-1 gap-3">
                <input type="text" className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" {...formik.getFieldProps('linkedin')} placeholder="LinkedIn URL" />
                <input type="text" className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" {...formik.getFieldProps('instagram')} placeholder="Instagram URL" />
                <input type="text" className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none dark:text-white" {...formik.getFieldProps('facebook')} placeholder="Facebook URL" />
              </div>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-3 px-4 border border-gray-300 dark:border-gray-700 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">{t('cancel')}</button>
            <button type="submit" disabled={createCardMutation.isPending} className="flex-1 py-3 px-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2">
              {createCardMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
              {t('save')}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export const TenantDashboard = ({ user }) => {
  const { t } = useTranslation();
  const location = useLocation();
  const isTransactionsView = location.pathname.includes('/transactions');
  const isCustomersView = location.pathname.includes('/customers');
  const isDashboardView = !isTransactionsView && !isCustomersView;
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);

  // Queries — small fetch just for the stats cards
  const { data: customersResponse, isLoading: customersLoading } = useCards({ companyId: user.companyId, page: 1, limit: 1 });

  const totalCards = customersResponse?.total ?? 0;

  if (customersLoading) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 bg-gray-50 dark:bg-gray-950 min-h-full transition-colors duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {isTransactionsView ? t('transactions') : (isCustomersView ? t('customers') : t('dashboard'))}
          </h1>
          <p className="text-gray-500 dark:text-gray-400">{t('welcome')}, {user.name}</p>
        </div>
        {isCustomersView && (
          <button
            onClick={() => setIsModalOpen(true)}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 transition-all active:scale-95"
          >
            <Plus className="w-4 h-4" />
            {t('add_customer')}
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm">
          <p className="text-sm text-gray-500 dark:text-gray-400">{t('total_customers')}</p>
          <p className="text-2xl font-bold dark:text-white">{customersResponse?.uniqueCustomers ?? '—'}</p>
        </div>
        <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm">
          <p className="text-sm text-gray-500 dark:text-gray-400">{t('cards')}</p>
          <p className="text-2xl font-bold dark:text-white">{totalCards}</p>
        </div>
      </div>

      {isDashboardView && (
        <div className="space-y-8">
          <CustomersTable
            companyId={user.companyId}
            onAddCard={() => setIsModalOpen(true)}
          />
          <TransactionsTable companyId={user.companyId} />
        </div>
      )}

      {isTransactionsView && <TransactionsTable companyId={user.companyId} />}

      {isCustomersView && (
        <CustomersTable
          companyId={user.companyId}
          onAddCard={() => setIsModalOpen(true)}
        />
      )}

      <AnimatePresence>
        {isModalOpen && (
          <AddCustomerModal
            onClose={() => setIsModalOpen(false)}
            user={user}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export const TenantCardsPage = ({ user }) => {
  const { t } = useTranslation();
  const [isModalOpen, setIsModalOpen] = useState(false);
  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-950 min-h-full">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('cards')}</h1>
          <p className="text-gray-500 dark:text-gray-400">{t('welcome')}, {user.name}</p>
        </div>
      </div>
      <CardsTable
        companyId={user.companyId}
        showCompanyCol={false}
        onAddCard={() => setIsModalOpen(true)}
        onViewCard={undefined}
      />
      <AnimatePresence>
        {isModalOpen && (
          <AddCustomerModal
            onClose={() => setIsModalOpen(false)}
            user={user}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export const CardTypeSelection = () => {
  const { t } = useTranslation();
  const types = [
    { id: 'loyalty', label: t('loyalty'), icon: CreditCard, enabled: true },
    { id: 'business_card', label: t('business_card'), icon: User, enabled: true },
    { id: 'flight', label: t('flight'), icon: Wallet, enabled: false },
    { id: 'offer', label: t('offer'), icon: Wallet, enabled: false },
  ];

  return (
    <div className="p-6 space-y-8 bg-gray-50 dark:bg-gray-950 min-h-full transition-colors duration-300">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('card_type')}</h1>
        <p className="text-gray-500 dark:text-gray-400">Select the type of digital card you want to issue</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {types.map((type) => (
          <div
            key={type.id}
            className={`p-6 rounded-2xl border transition-all relative overflow-hidden ${type.enabled
              ? 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 hover:border-indigo-500 dark:hover:border-indigo-500 cursor-pointer shadow-sm hover:shadow-md'
              : 'bg-gray-50 dark:bg-gray-800/50 border-gray-100 dark:border-gray-800 opacity-75'
              }`}
          >
            {!type.enabled && (
              <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 bg-gray-200 dark:bg-gray-700 rounded text-[10px] font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                <Lock className="w-3 h-3" />
                {t('coming_soon')}
              </div>
            )}
            <div className={`p-3 rounded-xl mb-4 w-fit ${type.enabled ? 'bg-indigo-100 dark:bg-indigo-900/30' : 'bg-gray-200 dark:bg-gray-700'}`}>
              <type.icon className={`w-6 h-6 ${type.enabled ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-400 dark:text-gray-500'}`} />
            </div>
            <h3 className={`font-bold ${type.enabled ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'}`}>{type.label}</h3>
          </div>
        ))}
      </div>
    </div>
  );
};

const ColorPicker = ({ color, onChange, label }) => {
  const { t } = useTranslation();
  const [displayColorPicker, setDisplayColorPicker] = useState(false);

  return (
    <div className="flex flex-col items-center gap-3">
      <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-gray-400">{label}</label>
      <div className="relative">
        <button
          type="button"
          onClick={() => setDisplayColorPicker(!displayColorPicker)}
          className="group flex flex-col items-center gap-2"
        >
          <div
            className="w-20 h-20 rounded-[2rem] shadow-xl border-4 border-white dark:border-gray-800 transition-all group-hover:scale-105 group-hover:rotate-3 active:scale-95"
            style={{ backgroundColor: color }}
          />
          <span className="text-xs font-mono font-bold text-gray-500 dark:text-gray-400 group-hover:text-indigo-500 transition-colors">
            {color.toUpperCase()}
          </span>
        </button>

        {displayColorPicker && (
          <div className="absolute z-[100] mt-4 left-1/2 -translate-x-1/2">
            <div
              className="fixed inset-0 bg-black/10 backdrop-blur-[2px]"
              onClick={() => setDisplayColorPicker(false)}
            />
            <div className="relative animate-in fade-in zoom-in slide-in-from-top-4 duration-300 origin-top">
              <div className="p-4 bg-white dark:bg-gray-900 rounded-[2rem] shadow-2xl border border-gray-100 dark:border-gray-800">
                <div className="flex justify-between items-center mb-4 px-2">
                  <span className="text-[10px] font-bold uppercase tracking-widest dark:text-white">{t('choose_color')}</span>
                  <button
                    type="button"
                    onClick={() => setDisplayColorPicker(false)}
                    className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors"
                  >
                    <X className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
                <SketchPicker
                  color={color}
                  onChange={(c) => onChange(c.hex)}
                  disableAlpha={true}
                  width="220px"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export const CreateTemplatePage = ({ user, onSuccess }) => {
  const { t } = useTranslation();
  const [step, setStep] = useState(1);
  const [createdProgramId, setCreatedProgramId] = useState(null);

  // Queries
  const { data: company, isLoading: companyLoading } = useCompanyById(user.companyId);

  // Mutations
  const createProgramMutation = useCreateCardProgram();

  const formik = useFormik({
    initialValues: {
      type: 'loyalty',
      issuerName: company?.name || '',
      programName: '',
      pointsPerPurchase: 10,
      welcomeBonus: 0,
      logo: company?.logo || '',
      heroImage: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&q=80&w=800',
      googleClassId: '',
      applePassTypeIdentifier: '',
      appleTeamIdentifier: '',
      backgroundColor: '#4f46e5',
      // Business Card specific defaults
      firstName: '',
      lastName: '',
      jobTitle: '',
      phone: '',
      email: '',
      linkedin: '',
      instagram: '',
      facebook: '',
    },
    enableReinitialize: true,
    validationSchema: Yup.object({
      type: Yup.string().required(t('required')),
      programName: Yup.string().when('type', {
        is: 'loyalty',
        then: (schema) => schema.required(t('required')),
      }),
      firstName: Yup.string().when('type', {
        is: 'business_card',
        then: (schema) => schema.required(t('required')),
      }),
      lastName: Yup.string().when('type', {
        is: 'business_card',
        then: (schema) => schema.required(t('required')),
      }),
      email: Yup.string().email(t('invalid_email')),
      pointsPerPurchase: Yup.number().when('type', {
        is: 'loyalty',
        then: (schema) => schema.positive(t('must_be_positive')).required(t('required')),
      }),
      welcomeBonus: Yup.number().when('type', {
        is: 'loyalty',
        then: (schema) => schema.min(0).required(t('required')),
      }),
    }),
    onSubmit: (values) => {
      // Destructure to separate top-level fields from those that should be nested
      const {
        pointsPerPurchase, welcomeBonus,
        firstName, lastName, jobTitle, phone, email,
        linkedin, instagram, facebook,
        ...rest
      } = values;

      const payload = {
        companyId: user.companyId,
        ...rest,
        rules: { pointsPerPurchase, welcomeBonus }
      };

      if (values.type === 'business_card') {
        payload.config = {
          firstName,
          lastName,
          jobTitle,
          phone,
          email,
          linkedin,
          instagram,
          facebook
        };
        // Also map these to top-level for better integration
        payload.issuerName = firstName + ' ' + lastName;
        payload.programName = jobTitle || 'Business Card';
      }

      createProgramMutation.mutate(payload, {
        onSuccess: (program) => {
          toast.success(t('template_success'));
          setCreatedProgramId(program._id || program.id);
          setStep(3);
        },
        onError: () => {
          toast.error(t('template_fail'));
        }
      });
    },
  });

  if (companyLoading) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8 bg-gray-50 dark:bg-gray-950 min-h-full transition-colors duration-300">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('create_template')}</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">{t('design_experience')}</p>
        </div>
        <div className="flex gap-2">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className={`w-8 h-1.5 rounded-full transition-all ${step >= i ? 'bg-indigo-600' : 'bg-gray-200 dark:bg-gray-800'}`}
            />
          ))}
        </div>
      </div>

      <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm">
        {step === 1 ? (
          <div className="p-8 space-y-6">
            <h2 className="text-xl font-bold dark:text-white">{t('step_1_select_type')}</h2>
            <div className="space-y-3">
              {[
                { id: 'loyalty', label: t('loyalty'), icon: CreditCard, enabled: true, description: t('loyalty_desc') },
                { id: 'business_card', label: t('business_card'), icon: User, enabled: true, description: t('business_card_desc') },
                { id: 'flight', label: t('flight'), icon: Wallet, enabled: false, description: t('flight_desc') },
              ].map((type) => (
                <button
                  key={type.id}
                  disabled={!type.enabled}
                  onClick={() => {
                    formik.setFieldValue('type', type.id);
                    setStep(2);
                  }}
                  className={`w-full p-5 rounded-2xl border text-left transition-all relative group flex items-center gap-4 ${type.enabled
                    ? 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 hover:border-indigo-500 dark:hover:border-indigo-500 hover:shadow-md'
                    : 'bg-gray-50 dark:bg-gray-800/50 border-gray-100 dark:border-gray-800 opacity-60 cursor-not-allowed'
                    }`}
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-colors ${type.enabled ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400' : 'bg-gray-100 dark:bg-gray-800 text-gray-400'}`}>
                    <type.icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold dark:text-white">{type.label}</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{type.description}</p>
                  </div>
                  {!type.enabled ? (
                    <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400 flex items-center gap-1">
                      <Lock className="w-3 h-3" /> {t('coming_soon')}
                    </span>
                  ) : (
                    <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-indigo-500 transition-colors" />
                  )}
                </button>
              ))}
            </div>
          </div>
        ) : step === 2 ? (
          <form onSubmit={formik.handleSubmit} className="divide-y divide-gray-100 dark:divide-gray-800">
            <div className="p-8 space-y-8">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold dark:text-white">{t('step_2_configure')} ({t(formik.values.type)})</h2>
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  Change Type
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
                {/* Left Column: Form Fields */}
                <div className="lg:col-span-5 space-y-6">
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        {formik.values.type === 'business_card' ? 'Default First Name' : t('issuer_name')}
                      </label>
                      <input
                        type="text"
                        {...formik.getFieldProps(formik.values.type === 'business_card' ? 'firstName' : 'issuerName')}
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                        placeholder={formik.values.type === 'business_card' ? 'e.g. John' : ''}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        {formik.values.type === 'business_card' ? 'Default Last Name' : t('program_name')}
                      </label>
                      <input
                        type="text"
                        {...formik.getFieldProps(formik.values.type === 'business_card' ? 'lastName' : 'programName')}
                        className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border ${formik.touched.programName && formik.errors.programName ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white`}
                        placeholder={formik.values.type === 'business_card' ? 'e.g. Doe' : "e.g. Aroma Gold Rewards"}
                      />
                    </div>
                    {formik.values.type === 'loyalty' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('points_per_purchase')}</label>
                          <input
                            type="number"
                            {...formik.getFieldProps('pointsPerPurchase')}
                            className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border ${formik.touched.pointsPerPurchase && formik.errors.pointsPerPurchase ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white`}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Welcome Bonus (Points)</label>
                          <input
                            type="number"
                            {...formik.getFieldProps('welcomeBonus')}
                            className={`w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border ${formik.touched.welcomeBonus && formik.errors.welcomeBonus ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white`}
                          />
                        </div>
                      </>
                    )}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Program Logo URL</label>
                      <input
                        type="text"
                        {...formik.getFieldProps('logo')}
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                        placeholder="https://example.com/logo.png"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Hero Image URL (Cover)</label>
                      <input
                        type="text"
                        {...formik.getFieldProps('heroImage')}
                        className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                        placeholder="https://example.com/cover.jpg"
                      />
                    </div>
                  </div>

                  {formik.values.type === 'business_card' && (
                    <div className="space-y-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                      <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 flex items-center gap-2">
                        <User className="w-4 h-4" /> Card Default Details
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Company / Default Job Title</label>
                          <input
                            type="text"
                            {...formik.getFieldProps('jobTitle')}
                            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                            placeholder="e.g. Sales Director"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Company Phone Number</label>
                          <input
                            type="text"
                            {...formik.getFieldProps('phone')}
                            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                            placeholder="e.g. +1 555 123 4567"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Company Email</label>
                        <input
                          type="email"
                          {...formik.getFieldProps('email')}
                          className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                          placeholder="hospital@example.com"
                        />
                      </div>
                      <div className="grid grid-cols-1 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Company LinkedIn URL</label>
                          <input
                            type="text"
                            {...formik.getFieldProps('linkedin')}
                            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                            placeholder="https://linkedin.com/..."
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Company Instagram URL</label>
                          <input
                            type="text"
                            {...formik.getFieldProps('instagram')}
                            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                            placeholder="https://instagram.com/..."
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Company Facebook URL</label>
                          <input
                            type="text"
                            {...formik.getFieldProps('facebook')}
                            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                            placeholder="https://facebook.com/..."
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 flex items-center gap-2">
                      <Globe className="w-4 h-4" /> {t('google_wallet')}
                    </h3>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('google_class_id')}</label>
                      <input
                        type="text"
                        {...formik.getFieldProps('googleClassId')}
                        className="w-full px-4 py-2 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                        placeholder="issuer_id.class_id"
                      />
                    </div>
                  </div>

                  <div className="space-y-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400 flex items-center gap-2">
                      <CreditCard className="w-4 h-4" /> {t('apple_wallet')}
                    </h3>
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('apple_pass_type_id')}</label>
                        <input
                          type="text"
                          {...formik.getFieldProps('applePassTypeIdentifier')}
                          className="w-full px-4 py-2 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                          placeholder="pass.com.example"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('apple_team_id')}</label>
                        <input
                          type="text"
                          {...formik.getFieldProps('appleTeamIdentifier')}
                          className="w-full px-4 py-2 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all dark:text-white"
                          placeholder="TEAMID123"
                        />
                      </div>
                    </div>
                  </div>


                </div>

                {/* Right Column: Preview & Styling */}
                <div className="lg:col-span-7 relative">
                  <div className="sticky top-8 space-y-8">
                    <div className="space-y-6 flex flex-col items-center">
                      <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 text-center">{t('styling')}</h3>
                      <div className="flex justify-center w-full">
                        <ColorPicker
                          label={t('background_color')}
                          color={formik.values.backgroundColor}
                          onChange={(val) => formik.setFieldValue('backgroundColor', val)}
                        />
                      </div>
                    </div>

                    {/* Card Preview */}
                    <div className="space-y-4">
                      <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">Preview</h3>
                      <div
                        className="rounded-3xl shadow-xl min-h-[350px] flex flex-col justify-between relative overflow-hidden transition-colors duration-500 w-full"
                        style={{ backgroundColor: formik.values.backgroundColor, color: '#ffffff' }}
                      >
                        {/* Hero Image Banner bg */}
                        <div className="absolute top-0 left-0 w-full h-28 pointer-events-none">
                          {formik.values.heroImage ? (
                            <>
                              <img src={formik.values.heroImage} alt="Hero Cover" className="w-full h-full object-cover opacity-90" />
                              <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-transparent" />
                            </>
                          ) : (
                            <div className="w-full h-full bg-black/5" />
                          )}
                        </div>

                        {/* Optional overlay decoration */}
                        <div className="absolute top-0 right-0 w-48 h-48 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl pointer-events-none" />

                        <div className="flex justify-between items-start relative z-10 p-6 sm:p-8">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-white/90 backdrop-blur-md rounded-2xl flex items-center justify-center overflow-hidden shadow-sm">
                              {formik.values.logo ? (
                                <img src={formik.values.logo} className="w-full h-full object-contain p-1" referrerPolicy="no-referrer" />
                              ) : (
                                <CreditCard className="w-6 h-6 text-gray-500" />
                              )}
                            </div>
                            <div>
                              <p className="text-xs font-bold uppercase tracking-widest opacity-90 drop-shadow-md" style={{ color: formik.values.heroImage ? '#fff' : '#ffffff' }}>
                                {formik.values.type === 'business_card'
                                  ? (formik.values.firstName ? `${formik.values.firstName} ${formik.values.lastName}` : 'Contact Name')
                                  : (formik.values.issuerName || 'Issuer Name')}
                              </p>
                              <p className="text-lg font-bold drop-shadow-md" style={{ color: formik.values.heroImage ? '#fff' : '#ffffff' }}>
                                {formik.values.type === 'business_card'
                                  ? (formik.values.jobTitle || 'Job Title')
                                  : (formik.values.programName || 'Program Name')}
                              </p>
                            </div>
                          </div>
                          <CheckCircle2 className="w-6 h-6 opacity-90 drop-shadow-md" style={{ color: formik.values.heroImage ? '#fff' : '#ffffff' }} />
                        </div>

                        <div className="relative z-10 px-6 sm:px-8 py-6">
                          {formik.values.type === 'loyalty' ? (
                            <>
                              <p className="text-xs uppercase tracking-wider font-semibold opacity-80 mb-2" style={{ color: '#ffffff' }}>
                                {t('balance')}
                              </p>
                              <h2 className="text-5xl sm:text-6xl font-extrabold tracking-tight" style={{ color: '#ffffff' }}>
                                {formik.values.welcomeBonus || 0} <span className="text-2xl font-normal opacity-80">{t('points')}</span>
                              </h2>
                            </>
                          ) : (
                            <div className="py-2 space-y-4">
                              <div className="flex items-center gap-3 opacity-80">
                                <User className="w-8 h-8" style={{ color: '#ffffff' }} />
                                <span className="text-xl font-bold uppercase tracking-wider" style={{ color: '#ffffff' }}>Business Card</span>
                              </div>

                              <div className="space-y-3">
                                {formik.values.phone && (
                                  <div className="flex items-center gap-2 text-sm opacity-90" style={{ color: '#ffffff' }}>
                                    <Phone className="w-4 h-4" />
                                    <span>{formik.values.phone}</span>
                                  </div>
                                )}
                                {formik.values.email && (
                                  <div className="flex items-center gap-2 text-sm opacity-90" style={{ color: '#ffffff' }}>
                                    <Mail className="w-4 h-4" />
                                    <span>{formik.values.email}</span>
                                  </div>
                                )}
                              </div>

                              <div className="flex gap-4 pt-2">
                                {formik.values.linkedin && <Linkedin className="w-5 h-5 opacity-80" style={{ color: '#ffffff' }} />}
                                {formik.values.instagram && <Instagram className="w-5 h-5 opacity-80" style={{ color: '#ffffff' }} />}
                                {formik.values.facebook && <Facebook className="w-5 h-5 opacity-80" style={{ color: '#ffffff' }} />}
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="flex justify-between items-end relative z-10 p-6 sm:p-8 pt-0">
                          <div className="space-y-2">
                            {formik.values.type === 'loyalty' && (
                              <div className="text-xs font-medium opacity-90 flex items-center gap-2" style={{ color: '#ffffff' }}>
                                <span className="font-bold">Earning:</span> {formik.values.pointsPerPurchase || 0} pts / purchase
                              </div>
                            )}
                            <div className="text-xs font-medium opacity-70" style={{ color: '#ffffff' }}>
                              {formik.values.googleClassId}
                            </div>
                          </div>
                          <div
                            className="px-4 py-2 bg-white/10 border border-white/20 backdrop-blur-md rounded-full text-xs font-bold uppercase tracking-widest shadow-sm"
                            style={{ color: '#ffffff' }}
                          >
                            {t(formik.values.type)}
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400 dark:text-gray-500 text-center italic">
                        Note: Customer balances are managed separately through transactions.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-8 bg-gray-50 dark:bg-gray-800/50 flex justify-end gap-4">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-6 py-3 text-gray-600 dark:text-gray-300 font-bold hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl transition-colors"
              >
                {t('cancel')}
              </button>
              <button
                type="submit"
                disabled={formik.isSubmitting}
                className="px-10 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 transition-all active:scale-95 disabled:opacity-50 flex items-center gap-2"
              >
                {formik.isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
                {t('save')}
              </button>
            </div>
          </form>
        ) : (
          <div className="p-12 space-y-8 flex flex-col items-center text-center">
            <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mb-4">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <h2 className="text-3xl font-bold dark:text-white mb-2">Template Created Successfully!</h2>
              <p className="text-gray-500 dark:text-gray-400 max-w-md mx-auto">
                Your Digital Card Program has been created and synced with Google Wallet. You can now start issuing cards to your customers or share the program directly.
              </p>
            </div>

            <div className="w-full max-w-md pt-4">
              <ProgramQRShare programId={createdProgramId} />
            </div>

            <div className="pt-8 w-full border-t border-gray-100 dark:border-gray-800 flex flex-col gap-4">

              <button
                type="button"
                onClick={() => {
                  setStep(1);
                  setCreatedProgramId(null);
                  formik.resetForm();
                  if (onSuccess) onSuccess();
                }}
                className="w-full py-4 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 font-bold rounded-2xl hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
              >
                Finish
              </button>

              <button
                type="button"
                onClick={() => {
                  setStep(1);
                  setCreatedProgramId(null);
                  formik.resetForm();
                }}
                className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
              >
                {t('create_another')}
              </button>
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
