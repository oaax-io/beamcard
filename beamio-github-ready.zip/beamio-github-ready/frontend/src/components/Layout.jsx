import {
  CreditCard,
  Globe,
  History,
  LayoutDashboard,
  Layers,
  LogOut,
  Menu,
  Moon,
  Store,
  Sun,
  User,
  Users,
  DollarSign,
  FileText
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { ROLES } from '../db';

export const Navbar = ({ user, onLogout, toggleSidebar, isSidebarOpen, theme, toggleTheme }) => {
  const { t, i18n } = useTranslation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const languages = [
    { code: 'en', label: 'English' },
    { code: 'fr', label: 'Français' },
    { code: 'ar', label: 'العربية' },
  ];

  return (
    <nav className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 sticky top-0 z-50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center gap-4">
            {user && (
              <button
                onClick={toggleSidebar}
                className="p-2 rounded-xl text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all active:scale-90 group"
                title={isSidebarOpen ? t('close') : t('open')}
              >
                <div className="relative w-6 h-6 flex items-center justify-center">
                  <motion.div
                    animate={{ rotate: isSidebarOpen ? 90 : 0 }}
                    transition={{ duration: 0.2, ease: "easeOut" }}
                  >
                    <Menu className={`w-5 h-5 ${isSidebarOpen ? 'text-indigo-600 dark:text-indigo-400' : ''}`} />
                  </motion.div>
                </div>
              </button>
            )}
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:scale-110 transition-transform">
                <CreditCard className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-gray-900 dark:text-white">{t('app_name')}</span>
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all active:scale-90"
            >
              {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </button>

            <div className="relative group">
              <button className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                <Globe className="w-4 h-4" />
                {languages.find(l => l.code === i18n.language)?.label || t('language')}
              </button>
              <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 overflow-hidden">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => i18n.changeLanguage(lang.code)}
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>

            {user ? (
              <div className="flex items-center gap-4 pl-4 border-l border-gray-200 dark:border-gray-700">
                <div className="flex flex-col items-end">
                  <span className="text-sm font-semibold text-gray-900 dark:text-white">
                    {user.firstName} {user.lastName}
                  </span>
                  <span className="text-[10px] uppercase tracking-wider text-gray-500 dark:text-gray-400">{t(user.role)}</span>
                </div>
                <button
                  onClick={onLogout}
                  className="p-2 rounded-xl text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                  title={t('logout')}
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <Link
                to="/login"
                className="inline-flex items-center px-5 py-2.5 border border-transparent text-sm font-bold rounded-xl text-white bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 transition-all active:scale-95"
              >
                {t('login')}
              </Link>
            )}
          </div>

          <div className="md:hidden flex items-center gap-2">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all active:scale-90"
            >
              {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </button>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-xl text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none transition-all active:scale-90"
            >
              <div className="relative w-6 h-6 flex items-center justify-center">
                <motion.div
                  animate={{ rotate: isMenuOpen ? 90 : 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Menu className={`w-6 h-6 ${isMenuOpen ? 'text-indigo-600 dark:text-indigo-400' : ''}`} />
                </motion.div>
              </div>
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 overflow-hidden"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <div className="px-3 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">{t('language')}</div>
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    i18n.changeLanguage(lang.code);
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-md text-base font-medium text-gray-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-gray-50 dark:hover:bg-gray-800"
                >
                  {lang.label}
                </button>
              ))}
              {user ? (
                <>
                  <div className="px-3 py-2 text-base font-medium text-gray-500 dark:text-gray-400 border-t border-gray-100 dark:border-gray-800 mt-2">
                    {user.firstName} {user.lastName} ({t(user.role)})
                  </div>
                  <button
                    onClick={onLogout}
                    className="w-full text-left px-3 py-2 rounded-md text-base font-medium text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center gap-2"
                  >
                    <LogOut className="w-5 h-5" />
                    {t('logout')}
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  className="block px-3 py-2 rounded-md text-base font-medium text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {t('login')}
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export const Sidebar = ({ role, isOpen }) => {
  const { t } = useTranslation();

  const links = useMemo(() => {
    if (role === ROLES.SUPERADMIN) {
      return [
        { to: '/admin', icon: LayoutDashboard, label: t('dashboard') },
        { to: '/admin/pricing', icon: DollarSign, label: t('pricing_config') || 'Pricing Config' },
        { to: '/admin/billing', icon: FileText, label: t('billing_transactions') || 'Billing' },
        { to: '/admin/companies', icon: Store, label: t('companies') },
        { to: '/admin/users', icon: Users, label: t('users') },
        { to: '/admin/cards', icon: CreditCard, label: t('cards') },
        { to: '/admin/templates', icon: Layers, label: t('templates') },
        { to: '/admin/transactions', icon: History, label: t('transactions') },
        { to: '/admin/customers', icon: Users, label: t('customers') },
      ];
    }
    if (role === ROLES.TENANT || role === ROLES.ADMIN) {
      return [
        { to: '/tenant', icon: LayoutDashboard, label: t('dashboard') },
        { to: '/tenant/customers', icon: Users, label: t('customers') },
        { to: '/tenant/cards-list', icon: CreditCard, label: t('cards') },
        { to: '/tenant/templates', icon: Layers, label: t('templates') },
        { to: '/tenant/transactions', icon: History, label: t('transactions') },
        { to: '/tenant/billing', icon: FileText, label: t('billing_transactions') || 'Billing' },
        { to: '/tenant/subscription', icon: CreditCard, label: t('subscription_plans') },
      ];
    }
    if (role === ROLES.CUSTOMER) {
      return [
        { to: '/customer', icon: User, label: t('my_card') },
        { to: '/customer/history', icon: History, label: t('history') },
      ];
    }
    return [];
  }, [role, t]);

  if (links.length === 0) return null;

  return (
    <motion.aside
      initial={false}
      animate={{ width: isOpen ? 256 : 0, opacity: isOpen ? 1 : 0 }}
      className="bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 overflow-hidden min-h-[calc(100vh-64px)] transition-colors duration-300"
    >
      <div className="p-4 space-y-2 w-64">
        {links.map((link) => (
          <Link
            key={link.to}
            to={link.to}
            className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-gray-600 dark:text-gray-400 rounded-xl hover:bg-indigo-50 dark:hover:bg-indigo-900/20 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all group"
          >
            <link.icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
            {link.label}
          </Link>
        ))}
      </div>
    </motion.aside>
  );
};
