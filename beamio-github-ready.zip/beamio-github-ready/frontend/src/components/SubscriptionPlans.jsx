import React, { useEffect, useState } from 'react';
import { Check, Loader2, Star, Users, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { 
    useSubscriptionPlans, 
    useMySubscription, 
    usePlanConfig, 
    useCreateCheckoutSession 
} from '../api/hooks/useSubscription';

export const SubscriptionPlans = ({ onSelectPlan }) => {
    const { t } = useTranslation();
    const [searchParams, setSearchParams] = useSearchParams();
    
    // Hardcoded plan structure & features
    const { data: basePlans = [], isLoading: loadingPlans } = useSubscriptionPlans();
    
    // Real pricing from backend config
    const { data: planConfig, isLoading: loadingConfig } = usePlanConfig();
    
    // User's active subscription status
    const { data: mySub, isLoading: loadingMySub } = useMySubscription();
    
    // Stripe checkout mutation
    const createCheckout = useCreateCheckoutSession();
    
    // State for which plan's checkout is loading
    const [loadingPlanId, setLoadingPlanId] = useState(null);

    useEffect(() => {
        if (searchParams.get('success')) {
            toast.success(t('payment_successful_desc') || 'Payment successful! Your subscription is active.');
            searchParams.delete('success');
            setSearchParams(searchParams);
        }
        if (searchParams.get('canceled')) {
            toast.error(t('payment_canceled_desc') || 'Checkout canceled.');
            searchParams.delete('canceled');
            setSearchParams(searchParams);
        }
    }, [searchParams, setSearchParams, t]);

    const getIcon = (id) => {
        switch (id) {
            case 'basic': return <Zap className="w-6 h-6" />;
            case 'pro': return <Star className="w-6 h-6" />;
            case 'team': return <Users className="w-6 h-6" />;
            default: return <Zap className="w-6 h-6" />;
        }
    };

    const handleSelect = async (plan) => {
        // If Basic, no payment needed
        if (plan.id === 'basic') {
            toast.success(t('plan_selected_success', { plan: t(`${plan.id}_name`) }));
            if (onSelectPlan) onSelectPlan(plan);
            return;
        }

        // For Pro / Team, trigger Stripe
        setLoadingPlanId(plan.id);
        try {
            await createCheckout.mutateAsync(plan.id);
            // It redirects on success, so we don't clear loading state here unless error
        } catch (error) {
            toast.error(t('checkout_error') || 'Error creating checkout session.');
            setLoadingPlanId(null);
        }
    };

    if (loadingPlans || loadingConfig || loadingMySub) {
        return (
            <div className="flex items-center justify-center p-12 h-[60vh]">
                <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
            </div>
        );
    }

    // Merge base plans with real prices from config
    const mergedPlans = basePlans.map(plan => {
        if (plan.id === 'basic') return { ...plan, price: 0, currency: planConfig?.currency?.toUpperCase() || 'EUR' };
        if (plan.id === 'pro') return { ...plan, price: planConfig?.plans?.proPrice || plan.price, currency: planConfig?.currency?.toUpperCase() || plan.currency };
        if (plan.id === 'team') return { ...plan, price: planConfig?.plans?.teamPrice || plan.price, currency: planConfig?.currency?.toUpperCase() || plan.currency };
        return plan;
    });

    const activePlanId = mySub?.planId || 'basic';

    return (
        <div className="py-12 px-4 max-w-7xl mx-auto">
            <div className="text-center mb-12">
                <motion.h2
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-3xl md:text-4xl font-extrabold text-gray-900 dark:text-white mb-4"
                >
                    {t('choose_plan')}
                </motion.h2>
                <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="text-lg text-gray-600 dark:text-gray-400"
                >
                    {t('subscription_plans')}
                </motion.p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {mergedPlans.map((plan, index) => {
                    const isActive = activePlanId === plan.id;
                    const isProcessing = loadingPlanId === plan.id;

                    return (
                        <motion.div
                            key={plan.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className={`relative flex flex-col p-8 bg-white dark:bg-gray-900 rounded-[2.5rem] shadow-xl border-2 transition-all hover:scale-[1.02] hover:shadow-2xl ${
                                isActive ? 'border-green-500 shadow-green-100 dark:shadow-none' : 
                                plan.id === 'pro' ? 'border-indigo-500 scale-105 z-10' : 'border-transparent dark:border-gray-800'
                            }`}
                        >
                            {isActive && (
                                <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-green-500 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg flex items-center gap-1">
                                    <Check className="w-4 h-4" /> {t('current_plan') || 'Current Plan'}
                                </div>
                            )}
                            {!isActive && plan.id === 'pro' && (
                                <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                                    {t('most_popular')}
                                </div>
                            )}

                            <div className="flex items-center gap-4 mb-6">
                                <div className={`p-3 rounded-2xl ${
                                    isActive ? 'bg-green-100 text-green-600 dark:bg-green-900/30' :
                                    plan.id === 'pro' ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30' : 
                                    'bg-gray-100 text-gray-600 dark:bg-gray-800'
                                }`}>
                                    {getIcon(plan.id)}
                                </div>
                                <div>
                                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t(`${plan.id}_name`)}</h3>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">{t(`target_${plan.id === 'basic' ? 'ideal_testing' : plan.id === 'pro' ? 'perfect_freelancers' : 'ideal_teams'}`)}</p>
                                </div>
                            </div>

                            <div className="mb-6">
                                <div className="flex items-baseline gap-1">
                                    <span className="text-4xl font-black text-gray-900 dark:text-white">{plan.price}</span>
                                    <span className="text-lg font-medium text-gray-500 dark:text-gray-400">{plan.currency}</span>
                                    <span className="text-gray-500 dark:text-gray-400">/{t('billingPeriod' === plan.billingPeriod ? 'month' : 'month')}</span>
                                </div>
                                <p className="text-xs text-gray-400 mt-1">{t('billed_monthly')}</p>
                            </div>

                            <p className="text-gray-600 dark:text-gray-400 text-sm mb-8 leading-relaxed">
                                {t(`${plan.id}_desc`)}
                            </p>

                            <div className="flex-grow">
                                <h4 className="text-sm font-bold text-gray-900 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                                    <Check className={`w-4 h-4 ${isActive ? 'text-green-500' : 'text-indigo-600'}`} />
                                    {t('features')}
                                </h4>
                                <ul className="space-y-3 mb-8">
                                    {plan.features.map((feature, fIndex) => (
                                        <li key={fIndex} className="flex font-medium text-sm text-gray-600 dark:text-gray-400 gap-3">
                                            <div className={`mt-1 flex-shrink-0 w-1.5 h-1.5 rounded-full ${isActive ? 'bg-green-500' : 'bg-indigo-500'}`} />
                                            {t(`${plan.id}_feature_${fIndex}`)}
                                        </li>
                                    ))}
                                </ul>
                            </div>

                            <button
                                onClick={() => handleSelect(plan)}
                                disabled={isActive || isProcessing || (loadingPlanId !== null)}
                                className={`w-full py-4 rounded-2xl font-bold transition-all flex items-center justify-center gap-2
                                    ${isActive 
                                        ? 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400 cursor-not-allowed' 
                                        : plan.id === 'pro'
                                            ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-200 dark:shadow-none active:scale-95'
                                            : 'bg-gray-900 dark:bg-white text-white dark:text-gray-900 hover:opacity-90 active:scale-95 shadow-lg'
                                    }`}
                            >
                                {isProcessing && <Loader2 className="w-5 h-5 animate-spin" />}
                                {isActive ? (t('current_plan') || 'Current Plan') : isProcessing ? (t('processing') || 'Processing...') : (t('select_plan') || 'Select Plan')}
                            </button>
                        </motion.div>
                    );
                })}
            </div>
        </div>
    );
};
