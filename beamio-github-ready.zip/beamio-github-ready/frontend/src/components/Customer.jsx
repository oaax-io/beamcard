import {
  ArrowDownRight,
  ArrowUpRight,
  Briefcase,
  CreditCard,
  Globe,
  History,
  Linkedin,
  Loader2,
  User,
  Wallet
} from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { useCardsByUserId, useSaveLink, useTransactions } from '../api/hooks/useCards';

export const CustomerDashboard = ({ user }) => {
  const { t } = useTranslation();
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [saveUrl, setSaveUrl] = useState(null);

  // Queries
  const { data: customers = [], isLoading: customersLoading } = useCardsByUserId(user.id);
  const { data: transactions = [], isLoading: transactionsLoading } = useTransactions(selectedCustomer?._id || selectedCustomer?.id);

  // Mutations
  const saveLinkMutation = useSaveLink();

  // Set initial selected customer
  useEffect(() => {
    if (customers.length > 0 && !(selectedCustomer?._id || selectedCustomer?.id)) {
      setSelectedCustomer(customers[0]);
    }
  }, [customers, selectedCustomer?._id, selectedCustomer?.id]);

  const handleSelectCard = (cust) => {
    setSelectedCustomer(cust);
    setSaveUrl(null);
  };

  const handleAddToWallet = () => {
    if (!selectedCustomer) return;
    saveLinkMutation.mutate(selectedCustomer._id || selectedCustomer.id, {
      onSuccess: ({ saveUrl }) => {
        setSaveUrl(saveUrl);
        window.open(saveUrl, '_blank');
        toast.success(t('wallet_success'));
      },
      onError: () => {
        toast.error(t('wallet_fail'));
      }
    });
  };

  if (customersLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (customers.length === 0) {
    return (
      <div className="p-12 text-center text-gray-500 dark:text-gray-400">
        <CreditCard className="w-12 h-12 mx-auto mb-4 opacity-20" />
        <p>{t('no_data')}</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 max-w-6xl mx-auto bg-gray-50 dark:bg-gray-950 min-h-full transition-colors duration-300">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{t('welcome')}, {user.name}!</h1>
        <p className="text-gray-500 dark:text-gray-400">{t('manage_rewards')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Card List */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold px-2 dark:text-white">{t('my_cards')}</h3>
          <div className="space-y-3">
            {customers.map((cust) => (
              <button
                key={cust._id || cust.id}
                onClick={() => handleSelectCard(cust)}
                className={`w-full text-left p-4 rounded-2xl border transition-all ${(selectedCustomer?._id || selectedCustomer?.id) === (cust._id || cust.id)
                    ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-500/50 ring-2 ring-indigo-500/20'
                    : 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 hover:border-indigo-300 dark:hover:border-indigo-500'
                  }`}
              >
                <div className="flex items-center gap-3">
                  <img src={cust.company?.logo} className="w-10 h-10 rounded-lg object-cover" referrerPolicy="no-referrer" />
                  <div>
                    <p className="font-bold text-gray-900 dark:text-white">{cust.company?.name}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{cust.type || t('loyalty')} • {cust.currentBalance} pts</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Card Detail */}
        <div className="lg:col-span-2 space-y-8">
          {selectedCustomer && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                <motion.div
                  key={selectedCustomer._id || selectedCustomer.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-indigo-600 rounded-3xl p-8 text-white shadow-2xl shadow-indigo-200 dark:shadow-none relative overflow-hidden aspect-[1.6/1] flex flex-col justify-between"
                >
                  <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
                  <div className="flex justify-between items-start relative z-10">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-md">
                      {selectedCustomer.type === 'business_card' ? (
                        <User className="w-6 h-6 text-white" />
                      ) : (
                        <CreditCard className="w-6 h-6 text-white" />
                      )}
                    </div>
                    <span className="text-xs font-bold uppercase tracking-widest text-white/60">{selectedCustomer.company?.name}</span>
                  </div>
                  <div className="relative z-10">
                    {selectedCustomer.type === 'business_card' ? (
                      <div className="space-y-1">
                        <h2 className="text-3xl font-extrabold tracking-tight">{selectedCustomer.name}</h2>
                        <p className="text-sm text-white/80 font-medium flex items-center gap-2">
                          <Briefcase className="w-4 h-4" /> {selectedCustomer.jobTitle}
                        </p>
                      </div>
                    ) : (
                      <>
                        <p className="text-sm text-white/60 mb-1 uppercase tracking-wider font-semibold">{t('balance')}</p>
                        <h2 className="text-5xl font-extrabold tracking-tight">{selectedCustomer.currentBalance} <span className="text-2xl font-normal opacity-80">{t('points')}</span></h2>
                      </>
                    )}
                  </div>
                  <div className="flex justify-between items-end relative z-10">
                    <div>
                      <p className="text-[10px] text-white/40 uppercase tracking-widest mb-1">Object ID</p>
                      <p className="text-xs font-mono opacity-80">{selectedCustomer.walletIds?.googleObjectId}</p>
                    </div>
                    <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center backdrop-blur-md">
                      <Wallet className="w-5 h-5 text-white" />
                    </div>
                  </div>
                </motion.div>

                <div className="space-y-6">
                  <div className="bg-white dark:bg-gray-900 p-8 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm">
                    <h3 className="text-xl font-bold mb-4 dark:text-white">{t('add_to_wallet')}</h3>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">{t('save_wallet_desc', { company: selectedCustomer.company?.name })}</p>
                    <button
                      onClick={handleAddToWallet}
                      className="w-full py-4 px-6 bg-black text-white rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-gray-900 transition-all transform active:scale-95 shadow-lg"
                    >
                      <Wallet className="w-6 h-6" />
                      {t('add_to_wallet')}
                    </button>
                    {saveUrl && (
                      <p className="mt-4 text-[10px] font-mono text-gray-400 dark:text-gray-500 break-all text-center">
                        Mock JWT: {saveUrl}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">
                {selectedCustomer.type === 'business_card' ? (
                  <div className="p-8 space-y-6">
                    <div className="flex items-center gap-2 border-b border-gray-100 dark:border-gray-800 pb-4">
                      <User className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                      <h2 className="text-lg font-bold dark:text-white">{t('contact_info')}</h2>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {selectedCustomer.website && (
                        <a
                          href={selectedCustomer.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-3 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all group border border-transparent hover:border-indigo-100 dark:hover:border-indigo-500/30"
                        >
                          <div className="w-12 h-12 rounded-xl bg-white dark:bg-gray-900 flex items-center justify-center shadow-sm group-hover:text-indigo-600 transition-colors">
                            <Globe className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-0.5">{t('website')}</p>
                            <p className="text-sm font-bold dark:text-gray-200">{selectedCustomer.website.replace(/^https?:\/\//, '')}</p>
                          </div>
                        </a>
                      )}
                      {selectedCustomer.linkedin && (
                        <a
                          href={selectedCustomer.linkedin}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-3 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all group border border-transparent hover:border-indigo-100 dark:hover:border-indigo-500/30"
                        >
                          <div className="w-12 h-12 rounded-xl bg-white dark:bg-gray-900 flex items-center justify-center shadow-sm group-hover:text-indigo-600 transition-colors">
                            <Linkedin className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-0.5">{t('linkedin')}</p>
                            <p className="text-sm font-bold dark:text-gray-200">LinkedIn Profile</p>
                          </div>
                        </a>
                      )}
                      <div className="flex items-center gap-3 p-4 rounded-2xl bg-gray-50 dark:bg-gray-800 border border-transparent">
                        <div className="w-12 h-12 rounded-xl bg-white dark:bg-gray-900 flex items-center justify-center shadow-sm">
                          <Briefcase className="w-6 h-6 text-indigo-600" />
                        </div>
                        <div>
                          <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-0.5">{t('job_title')}</p>
                          <p className="text-sm font-bold dark:text-gray-200">{selectedCustomer.jobTitle}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="p-6 border-b border-gray-100 dark:border-gray-800 flex items-center gap-2">
                      <History className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                      <h2 className="text-lg font-bold dark:text-white">{t('history')} - {selectedCustomer.company?.name}</h2>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left">
                        <thead className="bg-gray-50 dark:bg-gray-800/50 text-xs uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400">
                          <tr>
                            <th className="px-6 py-3">{t('date')}</th>
                            <th className="px-6 py-3">{t('type')}</th>
                            <th className="px-6 py-3">{t('amount')}</th>
                            <th className="px-6 py-3">{t('note')}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                          {transactions.map((tx) => (
                            <tr key={tx._id || tx.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                              <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                                {new Date(tx.date).toLocaleDateString()}
                              </td>
                              <td className="px-6 py-4">
                                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${tx.type === 'award' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                                  }`}>
                                  {tx.type === 'award' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                                  {t(tx.type)}
                                </span>
                              </td>
                              <td className={`px-6 py-4 font-bold ${tx.type === 'award' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                                {tx.type === 'award' ? '+' : '-'}{tx.amount}
                              </td>
                              <td className="px-6 py-4 text-sm text-gray-600 dark:text-gray-400">{tx.note}</td>
                            </tr>
                          ))}
                          {transactions.length === 0 && (
                            <tr>
                              <td colSpan="4" className="px-6 py-12 text-center text-gray-400 dark:text-gray-500">{t('no_data')}</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
