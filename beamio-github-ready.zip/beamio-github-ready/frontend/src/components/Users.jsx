import { useFormik } from 'formik';
import {
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Edit2,
  Eye,
  EyeOff,
  Loader2,
  Plus,
  Search,
  Trash2,
  User,
  UserCheck,
  X
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import { useCompanies } from '../api/hooks/useCompanies';
import { useCreateUser, useDeleteUser, useUpdateUser, useUsers } from '../api/hooks/useUsers';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import { useDebounce } from '../hooks/useDebounce';

const ROLES = [
  { value: 'SUPERADMIN', label: 'Super Admin', color: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300' },
  { value: 'ADMIN', label: 'Admin', color: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300' },
  { value: 'TENANT', label: 'Tenant', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' },
  { value: 'STAFF', label: 'Staff', color: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300' },
  { value: 'CUSTOMER', label: 'Customer', color: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' },
];

// Roles that strictly require a company
const REQUIRES_COMPANY = ['TENANT', 'STAFF'];
// Roles that can optionally have a company
const CAN_HAVE_COMPANY = ['ADMIN', 'TENANT', 'STAFF'];

const RoleBadge = ({ role }) => {
  const found = ROLES.find(r => r.value === role);
  if (!found) return <span className="text-gray-400 text-xs">{role}</span>;
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${found.color}`}>
      {found.label}
    </span>
  );
};

const EMPTY_FORM = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  password: '',
  role: 'CUSTOMER',
  companyId: '',
  profileImage: '',
};

export const SuperAdminUsers = () => {
  const { t } = useTranslation();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [companyFilter, setCompanyFilter] = useState('');
  const [page, setPage] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const debouncedSearch = useDebounce(searchTerm, 500);

  const { data: usersResponse, isLoading: usersLoading } = useUsers({
    search: debouncedSearch || undefined,
    role: roleFilter || undefined,
    companyId: companyFilter || undefined,
    page,
    limit: 10,
  });
  const { data: companiesResponse, isLoading: companiesLoading } = useCompanies({ limit: 100 });
  const companies = companiesResponse?.data || [];
  const isLoading = usersLoading || companiesLoading;

  const users = usersResponse?.data || [];
  const totalUsers = usersResponse?.total || 0;
  const lastPage = usersResponse?.lastPage || 1;
  const createMutation = useCreateUser();
  const updateMutation = useUpdateUser();
  const deleteMutation = useDeleteUser();

  const formik = useFormik({
    initialValues: editingUser ? {
      firstName: editingUser.firstName || '',
      lastName: editingUser.lastName || '',
      email: editingUser.email || '',
      phone: editingUser.phone || '',
      password: '',
      role: editingUser.role || 'CUSTOMER',
      companyId: editingUser.companyId?._id || editingUser.companyId || '',
      profileImage: editingUser.profileImage || '',
    } : EMPTY_FORM,
    enableReinitialize: true,
    validationSchema: Yup.object({
      firstName: Yup.string().min(2, t('too_short')).required(t('required')),
      lastName: Yup.string().min(2, t('too_short')).required(t('required')),
      email: Yup.string().email(t('invalid_email')).required(t('required')),
      phone: Yup.string().optional(),
      password: editingUser
        ? Yup.string().min(6, t('min_6_chars')).optional()
        : Yup.string().min(6, t('min_6_chars')).required(t('required')),
      role: Yup.string().required(t('required')),
      companyId: Yup.string().when('role', {
        is: (r) => REQUIRES_COMPANY.includes(r),
        then: (s) => s.required(t('required')),
        otherwise: (s) => s.optional(),
      }),
      profileImage: Yup.string().url(t('invalid_url')).optional().nullable(),
    }),
    onSubmit: (values, { resetForm }) => {
      const payload = { ...values };
      if (!payload.password) delete payload.password;
      if (!payload.companyId || !REQUIRES_COMPANY.includes(payload.role)) delete payload.companyId;
      if (!payload.profileImage) delete payload.profileImage;
      if (!payload.phone) delete payload.phone;

      const mutation = editingUser ? updateMutation : createMutation;
      const data = editingUser ? { id: editingUser._id || editingUser.id, ...payload } : payload;

      mutation.mutate(data, {
        onSuccess: () => {
          toast.success(t(editingUser ? 'user_updated' : 'user_created'));
          setIsModalOpen(false);
          setEditingUser(null);
          resetForm();
        },
        onError: (err) => {
          const msg = err?.response?.data?.message || t(editingUser ? 'user_update_fail' : 'user_create_fail');
          toast.error(msg);
        },
      });
    },
  });

  const openCreate = () => {
    setEditingUser(null);
    formik.resetForm({ values: EMPTY_FORM });
    setIsModalOpen(true);
  };

  const openEdit = (user) => {
    setEditingUser(user);
    setIsModalOpen(true);
  };

  const confirmDelete = () => {
    deleteMutation.mutate(userToDelete._id || userToDelete.id, {
      onSuccess: () => {
        toast.success(t('user_deleted'));
        setIsDeleteModalOpen(false);
        setUserToDelete(null);
      },
      onError: () => {
        toast.error(t('user_delete_fail'));
        setIsDeleteModalOpen(false);
        setUserToDelete(null);
      },
    });
  };

  const inputClass = (touched, error) =>
    `w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border ${touched && error ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white text-sm`;

  const fieldError = (field) =>
    formik.touched[field] && formik.errors[field]
      ? <p className="text-red-500 text-xs mt-1">{formik.errors[field]}</p>
      : null;

  if (isLoading) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 bg-gray-50 dark:bg-gray-950 min-h-full">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold dark:text-white bg-clip-text text-transparent bg-gradient-to-r from-indigo-500 to-purple-600">
            {t('users_management')}
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">{t('manage_users_desc')}</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 flex-wrap">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder={t('search_users')}
              value={searchTerm}
              onChange={(e) => { setSearchTerm(e.target.value); setPage(1); }}
              className="pl-10 pr-10 py-2 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white w-full sm:w-56"
            />
            {searchTerm && (
              <button onClick={() => { setSearchTerm(''); setPage(1); }} className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full text-gray-400 hover:text-gray-600 transition-colors">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <select
            value={roleFilter}
            onChange={(e) => { setRoleFilter(e.target.value); setPage(1); }}
            className="py-2 px-3 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm dark:text-white transition-all"
          >
            <option value="">{t('all_roles')}</option>
            {ROLES.map(r => (
              <option key={r.value} value={r.value}>{r.label}</option>
            ))}
          </select>

          <select
            value={companyFilter}
            onChange={(e) => { setCompanyFilter(e.target.value); setPage(1); }}
            className="py-2 px-3 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm dark:text-white transition-all"
          >
            <option value="">{t('all_companies')}</option>
            {companies.map(c => (
              <option key={c._id || c.id} value={c._id || c.id}>{c.name}</option>
            ))}
          </select>

          <button
            onClick={openCreate}
            className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-xl font-medium transition-all shadow-lg shadow-indigo-200 dark:shadow-none"
          >
            <Plus className="w-4 h-4" />
            {t('create_user')}
          </button>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 dark:bg-gray-800/50 text-xs uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400">
              <tr>
                <th className="px-6 py-3">{t('user')}</th>
                <th className="px-6 py-3">{t('email')}</th>
                <th className="px-6 py-3">{t('phone')}</th>
                <th className="px-6 py-3">{t('role')}</th>
                <th className="px-6 py-3">{t('company')}</th>
                <th className="px-6 py-3">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {users.length === 0 && !isLoading ? (
                <tr>
                  <td colSpan={6} className="text-center px-6 py-12 text-gray-400">
                    <User className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    <p>{t('no_users')}</p>
                  </td>
                </tr>
              ) : users.map((user) => (
                <tr key={user._id || user.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      {user.profileImage ? (
                        <img src={user.profileImage} alt="" className="w-9 h-9 rounded-full object-cover border-2 border-white dark:border-gray-700 shadow-sm" />
                      ) : (
                        <div className="w-9 h-9 rounded-full bg-indigo-100 dark:bg-indigo-900/40 flex items-center justify-center">
                          <UserCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        </div>
                      )}
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white text-sm">{user.firstName} {user.lastName}</p>
                        <p className="text-xs text-gray-400">{user.name || ''}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{user.email}</td>
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">{user.phone || '—'}</td>
                  <td className="px-6 py-4"><RoleBadge role={user.role} /></td>
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                    {user.companyId?.name || (companies.find(c => (c._id || c.id) === (user.companyId?._id || user.companyId))?.name) || '—'}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); openEdit(user); }}
                        className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                        title={t('edit')}
                      >
                        <Edit2 className="w-4 h-4 pointer-events-none" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); setUserToDelete(user); setIsDeleteModalOpen(true); }}
                        className="p-1.5 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                        title={t('delete')}
                      >
                        <Trash2 className="w-4 h-4 pointer-events-none" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {totalUsers > 0 && (
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4 bg-white dark:bg-gray-900 p-4 rounded-2xl border border-gray-100 dark:border-gray-800">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {t('showing')} <span className="font-medium">{(page - 1) * 10 + 1}</span> - <span className="font-medium">{Math.min(page * 10, totalUsers)}</span> {t('of')} <span className="font-medium">{totalUsers}</span> {t('users')}
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-5 h-5 dark:text-gray-300" />
            </button>
            <div className="flex items-center gap-1">
              {[...Array(lastPage)].map((_, i) => (
                <button
                  key={i + 1}
                  onClick={() => setPage(i + 1)}
                  className={`w-8 h-8 rounded-lg text-sm font-medium transition-colors ${page === i + 1
                    ? 'bg-indigo-600 text-white'
                    : 'hover:bg-gray-50 dark:hover:bg-gray-800 dark:text-gray-300'
                    }`}
                >
                  {i + 1}
                </button>
              ))}
            </div>
            <button
              onClick={() => setPage(p => Math.min(lastPage, p + 1))}
              disabled={page === lastPage}
              className="p-2 rounded-lg border border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="w-5 h-5 dark:text-gray-300" />
            </button>
          </div>
        </div>
      )}

      {/* Create / Edit Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-2xl w-full p-8 border border-gray-100 dark:border-gray-800 my-8"
            >
              <h2 className="text-2xl font-bold mb-6 dark:text-white">
                {editingUser ? t('edit_user') : t('create_user')}
              </h2>

              <form onSubmit={formik.handleSubmit} className="space-y-5">
                {/* Profile Image Preview */}
                {formik.values.profileImage && (
                  <div className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                    <img
                      src={formik.values.profileImage}
                      alt="Preview"
                      className="w-14 h-14 rounded-full object-cover border-4 border-white dark:border-gray-700 shadow-md"
                      onError={(e) => { e.target.style.display = 'none'; }}
                    />
                    <div>
                      <p className="text-sm font-medium dark:text-white">{t('profile_preview')}</p>
                      <p className="text-xs text-gray-400">{t('profile_image_hint')}</p>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('profile_image')} <span className="text-gray-400">({t('optional')})</span></label>
                  <input
                    {...formik.getFieldProps('profileImage')}
                    placeholder="https://example.com/avatar.png"
                    className={inputClass(formik.touched.profileImage, formik.errors.profileImage)}
                  />
                  {fieldError('profileImage')}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('first_name')} *</label>
                    <input {...formik.getFieldProps('firstName')} className={inputClass(formik.touched.firstName, formik.errors.firstName)} />
                    {fieldError('firstName')}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('last_name')} *</label>
                    <input {...formik.getFieldProps('lastName')} className={inputClass(formik.touched.lastName, formik.errors.lastName)} />
                    {fieldError('lastName')}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('email')} *</label>
                    <input type="email" {...formik.getFieldProps('email')} className={inputClass(formik.touched.email, formik.errors.email)} />
                    {fieldError('email')}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      {t('phone')}
                    </label>
                    <PhoneInput
                      international
                      defaultCountry="CH"
                      value={formik.values.phone}
                      onChange={(val) => formik.setFieldValue('phone', val)}
                      className={`phone-input-container ${formik.touched.phone && formik.errors.phone ? 'phone-input-error' : ''}`}
                    />
                    {fieldError('phone')}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {t('password')} {editingUser && <span className="text-gray-400">({t('leave_blank_to_keep')})</span>}
                    {!editingUser && ' *'}
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      {...formik.getFieldProps('password')}
                      className={`${inputClass(formik.touched.password, formik.errors.password)} pr-12`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-colors p-1"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {fieldError('password')}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('role')} *</label>
                    <select
                      {...formik.getFieldProps('role')}
                      className={inputClass(formik.touched.role, formik.errors.role)}
                    >
                      {ROLES.map(r => (
                        <option key={r.value} value={r.value}>{r.label}</option>
                      ))}
                    </select>
                    {fieldError('role')}
                  </div>

                  {CAN_HAVE_COMPANY.includes(formik.values.role) && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        {t('company')} {REQUIRES_COMPANY.includes(formik.values.role) ? '*' : <span className="text-gray-400">({t('optional')})</span>}
                      </label>
                      <select
                        {...formik.getFieldProps('companyId')}
                        className={inputClass(formik.touched.companyId, formik.errors.companyId)}
                      >
                        <option value="">{t('select_company')}</option>
                        {companies.map(c => (
                          <option key={c._id || c.id} value={c._id || c.id}>{c.name}</option>
                        ))}
                      </select>
                      {fieldError('companyId')}
                    </div>
                  )}
                </div>

                <div className="flex gap-3 pt-4 border-t border-gray-100 dark:border-gray-800">
                  <button
                    type="button"
                    onClick={() => { setIsModalOpen(false); setEditingUser(null); }}
                    className="flex-1 py-3 px-4 border border-gray-300 dark:border-gray-700 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors font-medium"
                  >
                    {t('cancel')}
                  </button>
                  <button
                    type="submit"
                    disabled={createMutation.isPending || updateMutation.isPending}
                    className="flex-1 py-3 px-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 animate-spin" />}
                    {t('save')}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {isDeleteModalOpen && userToDelete && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-md w-full p-8 border border-gray-100 dark:border-gray-800"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-2xl">
                  <AlertCircle className="w-6 h-6 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <h3 className="text-xl font-bold dark:text-white">{t('confirm_delete')}</h3>
                  <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">{t('confirm_delete_user')}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setIsDeleteModalOpen(false);
                    setUserToDelete(null);
                  }}
                  className="flex-1 py-3 px-4 border border-gray-300 dark:border-gray-700 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors font-medium"
                >
                  {t('cancel')}
                </button>
                <button
                  onClick={confirmDelete}
                  disabled={deleteMutation.isPending}
                  className="flex-1 py-3 px-4 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-500/20 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {deleteMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
                  {t('delete')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
