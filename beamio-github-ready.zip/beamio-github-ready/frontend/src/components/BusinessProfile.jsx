import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api/axios';
import { Mail, Phone, Building, Briefcase, Download, Globe, Linkedin, Instagram, Facebook } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import toast from 'react-hot-toast';

export const BusinessProfile = () => {
  const { objectId } = useParams();
  const { t } = useTranslation();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isTemplate, setIsTemplate] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        // Check if URL contains 'template/' prefix
        const pathParts = window.location.pathname.split('/');
        const templateIndex = pathParts.indexOf('template');
        const isTemplateRoute = templateIndex !== -1 && pathParts[templateIndex + 1];
        
        setIsTemplate(isTemplateRoute);
        
        const endpoint = isTemplateRoute 
          ? `/business-cards/template/${objectId}/profile`
          : `/business-cards/${objectId}/profile`;
        
        const { data } = await api.get(endpoint);
        setProfile(data);
      } catch (err) {
        console.error('Failed to load profile', err);
        setError('Card not found or inactive.');
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, [objectId]);

  const handleDownloadVcf = () => {
    // Generate full backend URL for VCF download
    const baseURL = api.defaults?.baseURL || (window.location.protocol + '//' + window.location.hostname + ':3000');
    
    const vcfUrl = isTemplate 
      ? `${baseURL}/business-cards/template/${objectId}/vcf`
      : `${baseURL}/business-cards/${objectId}/vcf`;
    
    window.location.href = vcfUrl;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-2xl shadow-xl text-center max-w-sm w-full">
          <div className="bg-red-50 text-red-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl font-bold">!</span>
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">{error || 'Card not found'}</h2>
          <p className="text-gray-500">The business card you are looking for does not exist or has been removed.</p>
        </div>
      </div>
    );
  }

  const { firstName, lastName, jobTitle, email, phone, companyName, metadata } = profile;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-blue-100 flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden transform transition-all hover:-translate-y-1 hover:shadow-3xl">
        
        {/* Header Cover */}
        <div className="h-32 bg-indigo-600 relative overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-10"></div>
          {/* Decorative circles */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-white opacity-10 rounded-full blur-2xl"></div>
          <div className="absolute top-10 -left-10 w-24 h-24 bg-white opacity-20 rounded-full blur-xl"></div>
        </div>

        {/* Profile Info */}
        <div className="relative px-6 pb-8 text-center -mt-16">
          <div className="w-32 h-32 mx-auto bg-white rounded-full p-2 mb-4 shadow-xl border-4 border-white z-10 relative">
            <div className="w-full h-full bg-indigo-100 rounded-full flex items-center justify-center text-4xl font-bold text-indigo-500 uppercase">
              {firstName?.[0] || ''}{lastName?.[0] || ''}
            </div>
          </div>

          <h1 className="text-3xl font-extrabold text-gray-900 mb-1">{firstName} {lastName}</h1>
          <h2 className="text-lg text-indigo-600 font-semibold mb-2">{jobTitle}</h2>
          
          {companyName && (
            <div className="inline-flex items-center space-x-2 bg-gray-50 px-4 py-1.5 rounded-full border border-gray-100 mb-6">
              <Building className="w-4 h-4 text-gray-400" />
              <span className="text-sm font-medium text-gray-600">{companyName}</span>
            </div>
          )}

          {/* Download Button */}
          <button
            onClick={handleDownloadVcf}
            className="w-full py-4 px-6 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold tracking-wide shadow-lg hover:shadow-indigo-500/30 transition-all flex items-center justify-center space-x-3 group mb-8"
          >
            <Download className="w-5 h-5 group-hover:-translate-y-1 transition-transform" />
            <span>Download Contact</span>
          </button>

          {/* Contact Details Grid */}
          <div className="space-y-4 mb-8 text-left">
            {email && (
              <a href={`mailto:${email}`} className="flex items-center space-x-4 p-4 rounded-xl border border-gray-100 hover:bg-indigo-50 hover:border-indigo-100 transition-colors group">
                <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-500 flex items-center justify-center group-hover:bg-indigo-100">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-0.5">Email</p>
                  <p className="font-medium text-gray-900">{email}</p>
                </div>
              </a>
            )}

            {phone && (
              <a href={`tel:${phone}`} className="flex items-center space-x-4 p-4 rounded-xl border border-gray-100 hover:bg-indigo-50 hover:border-indigo-100 transition-colors group">
                <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-500 flex items-center justify-center group-hover:bg-indigo-100">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-0.5">Phone</p>
                  <p className="font-medium text-gray-900">{phone}</p>
                </div>
              </a>
            )}

            {metadata?.website && (
              <a href={metadata.website.startsWith('http') ? metadata.website : `https://${metadata.website}`} target="_blank" rel="noopener noreferrer" className="flex items-center space-x-4 p-4 rounded-xl border border-gray-100 hover:bg-indigo-50 hover:border-indigo-100 transition-colors group">
                <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-500 flex items-center justify-center group-hover:bg-indigo-100">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-0.5">Website</p>
                  <p className="font-medium text-gray-900 truncate">{metadata.website}</p>
                </div>
              </a>
            )}
          </div>

          {/* Social Links Layout */}
          {(metadata?.linkedin || metadata?.instagram || metadata?.facebook) && (
            <div className="pt-6 border-t border-gray-100">
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4">Social Links</p>
              <div className="flex justify-center space-x-4">
                {metadata.linkedin && (
                  <a href={metadata.linkedin} target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 hover:text-blue-600 hover:bg-blue-50 hover:border-blue-100 transition-all">
                    <Linkedin className="w-5 h-5" />
                  </a>
                )}
                {metadata.instagram && (
                  <a href={metadata.instagram} target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 hover:text-pink-600 hover:bg-pink-50 hover:border-pink-100 transition-all">
                    <Instagram className="w-5 h-5" />
                  </a>
                )}
                {metadata.facebook && (
                  <a href={metadata.facebook} target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 hover:text-blue-700 hover:bg-blue-50 hover:border-blue-100 transition-all">
                    <Facebook className="w-5 h-5" />
                  </a>
                )}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default BusinessProfile;
