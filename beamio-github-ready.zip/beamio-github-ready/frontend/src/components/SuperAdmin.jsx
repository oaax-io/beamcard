import { useFormik } from 'formik';
import {
  AlertCircle,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  Edit2,
  Loader2,
  Plus,
  Search,
  Store,
  Trash2,
  TrendingUp,
  Users,
  X
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import * as Yup from 'yup';
import { useAdminAllCards } from '../api/hooks/useCards';
import {
  useCompanies,
  useCompanyById,
  useCompanyStats,
  useCreateCompany,
  useDeleteCompany,
  useGlobalStats,
  useUpdateCompany,
  useUpdateCompanyStatus
} from '../api/hooks/useCompanies';
import { useDebounce } from '../hooks/useDebounce';
import { CardsTable } from './CardsTable';
import { CustomersTable } from './CustomersTable';
import { TransactionsTable } from './TransactionsTable';



export const SuperAdminDashboard = () => {
  const { t } = useTranslation();
  const { companyId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState(null);
  const [deletingCompanyId, setDeletingCompanyId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [companiesPage, setCompaniesPage] = useState(1);
  const debouncedSearch = useDebounce(searchTerm, 500);

  // Queries
  const { data: stats, isLoading: statsLoading } = useGlobalStats();
  const { data: companiesResponse, isLoading: companiesLoading } = useCompanies({ search: debouncedSearch, page: companiesPage, limit: 10 });
  const companies = companiesResponse?.data || [];
  const totalCompanies = companiesResponse?.total || 0;
  const companiesLastPage = companiesResponse?.lastPage || 1;

  const { data: cardsResponse, isLoading: cardsLoading } = useAdminAllCards({ page: 1, limit: 10 });
  const cardsLoading2 = false; // handled inside CardsTable

  const { data: selectedCompany, isLoading: companyLoading } = useCompanyById(companyId);
  const { data: companyStats, isLoading: companyStatsLoading } = useCompanyStats(companyId);

  // Mutations
  const createCompanyMutation = useCreateCompany();
  const updateCompanyMutation = useUpdateCompany();
  const deleteCompanyMutation = useDeleteCompany();
  const updateStatusMutation = useUpdateCompanyStatus();

  const isCompaniesView = location.pathname.includes('companies');
  const isCardsView = location.pathname.includes('cards');
  const isDashboardView = !isCompaniesView && !isCardsView && !companyId;

  const formik = useFormik({
    initialValues: editingCompany ? {
      name: editingCompany.name || '',
      uid: editingCompany.uid || '',
      industry: editingCompany.industry || '',
      address: {
        street: editingCompany.address?.street || '',
        houseNumber: editingCompany.address?.houseNumber || '',
        postalCode: editingCompany.address?.postalCode || '',
        city: editingCompany.address?.city || '',
        country: editingCompany.address?.country || 'Switzerland',
      },
      contactEmail: editingCompany.contactEmail || '',
      contactPhone: editingCompany.contactPhone || '',
    } : {
      name: '',
      uid: '',
      industry: '',
      address: {
        street: '',
        houseNumber: '',
        postalCode: '',
        city: '',
        country: 'Switzerland',
      },
      contactEmail: '',
      contactPhone: '',
    },
    enableReinitialize: true,
    validationSchema: Yup.object({
      name: Yup.string().min(3, t('too_short')).required(t('required')),
      uid: Yup.string().matches(/^CHE-\d{3}\.\d{3}\.\d{3}$/, t('invalid_uid_format')).required(t('required')),
      industry: Yup.string(),
      contactEmail: Yup.string().email(t('invalid_email')),
      contactPhone: Yup.string(),
      address: Yup.object({
        street: Yup.string().required(t('required')),
        houseNumber: Yup.string().required(t('required')),
        postalCode: Yup.string().required(t('required')),
        city: Yup.string().required(t('required')),
        country: Yup.string().required(t('required')),
      })
    }),
    onSubmit: (values, { resetForm }) => {
      const mutation = editingCompany ? updateCompanyMutation : createCompanyMutation;
      const data = {
        ...values,
        id: editingCompany?.id || editingCompany?._id,
        type: 'loyalty',
        logo: values.logo || `https://picsum.photos/seed/${values.name}/200/200`
      };

      mutation.mutate(data, {
        onSuccess: () => {
          toast.success(t(editingCompany ? 'company_updated' : 'company_success'));
          setIsModalOpen(false);
          setEditingCompany(null);
          resetForm();
        },
        onError: () => {
          toast.error(t(editingCompany ? 'company_update_fail' : 'company_fail'));
        }
      });
    },
  });

  const handleEdit = (company) => {
    setEditingCompany(company);
    setIsModalOpen(true);
  };

  const handleDelete = (id) => {
    setDeletingCompanyId(id);
  };

  const confirmDelete = () => {
    if (!deletingCompanyId) return;

    deleteCompanyMutation.mutate(deletingCompanyId, {
      onSuccess: () => {
        toast.success(t('company_deleted'));
        setDeletingCompanyId(null);
      },
      onError: (error) => {
        console.error('Delete failed:', error);
        toast.error(t('delete_fail'));
        setDeletingCompanyId(null);
      }
    });
  };

  const handleToggleStatus = (id, currentStatus) => {
    const newStatus = currentStatus === 'active' ? 'suspended' : 'active';
    updateStatusMutation.mutate({ id, status: newStatus }, {
      onSuccess: () => {
        toast.success(t(newStatus === 'active' ? 'company_activated' : 'company_suspended'));
      },
      onError: () => {
        toast.error(t('status_update_fail'));
      }
    });
  };

  const isLoadingData = statsLoading || companiesLoading ||
    (companyId && (companyLoading || companyStatsLoading));

  if (isLoadingData) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (companyId && selectedCompany) {
    return (
      <div className="p-6 space-y-8 bg-gray-50 dark:bg-gray-950 min-h-full transition-colors duration-300">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/admin/companies')} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5 dark:text-gray-400" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{selectedCompany.name}</h1>
            <p className="text-gray-500 dark:text-gray-400">{t('company_details')}</p>
          </div>
        </div>

        {companyStats && (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm">
              <p className="text-sm text-gray-500 dark:text-gray-400">{t('total_customers')}</p>
              <p className="text-2xl font-bold dark:text-white">{companyStats.totalCustomers}</p>
            </div>
            <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm">
              <p className="text-sm text-gray-500 dark:text-gray-400">{t('total_cards')}</p>
              <p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">{companyStats.totalCards}</p>
            </div>
            <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm">
              <p className="text-sm text-gray-500 dark:text-gray-400">{t('total_points')}</p>
              <p className="text-2xl font-bold text-green-600 dark:text-green-400">{companyStats.totalPointsIssued}</p>
            </div>
            <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm">
              <p className="text-sm text-gray-500 dark:text-gray-400">{t('total_points_redeemed')}</p>
              <p className="text-2xl font-bold text-red-600 dark:text-red-400">{companyStats.totalPointsRedeemed}</p>
            </div>
            <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm">
              <p className="text-sm text-gray-500 dark:text-gray-400">{t('current_liability')}</p>
              <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">{companyStats.currentLiability}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm p-6">
            <h2 className="text-lg font-bold mb-4 dark:text-white">{t('information')}</h2>
            <div className="space-y-3">
              <div className="flex justify-between border-b border-gray-50 dark:border-gray-800 pb-2">
                <span className="text-gray-500">{t('uid')}</span>
                <span className="font-medium dark:text-gray-200">{selectedCompany.uid}</span>
              </div>
              <div className="flex justify-between border-b border-gray-50 dark:border-gray-800 pb-2">
                <span className="text-gray-500">{t('industry')}</span>
                <span className="font-medium dark:text-gray-200">{selectedCompany.industry || '-'}</span>
              </div>
              <div className="flex justify-between border-b border-gray-50 dark:border-gray-800 pb-2">
                <span className="text-gray-500">{t('contact_email')}</span>
                <span className="font-medium dark:text-gray-200">{selectedCompany.contactEmail || '-'}</span>
              </div>
              <div className="flex justify-between border-b border-gray-50 dark:border-gray-800 pb-2">
                <span className="text-gray-500">{t('contact_phone')}</span>
                <span className="font-medium dark:text-gray-200">{selectedCompany.contactPhone || '-'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">{t('status')}</span>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${selectedCompany.status === 'active' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                  }`}>
                  {t(selectedCompany.status)}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm p-6">
            <h2 className="text-lg font-bold mb-4 dark:text-white">{t('address')}</h2>
            <div className="space-y-1">
              <p className="font-medium dark:text-gray-200">{selectedCompany.address?.street} {selectedCompany.address?.houseNumber}</p>
              <p className="dark:text-gray-400">{selectedCompany.address?.postalCode} {selectedCompany.address?.city}</p>
              <p className="dark:text-gray-400">{selectedCompany.address?.country}</p>
            </div>
          </div>
        </div>

        <CustomersTable companyId={companyId} />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8 bg-gray-50 dark:bg-gray-950 min-h-full transition-colors duration-300">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {isCardsView ? t('cards') : (isCompaniesView ? t('companies_management') : t('dashboard'))}
          </h1>
          <p className="text-gray-500 dark:text-gray-400">{isCompaniesView ? t('manage_companies_desc') : t('welcome') + ', ' + t('superadmin')}</p>
        </div>
        {isCompaniesView && (
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative group">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder={t('search_companies')}
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCompaniesPage(1);
                  }}
                  className="pl-10 pr-10 py-2 bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white w-full sm:w-64"
                />
                {searchTerm && (
                  <button
                    onClick={() => { setSearchTerm(''); setCompaniesPage(1); }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <button
                onClick={() => {
                  setEditingCompany(null);
                  setIsModalOpen(true);
                }}
                className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-xl font-medium transition-all shadow-lg shadow-indigo-200 dark:shadow-none"
              >
                <Plus className="w-4 h-4" />
                {t('create_company')}
              </button>
            </div>
        )}
      </div>

      {isDashboardView && stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl transition-colors">
              <Store className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            </div>
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">{t('total_companies')}</p>
              <p className="text-2xl font-bold dark:text-white">{stats.totalCompanies}</p>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-xl transition-colors">
              <Users className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">{t('total_customers')}</p>
              <p className="text-2xl font-bold dark:text-white">{stats.totalCustomers}</p>
            </div>
          </div>
          <div className="bg-white dark:bg-gray-900 p-6 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-amber-100 dark:bg-amber-900/30 rounded-xl transition-colors">
              <TrendingUp className="w-6 h-6 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400">{t('total_points')}</p>
              <p className="text-2xl font-bold dark:text-white">{stats.totalPointsIssued}</p>
            </div>
          </div>
        </div>
      )}

      {(isDashboardView || isCompaniesView) && (
        <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center">
            <h2 className="text-lg font-bold dark:text-white">{t('companies')}</h2>
            {isDashboardView && <Link to="/admin/companies" className="text-indigo-600 dark:text-indigo-400 text-sm font-medium hover:underline">{t('view_all')}</Link>}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 dark:bg-gray-800/50 text-xs uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400">
                <tr>
                  <th className="px-6 py-3">{t('company_name')}</th>
                  <th className="px-6 py-3">{t('uid')}</th>
                  <th className="px-6 py-3">{t('city')}</th>
                  <th className="px-6 py-3">{t('status')}</th>
                  <th className="px-6 py-3">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {(isDashboardView ? companies.slice(0, 5) : companies).map((company) => (
                  <tr key={company.id || company._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors cursor-pointer" onClick={() => navigate(`/admin/companies/${company.id || company._id}`)}>
                    <td className="px-6 py-4 flex items-center gap-3">
                      <img src={company.logo} className="w-10 h-10 rounded-xl object-cover shadow-sm" referrerPolicy="no-referrer" />
                      <span className="font-medium dark:text-gray-200">{company.name}</span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400 font-mono">{company.uid}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{company.address?.city}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${company.status === 'active' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                        }`}>
                        {t(company.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleStatus(company.id || company._id, company.status);
                          }}
                          className={`text-xs font-bold px-2 py-1 rounded-lg ${company.status === 'active' ? 'text-amber-600 bg-amber-50 hover:bg-amber-100' : 'text-green-600 bg-green-50 hover:bg-green-100'}`}
                        >
                          {company.status === 'active' ? t('suspend') : t('activate')}
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEdit(company);
                          }}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title={t('edit')}
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            console.log('[SuperAdmin] Delete button clicked');
                            e.preventDefault();
                            e.stopPropagation();
                            const targetId = company.id || company._id;
                            console.log('[SuperAdmin] Target ID:', targetId);
                            handleDelete(targetId);
                          }}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title={t('delete')}
                        >
                          <Trash2 className="w-4 h-4 pointer-events-none" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!isDashboardView && totalCompanies > 0 && (
            <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-4 p-4 border-t border-gray-100 dark:border-gray-800">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {t('showing')} <span className="font-medium">{(companiesPage - 1) * 10 + 1}</span> - <span className="font-medium">{Math.min(companiesPage * 10, totalCompanies)}</span> {t('of')} <span className="font-medium">{totalCompanies}</span> {t('companies')}
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCompaniesPage(p => Math.max(1, p - 1))}
                  disabled={companiesPage === 1}
                  className="p-2 rounded-lg border border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 disabled:opacity-50 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 dark:text-gray-300" />
                </button>
                <div className="flex items-center gap-1">
                  {[...Array(companiesLastPage)].map((_, i) => (
                    <button
                      key={i + 1}
                      onClick={() => setCompaniesPage(i + 1)}
                      className={`w-8 h-8 rounded-lg text-sm font-medium transition-colors ${companiesPage === i + 1 ? 'bg-indigo-600 text-white' : 'hover:bg-gray-50 dark:hover:bg-gray-800 dark:text-gray-300'}`}
                    >
                      {i + 1}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setCompaniesPage(p => Math.min(companiesLastPage, p + 1))}
                  disabled={companiesPage === companiesLastPage}
                  className="p-2 rounded-lg border border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 disabled:opacity-50 transition-colors"
                >
                  <ChevronRight className="w-4 h-4 dark:text-gray-300" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {(isDashboardView || isCardsView) && (
        <CardsTable
          showCompanyCol
          headerTitle={isCardsView ? t('cards') : undefined}
        />
      )}

      {isDashboardView && (
        <TransactionsTable showCompanyCol />
      )}

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-2xl w-full p-8 border border-gray-100 dark:border-gray-800 my-8"
            >
              <h2 className="text-2xl font-bold mb-6 dark:text-white">
                {editingCompany ? t('edit_company') : t('create_company')}
              </h2>
              <form onSubmit={formik.handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Company Section */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-semibold uppercase tracking-wider text-gray-400">{t('company_info')}</h3>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('company_name')}</label>
                      <input
                        {...formik.getFieldProps('name')}
                        className={`w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border ${formik.touched.name && formik.errors.name ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white`}
                      />
                      {formik.touched.name && formik.errors.name && <p className="text-red-500 text-xs mt-1">{formik.errors.name}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('uid')} (CHE-123.456.789)</label>
                      <input
                        {...formik.getFieldProps('uid')}
                        placeholder="CHE-121.212.121"
                        className={`w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border ${formik.touched.uid && formik.errors.uid ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white text-sm font-mono`}
                      />
                      {formik.touched.uid && formik.errors.uid && <p className="text-red-500 text-xs mt-1">{formik.errors.uid}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('industry')} ({t('optional')})</label>
                      <input
                        {...formik.getFieldProps('industry')}
                        className="w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('contact_email')}</label>
                      <input
                        type="email"
                        {...formik.getFieldProps('contactEmail')}
                        className={`w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border ${formik.touched.contactEmail && formik.errors.contactEmail ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white`}
                      />
                      {formik.touched.contactEmail && formik.errors.contactEmail && <p className="text-red-500 text-xs mt-1">{formik.errors.contactEmail}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        {t('contact_phone')}
                      </label>
                      <PhoneInput
                        international
                        defaultCountry="CH"
                        value={formik.values.contactPhone}
                        onChange={(val) => formik.setFieldValue('contactPhone', val)}
                        className={`phone-input-container ${formik.touched.contactPhone && formik.errors.contactPhone ? 'phone-input-error' : ''}`}
                      />
                    </div>
                  </div>

                  {/* Address Section */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-semibold uppercase tracking-wider text-gray-400">{t('address')}</h3>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="col-span-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('street')}</label>
                        <input
                          {...formik.getFieldProps('address.street')}
                          className={`w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border ${formik.touched.address?.street && formik.errors.address?.street ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white`}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('no')}</label>
                        <input
                          {...formik.getFieldProps('address.houseNumber')}
                          className={`w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border ${formik.touched.address?.houseNumber && formik.errors.address?.houseNumber ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white`}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('zip')}</label>
                        <input
                          {...formik.getFieldProps('address.postalCode')}
                          className={`w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border ${formik.touched.address?.postalCode && formik.errors.address?.postalCode ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white`}
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('city')}</label>
                        <input
                          {...formik.getFieldProps('address.city')}
                          className={`w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border ${formik.touched.address?.city && formik.errors.address?.city ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white`}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('country')}</label>
                      <input
                        {...formik.getFieldProps('address.country')}
                        className={`w-full px-4 py-2.5 bg-gray-50 dark:bg-gray-800 border ${formik.touched.address?.country && formik.errors.address?.country ? 'border-red-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all dark:text-white`}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-6 border-t border-gray-100 dark:border-gray-800">
                  <button
                    type="button"
                    onClick={() => {
                      setIsModalOpen(false);
                      setEditingCompany(null);
                    }}
                    className="flex-1 py-3 px-4 border border-gray-300 dark:border-gray-700 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    {t('cancel')}
                  </button>
                  <button
                    type="submit"
                    disabled={createCompanyMutation.isPending || updateCompanyMutation.isPending}
                    className="flex-1 py-3 px-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-500/20 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {(createCompanyMutation.isPending || updateCompanyMutation.isPending) && <Loader2 className="w-4 h-4 animate-spin" />}
                    {t('save')}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {deletingCompanyId && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-gray-900 rounded-3xl shadow-2xl max-w-md w-full p-8 border border-gray-100 dark:border-gray-800"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-2xl">
                  <AlertCircle className="w-6 h-6 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <h3 className="text-xl font-bold dark:text-white">{t('confirm_delete')}</h3>
                  <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">{t('confirm_delete_company')}</p>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setDeletingCompanyId(null)}
                  className="flex-1 py-3 px-4 border border-gray-300 dark:border-gray-700 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors font-medium"
                >
                  {t('cancel')}
                </button>
                <button
                  onClick={confirmDelete}
                  disabled={deleteCompanyMutation.isPending}
                  className="flex-1 py-3 px-4 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-500/20 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {deleteCompanyMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
                  {t('delete')}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
