import axios from 'axios';
import secureLocalStorage from 'react-secure-storage';

// API base URL: from build env, or infer from current host so login/auth always hit the API
// @ts-ignore
const BASE_URL =
  import.meta.env.VITE_API_URL ||
  (typeof window !== 'undefined' && window.location.hostname === 'demo.beamcard.ch'
    ? 'https://api.beamcard.ch'
    : 'http://localhost:3001');

export const api = axios.create({
  baseURL: BASE_URL,
  withCredentials: true, // Crucial for sending/receiving HttpOnly cookies (refresh token)
});

// A flag to prevent multiple refresh calls simultaneously
let isRefreshing = false;
let failedQueue: { resolve: (value?: unknown) => void; reject: (reason?: any) => void }[] = [];

const processQueue = (error: any, token: string | null = null) => {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(token);
    }
  });
  failedQueue = [];
};

// Request Interceptor: Attach Access Token
api.interceptors.request.use(
  (config) => {
    const token = secureLocalStorage.getItem('accessToken') as string;
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response Interceptor: Handle 401s and Token Rotation
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // Only intercept 401s where we actually sent an auth header,
    // and prevent infinite loops by checking `_retry`
    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        // If already refreshing, wait for the new token
        try {
          const token = await new Promise<string>((resolve, reject) => {
            failedQueue.push({ resolve, reject });
          });
          originalRequest.headers['Authorization'] = `Bearer ${token}`;
          return api(originalRequest);
        } catch (err) {
          return Promise.reject(err);
        }
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        // The refresh endpoint relies on the HttpOnly cookie being sent automatically
        const { data } = await axios.post(
          `${BASE_URL}/auth/refresh`,
          {},
          { withCredentials: true }
        );

        const newAccessToken = data.accessToken;
        secureLocalStorage.setItem('accessToken', newAccessToken);

        // Optional: Update user session data here if needed
        secureLocalStorage.setItem('user', JSON.stringify(data.user));

        processQueue(null, newAccessToken);
        
        originalRequest.headers['Authorization'] = `Bearer ${newAccessToken}`;
        return api(originalRequest);
      } catch (err) {
        processQueue(err, null);
        
        // Force logout / redirect on refresh failure
        secureLocalStorage.removeItem('accessToken');
        secureLocalStorage.removeItem('user');
        window.location.href = '/'; // Or trigger a specific auth context logout function

        return Promise.reject(err);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);
