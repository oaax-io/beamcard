import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../../db';

export const useSubscriptionPlans = () => {
  return useQuery({
    queryKey: ['subscription-plans'],
    queryFn: api.getSubscriptionPlans,
  });
};

export const useMySubscription = () => {
  return useQuery({
    queryKey: ['my-subscription'],
    queryFn: api.getMySubscription,
  });
};

export const usePlanConfig = () => {
  return useQuery({
    queryKey: ['plan-config'],
    queryFn: api.getPlanConfig,
  });
};

export const useUpdatePlanConfig = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: api.updatePlanConfig,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['plan-config'] });
    },
  });
};

export const useCreateCheckoutSession = () => {
  return useMutation({
    mutationFn: (planId) => api.createCheckoutSession(planId),
    onSuccess: ({ url }) => {
      window.location.href = url;
    },
  });
};
