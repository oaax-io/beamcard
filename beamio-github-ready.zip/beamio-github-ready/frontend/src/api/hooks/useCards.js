import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../../db';

export const useCards = (params = {}, options = {}) => {
  return useQuery({
    queryKey: ['cards', params],
    queryFn: () => api.getCards(params),
    ...options,
  });
};

export const useCardsByUserId = (userId) => {
  return useQuery({
    queryKey: ['user-cards', userId],
    queryFn: () => api.getCardsByUserId(userId),
    enabled: !!userId,
  });
};

export const useCreateCard = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (cardData) => api.createCard(cardData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cards'] });
      queryClient.invalidateQueries({ queryKey: ['admin-all-cards'] });
    },
  });
};

export const useDeleteCustomer = () => {
  const queryClient = useQueryClient();
  return useMutation({
    // cardIds: all card ids of the customer, userId: the user id
    mutationFn: async ({ cardIds, userId }) => {
      await Promise.all(cardIds.map(id => api.deleteCard(id)));
      await api.deleteUser(userId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cards'] });
      queryClient.invalidateQueries({ queryKey: ['admin-all-cards'] });
    },
  });
};

export const useUpdateCustomer = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ userId, data }) => api.updateUser(userId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['cards'] });
      queryClient.invalidateQueries({ queryKey: ['admin-all-cards'] });
    },
  });
};

export const useAwardPoints = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ cardId, amount, note }) => api.awardPoints(cardId, amount, note),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['cards'] });
      queryClient.invalidateQueries({ queryKey: ['admin-all-cards'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      queryClient.invalidateQueries({ queryKey: ['company-stats', data.card.companyId] });
    },
  });
};

export const useRedeemPoints = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ cardId, amount, note }) => api.redeemPoints(cardId, amount, note),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['cards'] });
      queryClient.invalidateQueries({ queryKey: ['admin-all-cards'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      queryClient.invalidateQueries({ queryKey: ['company-stats', data.card.companyId] });
    },
  });
};

export const useTransactions = (params = {}, options = {}) => {
  return useQuery({
    queryKey: ['transactions', params],
    queryFn: () => api.getTransactions(params),
    ...options,
  });
};

export const useAdminAllCards = (params = {}, options = {}) => {
  return useQuery({
    queryKey: ['admin-all-cards', params],
    queryFn: () => api.adminGetAllCards(params),
    ...options,
  });
};

export const useUniqueCustomers = (params = {}, options = {}) => {
  return useQuery({
    queryKey: ['unique-customers', params],
    queryFn: () => api.getUniqueCustomers(params),
    ...options,
  });
};

export const useEnrollCustomer = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ programId, customerData }) => api.enrollCustomerInProgram(programId, customerData),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['cards', data.card.companyId] });
      queryClient.invalidateQueries({ queryKey: ['user-cards', data.card.userId] });
    },
  });
};

export const useSaveLink = () => {
  return useMutation({
    mutationFn: (cardId) => api.generateSaveLink(cardId),
  });
};
