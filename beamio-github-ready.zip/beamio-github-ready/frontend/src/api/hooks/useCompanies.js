import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../../db';

export const useCompanies = (params = {}) => {
  return useQuery({
    queryKey: ['companies', params],
    queryFn: () => api.getCompanies(params),
  });
};

export const useCompanyById = (companyId) => {
  return useQuery({
    queryKey: ['companies', companyId],
    queryFn: () => api.getCompanyById(companyId),
    enabled: !!companyId,
  });
};

export const useCreateCompany = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (companyData) => api.createCompany(companyData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      queryClient.invalidateQueries({ queryKey: ['global-stats'] });
    },
  });
};

export const useUpdateCompanyStatus = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }) => api.updateCompanyStatus(id, status),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      queryClient.invalidateQueries({ queryKey: ['companies', data.id] });
    },
  });
};

export const useUpdateCompany = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...data }) => api.updateCompany(id, data),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      queryClient.invalidateQueries({ queryKey: ['companies', data.id || data._id] });
    },
  });
};

export const useDeleteCompany = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id) => api.deleteCompany(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      queryClient.invalidateQueries({ queryKey: ['global-stats'] });
    },
  });
};

export const useCompanyStats = (companyId) => {
  return useQuery({
    queryKey: ['company-stats', companyId],
    queryFn: () => api.getCompanyStats(companyId),
    enabled: !!companyId,
  });
};

export const useGlobalStats = () => {
  return useQuery({
    queryKey: ['global-stats'],
    queryFn: api.getGlobalStats,
  });
};
