import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '../../db';

export const useCardPrograms = (params = {}, options = {}) => {
  return useQuery({
    queryKey: ['programs', params],
    queryFn: () => api.getCardPrograms(params),
    ...options,
  });
};

export const useProgramById = (programId) => {
  return useQuery({
    queryKey: ['program', programId],
    queryFn: () => api.getProgramById(programId),
    enabled: !!programId,
  });
};

export const useCreateCardProgram = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (programData) => api.createCardProgram(programData),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['programs', data.companyId] });
    },
  });
};

export const useProgramShareLink = () => {
  return useMutation({
    mutationFn: (programId) => api.generateProgramShareLink(programId),
  });
};
