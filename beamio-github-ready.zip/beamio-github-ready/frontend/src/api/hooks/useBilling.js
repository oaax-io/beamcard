import { useQuery } from '@tanstack/react-query';
import { api } from '../axios';

export const useAdminBillingTransactions = ({ page = 1, limit = 10 }) => {
  return useQuery({
    queryKey: ['admin-billing-transactions', { page, limit }],
    queryFn: async () => {
      const response = await api.get('/stripe/admin/billing-transactions', {
        params: { page, limit },
      });
      return response.data;
    },
    keepPreviousData: true,
  });
};

export const useUserBillingTransactions = ({ page = 1, limit = 10 }) => {
  return useQuery({
    queryKey: ['user-billing-transactions', { page, limit }],
    queryFn: async () => {
      const response = await api.get('/stripe/my-billing-transactions', {
        params: { page, limit },
      });
      return response.data;
    },
    keepPreviousData: true,
  });
};
