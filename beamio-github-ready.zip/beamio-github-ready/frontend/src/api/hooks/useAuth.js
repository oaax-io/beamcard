import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../../db';

export const useLogin = (onSuccess) => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: ({ email, password }) => api.login(email, password),
    onSuccess: (data) => {
      if (onSuccess) onSuccess(data);
    },
  });
};
