import { QueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      cacheTime: 1000 * 60 * 30, // 30 minutes
      retry: 1,
      refetchOnWindowFocus: false,
      onError: (error) => {
        toast.error(error.message || 'Something went wrong');
      },
    },
    mutations: {
      onError: (error) => {
        toast.error(error.message || 'Action failed');
      },
    },
  },
});
