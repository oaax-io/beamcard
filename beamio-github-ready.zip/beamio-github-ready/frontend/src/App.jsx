import React from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { Navigate, Route, Routes } from 'react-router-dom';
import { queryClient } from './api/queryClient';
import { CustomerDashboard } from './components/Customer';
import { CustomerEnroll } from './components/CustomerEnroll';
import { Navbar, Sidebar } from './components/Layout';
import { LoginPage } from './components/Login';
import { SubscriptionPlans } from './components/SubscriptionPlans';
import { SuperAdminDashboard } from './components/SuperAdmin';
import { SuperAdminUsers } from './components/Users';
import { CustomersTable } from './components/CustomersTable';
import { BusinessProfile } from './components/BusinessProfile';
import { PricingConfig } from './components/PricingConfig';
import { AdminBillingTransactions } from './components/AdminBillingTransactions';
import { UserBillingTransactions } from './components/UserBillingTransactions';

const AdminCustomersPage = () => {
  const { t } = useTranslation();
  return (
    <div className="p-6 space-y-6 bg-gray-50 dark:bg-gray-950 min-h-full">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('customers')}</h1>
        <p className="text-gray-500 dark:text-gray-400">{t('all_customers_desc')}</p>
      </div>
      <CustomersTable showCompanyCol />
    </div>
  );
};
import { CardTypeSelection, TenantDashboard, TenantCardsPage } from './components/Tenant';
import { TemplatesPage } from './components/TemplatesPage';
import { ROLES } from './db';
import { useAuthStore } from './store/authStore';

const AppLayout = ({ user, logout, isSidebarOpen, toggleSidebar, theme, toggleTheme }) => (
  <>
    <Navbar user={user} onLogout={logout} toggleSidebar={toggleSidebar} isSidebarOpen={isSidebarOpen} theme={theme} toggleTheme={toggleTheme} />
    <div className="flex">
      {user && <Sidebar role={user.role} isOpen={isSidebarOpen} />}
      <main className="flex-1 min-h-[calc(100vh-64px)] overflow-y-auto">
        <Routes>
          <Route path="/" element={<Navigate to={user ? (user.role === ROLES.SUPERADMIN ? '/admin' : ([ROLES.TENANT, ROLES.ADMIN].includes(user.role) ? '/tenant' : '/customer')) : '/login'} replace />} />
          <Route path="/login" element={user ? <Navigate to="/" replace /> : <LoginPage />} />

          {user?.role === ROLES.SUPERADMIN && (
            <>
              <Route path="/admin" element={<SuperAdminDashboard />} />
              <Route path="/admin/pricing" element={<PricingConfig />} />
              <Route path="/admin/billing" element={<AdminBillingTransactions />} />
              <Route path="/admin/companies" element={<SuperAdminDashboard />} />
              <Route path="/admin/companies/:companyId" element={<SuperAdminDashboard />} />
              <Route path="/admin/cards" element={<SuperAdminDashboard />} />
              <Route path="/admin/users" element={<SuperAdminUsers />} />
              <Route path="/admin/templates" element={<TemplatesPage showCompanyCol />} />
              <Route path="/admin/customers" element={<AdminCustomersPage />} />
              <Route path="/admin/transactions" element={<SuperAdminDashboard />} />
            </>
          )}

          {[ROLES.TENANT, ROLES.ADMIN].includes(user?.role) && (
            <>
              <Route path="/tenant" element={<TenantDashboard user={user} />} />
              <Route path="/tenant/customers" element={<TenantDashboard user={user} />} />
              <Route path="/tenant/transactions" element={<TenantDashboard user={user} />} />
              <Route path="/tenant/cards-list" element={<TenantCardsPage user={user} />} />
              <Route path="/tenant/templates" element={<TemplatesPage companyId={user.companyId} />} />
              <Route path="/tenant/cards" element={<CardTypeSelection />} />
              <Route path="/tenant/subscription" element={<SubscriptionPlans />} />
              <Route path="/tenant/billing" element={<UserBillingTransactions />} />
            </>
          )}

          {user?.role === ROLES.CUSTOMER && (
            <>
              <Route path="/customer" element={<CustomerDashboard user={user} />} />
              <Route path="/customer/history" element={<CustomerDashboard user={user} />} />
            </>
          )}

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  </>
);

export default function App() {
  const { i18n } = useTranslation();
  const { user, logout } = useAuthStore();
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(true);
  const [theme, setTheme] = React.useState(localStorage.getItem('beamcard_theme') || 'light');

  React.useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('beamcard_theme', theme);
  }, [theme]);

  React.useEffect(() => {
    document.dir = i18n.language === 'ar' ? 'rtl' : 'ltr';
  }, [i18n.language]);

  const toggleSidebar = () => setIsSidebarOpen(p => !p);
  const toggleTheme = () => setTheme(p => p === 'light' ? 'dark' : 'light');

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 font-sans text-gray-900 dark:text-gray-100 transition-colors duration-300">
        <Toaster position="top-right" />
        <Routes>
          {/* Public standalone — no navbar/sidebar */}
          <Route path="/enroll/:programId" element={<CustomerEnroll />} />
          <Route path="/profile/:objectId" element={<BusinessProfile />} />
          <Route path="/profile/template/:objectId" element={<BusinessProfile />} />
          {/* All other routes with layout */}
          <Route path="*" element={<AppLayout user={user} logout={logout} isSidebarOpen={isSidebarOpen} toggleSidebar={toggleSidebar} theme={theme} toggleTheme={toggleTheme} />} />
        </Routes>
      </div>
    </QueryClientProvider>
  );
}
