import { create } from 'zustand';
import secureLocalStorage from 'react-secure-storage';

// Initialize from secure storage
const getInitialUser = () => {
  const savedUser = secureLocalStorage.getItem('user');
  if (savedUser) {
    try {
      // In case it was stored as string
      const parsed = typeof savedUser === 'string' ? JSON.parse(savedUser) : savedUser;
      if (parsed && typeof parsed.role === 'string') {
        parsed.role = parsed.role.toUpperCase();
      }
      return parsed;
    } catch (e) {
      if (typeof savedUser === 'object' && savedUser?.role) {
        savedUser.role = savedUser.role.toUpperCase();
      }
      return savedUser;
    }
  }
  return null;
};

export const useAuthStore = create((set) => ({
  user: getInitialUser(),
  login: (userData, accessToken) => {
    const normalizedUser = { ...userData, role: userData.role?.toUpperCase() };
    secureLocalStorage.setItem('user', JSON.stringify(normalizedUser));
    if (accessToken) {
      secureLocalStorage.setItem('accessToken', accessToken);
    }
    set({ user: normalizedUser });
  },
  logout: async () => {
    try {
      const { api } = await import('../db');
      await api.logout();
    } catch (e) {
      console.error('Logout API call failed', e);
    }
    secureLocalStorage.removeItem('user');
    secureLocalStorage.removeItem('accessToken');
    set({ user: null });
  },
  setUser: (userData) => {
    const normalizedUser = { ...userData, role: userData.role?.toUpperCase() };
    secureLocalStorage.setItem('user', JSON.stringify(normalizedUser));
    set({ user: normalizedUser });
  }
}));
