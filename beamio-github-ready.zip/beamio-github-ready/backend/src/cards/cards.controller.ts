import { Controller, Get, Post, Body, Param, Put, Delete, UseGuards, Query, ParseIntPipe, DefaultValuePipe } from '@nestjs/common';
import { CardsService } from './cards.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Public } from '../common/decorators/public.decorator';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery, ApiOkResponse, ApiCreatedResponse, ApiParam, ApiBody } from '@nestjs/swagger';
import { CreateCardDto, UpdateCardDto } from './dto/create-card.dto';

@ApiTags('Cards (Instances)')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('cards')
export class CardsController {
  constructor(private readonly cardsService: CardsService) {}

  @Get('unique-customers')
  @ApiOperation({ summary: 'Get unique customers with their cards', description: 'Retrieve a paginated list of customers who have at least one card, showing their profile and linked cards.' })
  @ApiOkResponse({ description: 'List of customers and their cards retrieved successfully' })
  @ApiQuery({ name: 'page', required: false, type: Number, example: 1 })
  @ApiQuery({ name: 'limit', required: false, type: Number, example: 10 })
  @ApiQuery({ name: 'companyId', required: false, type: String, example: '60d21b4667d0d8992e610c85' })
  @ApiQuery({ name: 'search', required: false, type: String, example: 'John' })
  findAllCustomers(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(10), ParseIntPipe) limit: number,
    @Query('companyId') companyId?: string,
    @Query('search') search?: string,
  ) {
    return this.cardsService.findAllCustomers(companyId, page, limit, search);
  }

  @Get()
  @ApiOperation({ summary: 'Get all card instances', description: 'Retrieve a paginated list of all physical or digital card instances.' })
  @ApiOkResponse({ description: 'List of card instances retrieved successfully' })
  @ApiQuery({ name: 'page', required: false, type: Number, example: 1 })
  @ApiQuery({ name: 'limit', required: false, type: Number, example: 20 })
  @ApiQuery({ name: 'companyId', required: false, type: String, example: '60d21b4667d0d8992e610c85' })
  @ApiQuery({ name: 'userId', required: false, type: String, example: '60d21b4667d0d8992e610c86' })
  @ApiQuery({ name: 'search', required: false, type: String, example: 'Gold' })
  @ApiQuery({ name: 'type', required: false, type: String, example: 'loyalty', description: 'Filter by card type: loyalty, business_card, flight, offer' })
  findAll(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(10), ParseIntPipe) limit: number,
    @Query('companyId') companyId?: string,
    @Query('userId') userId?: string,
    @Query('search') search?: string,
    @Query('type') type?: string,
  ) {
    return this.cardsService.findAll(companyId, userId, page, limit, search, type);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a card instance by ID', description: 'Retrieve detailed information about a specific card instance.' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the card instance' })
  @ApiOkResponse({ description: 'Card instance details retrieved successfully' })
  findOne(@Param('id') id: string) {
    return this.cardsService.findOne(id);
  }

  @Public()
  @Post()
  @ApiOperation({ summary: 'Create a new card instance / Enrollment', description: 'Create a new card instance. Can also be used for customer enrollment where a new user is created if they do not exist.' })
  @ApiBody({ type: CreateCardDto })
  @ApiCreatedResponse({ description: 'Card instance created successfully' })
  create(@Body() dto: CreateCardDto) {
    return this.cardsService.create(dto);
  }

  @Roles('SUPERADMIN', 'TENANT')
  @Put(':id')
  @ApiOperation({ summary: 'Update a card instance', description: 'Modify an existing card instance\'s status or metadata.' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the card instance' })
  @ApiBody({ type: UpdateCardDto })
  @ApiOkResponse({ description: 'Card instance updated successfully' })
  update(@Param('id') id: string, @Body() dto: UpdateCardDto) {
    return this.cardsService.update(id, dto as any);
  }

  @Roles('SUPERADMIN', 'TENANT')
  @Delete(':id')
  @ApiOperation({ summary: 'Delete a card instance', description: 'Remove a card instance record.' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the card instance' })
  @ApiOkResponse({ description: 'Card instance deleted successfully' })
  remove(@Param('id') id: string) {
    return this.cardsService.remove(id);
  }
}
