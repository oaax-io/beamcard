import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { CardProgramsService } from '../card-programs/card-programs.service';
import { DemoLoyaltyService } from '../loyalty/demo-loyalty.service';
import { CardInstance, CardInstanceDocument } from '../schemas/card-instance.schema';
import { UsersService } from '../users/users.service';
import { BusinessCardsService } from '../business-cards/business-cards.service';

@Injectable()
export class CardsService {
  constructor(
    @InjectModel(CardInstance.name) private cardInstanceModel: Model<CardInstanceDocument>,
    private readonly usersService: UsersService,
    private readonly cardProgramsService: CardProgramsService,
    private readonly demoLoyaltyService: DemoLoyaltyService,
    private readonly businessCardsService: BusinessCardsService,
    private readonly configService: ConfigService,
  ) {}

  async findAllCustomers(companyId?: string, page: number = 1, limit: number = 10, search?: string) {
    const skip = (page - 1) * limit;

    const match: any = {};
    if (companyId) {
      // In aggregation pipelines, Mongoose won't auto-coerce strings to ObjectIds.
      // Use $in to cover both possible storage formats (ObjectId or string).
      try {
        match.companyId = { $in: [new Types.ObjectId(companyId), companyId] };
      } catch {
        match.companyId = companyId;
      }
    }

    // Initial pipeline: match cards, then convert userId to ObjectId to ensure $lookup works
    // regardless of whether userId was stored as a string or ObjectId.
    const pipeline: any[] = [
      { $match: match },
      {
        $addFields: {
          userObjId: {
            $cond: {
              if: { $eq: [{ $type: '$userId' }, 'objectId'] },
              then: '$userId',
              else: { $toObjectId: '$userId' },
            },
          },
        },
      },
      {
        $lookup: {
          from: 'users',
          localField: 'userObjId',
          foreignField: '_id',
          as: 'userDoc',
        },
      },
      { $unwind: { path: '$userDoc', preserveNullAndEmptyArrays: true } },
    ];

    // Apply search filter if provided
    if (search) {
      pipeline.push({
        $match: {
          $or: [
            { 'userDoc.firstName': { $regex: search, $options: 'i' } },
            { 'userDoc.lastName': { $regex: search, $options: 'i' } },
            { 'userDoc.email': { $regex: search, $options: 'i' } },
            { 'userDoc.phone': { $regex: search, $options: 'i' } },
          ],
        },
      });
    }

    // Group by userId to get unique customers
    const groupPipeline = [
      ...pipeline,
      {
        $group: {
          _id: '$userId',
          latestCardDate: { $max: '$createdAt' },
          firstName: { $first: '$userDoc.firstName' },
          lastName: { $first: '$userDoc.lastName' },
          email: { $first: '$userDoc.email' },
          phone: { $first: '$userDoc.phone' },
        },
      },
      { $sort: { latestCardDate: -1 } },
    ];

    // Get total count of unique customers
    const countResult = await this.cardInstanceModel.aggregate([...groupPipeline, { $count: 'total' }]).exec();
    const total = countResult[0]?.total ?? 0;

    // Get paginated unique customers
    const paginatedGroups = await this.cardInstanceModel
      .aggregate([...groupPipeline, { $skip: skip }, { $limit: limit }])
      .exec();

    // For each paginated customer, fetch all their cards for this company
    const data = await Promise.all(
      paginatedGroups.map(async (group) => {
        const customerCards = await this.cardInstanceModel
          .find({ userId: group._id, ...(companyId ? { companyId } : {}) })
          .select('-walletIds')
          .populate('programId')
          .populate('companyId', 'name')
          .sort({ createdAt: -1 })
          .exec();

        return {
          userId: group._id,
          firstName: group.firstName || '—',
          lastName: group.lastName || '—',
          email: group.email || '—',
          phone: group.phone || '—',
          cards: customerCards,
        };
      }),
    );

    return {
      data,
      total,
      page,
      lastPage: Math.ceil(total / limit),
    };
  }

  async findAll(companyId?: string, userId?: string, page: number = 1, limit: number = 20, search?: string, type?: string) {
    const skip = (page - 1) * limit;
    if (!search) {
      // Fast path: no search, use simple find + populate
      const filter: any = {};
      if (companyId) filter.companyId = companyId;
      if (userId) filter.userId = userId;

      // Filter by type via programId lookup
      if (type) {
        const programs = await this.cardProgramsService.findAll(companyId, 1, 10000, undefined, type);
        const programIdsStr = programs.data.map(p => String(p._id));
        filter.$expr = {
          $in: [{ $toString: '$programId' }, programIdsStr]
        };
      }

      const [data, total, uniqueCustomers] = await Promise.all([
        this.cardInstanceModel
          .find(filter)
          .populate('programId')
          .populate('userId', 'firstName lastName email phone')
          .populate('companyId', 'name')
          .skip(skip)
          .limit(limit)
          .sort({ createdAt: -1 })
          .exec(),
        this.cardInstanceModel.countDocuments(filter).exec(),
        this.cardInstanceModel.distinct('userId', filter).then(ids => ids.length),
      ]);

      return { data, total, page, lastPage: Math.ceil(total / limit), uniqueCustomers };
    }

    // Search path: aggregate with $lookup so we can filter by user name/email
    const preMatch: any = {};
    if (companyId) preMatch.companyId = new Types.ObjectId(companyId);
    if (userId) preMatch.userId = new Types.ObjectId(userId);

    // Filter by type via programId lookup
    if (type) {
      const programs = await this.cardProgramsService.findAll(companyId, 1, 10000, undefined, type);
      const programIdsObj = programs.data.map(p => new Types.ObjectId(String(p._id)));
      const programIdsStr = programs.data.map(p => String(p._id));
      preMatch.programId = { $in: [...programIdsObj, ...programIdsStr] };
    }

    const pipeline: any[] = [
      ...(Object.keys(preMatch).length ? [{ $match: preMatch }] : []),
      {
        $lookup: {
          from: 'users',
          localField: 'userId',
          foreignField: '_id',
          as: 'userDoc',
        },
      },
      { $unwind: { path: '$userDoc', preserveNullAndEmptyArrays: true } },
      {
        $match: {
          $or: [
            { 'userDoc.firstName': { $regex: search, $options: 'i' } },
            { 'userDoc.lastName': { $regex: search, $options: 'i' } },
            { 'userDoc.email': { $regex: search, $options: 'i' } },
            { 'userDoc.phone': { $regex: search, $options: 'i' } },
          ],
        },
      },
    ];

    const [countResult, data] = await Promise.all([
      this.cardInstanceModel.aggregate([...pipeline, { $count: 'total' }]).exec(),
      this.cardInstanceModel
        .aggregate([
          ...pipeline,
          { $sort: { createdAt: -1 } },
          { $skip: skip },
          { $limit: limit },
          {
            $lookup: {
              from: 'cardtemplates',
              localField: 'programId',
              foreignField: '_id',
              as: 'programId',
            },
          },
          { $unwind: { path: '$programId', preserveNullAndEmptyArrays: true } },
          {
            $lookup: {
              from: 'companies',
              localField: 'companyId',
              foreignField: '_id',
              as: 'companyId',
            },
          },
          { $unwind: { path: '$companyId', preserveNullAndEmptyArrays: true } },
          {
            $addFields: {
              userId: {
                _id: '$userDoc._id',
                firstName: '$userDoc.firstName',
                lastName: '$userDoc.lastName',
                email: '$userDoc.email',
                phone: '$userDoc.phone',
              },
            },
          },
          { $unset: 'userDoc' },
        ])
        .exec(),
    ]);

    const total = countResult[0]?.total ?? 0;
    const uniqueCustomers = await this.cardInstanceModel.distinct('userId', preMatch).then(ids => ids.length);
    return { data, total, page, lastPage: Math.ceil(total / limit), uniqueCustomers };
  }

  async findOne(id: string) {
    const card = await this.cardInstanceModel.findById(id).populate('programId').exec();
    if (!card) throw new NotFoundException('Card instance not found');
    return card;
  }

  async create(cardData: any) {
    // Fetch the program once upfront for all subsequent operations
    const program = cardData.programId
      ? await this.cardProgramsService.findOne(cardData.programId)
      : null;

    // If companyId is missing, it's likely an enrollment from a programId
    if (!cardData.companyId && program) {
      cardData.companyId = program.companyId;
    }

    // Extract additional user data
    const { firstName, lastName, email, phone, birthday, gender, city, userId, ...restData } = cardData;
    const extraUserData = { birthday, gender, city };

    // Handle User creation or update
    if (userId) {
      await this.usersService.update(userId, { firstName, lastName, phone, ...extraUserData });
      cardData.userId = userId;
    } else {
      // Check for existing user by email or phone — reject if already exists
      const byEmail = email ? await this.usersService.findByEmail(email) : null;
      const byPhone = phone ? await this.usersService.findByPhone(phone) : null;

      if (byEmail) throw new ConflictException('email_exists');
      if (byPhone) throw new ConflictException('phone_exists');

      const user = await this.usersService.createCustomer(email, firstName, lastName, phone, extraUserData);
      cardData.userId = String(user._id);
    }

    // Apply welcome bonus from program rules if not already set
    const welcomeBonus = program?.rules?.welcomeBonus || 0;
    if (welcomeBonus > 0 && !cardData.currentBalance) {
      cardData.currentBalance = welcomeBonus;
    }

    const createdCard = new this.cardInstanceModel(cardData);
    const savedCard = await createdCard.save();

    // Generate Google Wallet Link
    if (program) {
      try {
        let issuerId: string;
        let classSuffix: string;

        console.log(`[CardsService] Checking for Wallet IDs. Program googleClassId: ${program.googleClassId}`);

        if (program.googleClassId) {
          [issuerId, classSuffix] = program.googleClassId.split('.');
        } else {
          // Fallback: use global issuerId but make classSuffix unique per program
          // Each program gets its own Google Wallet class, so multiple programs
          // don't share one class (which would prevent users from having multiple cards)
          issuerId = this.configService.get<string>('GOOGLE_ISSUER_ID');
          classSuffix = String(program._id);
          console.log(`[CardsService] Fallback to global issuerId: ${issuerId}, classSuffix: ${classSuffix}`);
        }

        if (issuerId && classSuffix) {
          console.log(`[CardsService] Attempting to generate link for issuerId: ${issuerId}, classSuffix: ${classSuffix}`);
          const user = await this.usersService.findOne(String(savedCard.userId));
          let jwtLink = '';

          if (program.type === 'business_card') {
            await this.businessCardsService.createGenericClass(issuerId, classSuffix, {
              logo: program.logo,
              backgroundColor: program.backgroundColor,
              issuerName: program.issuerName
            });

            const isLead = savedCard.metadata?.isLead === true;
            const fallbackConfig = program.config || {};

            jwtLink = this.businessCardsService.createJwtNewObjects(
              issuerId,
              classSuffix,
              String(savedCard._id),
              {
                firstName: isLead ? (fallbackConfig.firstName || program.issuerName) : user.firstName,
                lastName: isLead ? (fallbackConfig.lastName || '') : user.lastName,
                email: isLead ? (fallbackConfig.email || '') : user.email,
                phone: isLead ? fallbackConfig.phone : (savedCard.phone || user.phone),
                jobTitle: isLead ? fallbackConfig.jobTitle : (savedCard as any).jobTitle,
                companyName: program.issuerName, // Or company.name if populated, fallback is issuerName 
                logo: program.logo,
                backgroundColor: program.backgroundColor,
                heroImage: program.heroImage,
              },
              this.configService.get<string>('FRONTEND_URL') || ''
            );
          } else {
            jwtLink = this.demoLoyaltyService.createJwtNewObjects(
              issuerId,
              classSuffix,
              String(savedCard._id),
              {
                issuerName: program.issuerName,
                programName: program.programName,
                logo: program.logo,
                backgroundColor: program.backgroundColor,
                heroImage: program.heroImage,
                qrCodeData: JSON.stringify({
                  cardId: String(savedCard._id),
                  userId: String(user._id),
                  email: user.email,
                  status: savedCard.status,
                  pointsPerPurchase: program.rules?.pointsPerPurchase || 0,
                }),
                customerId: String(user._id),
                customerName: `${user.firstName} ${user.lastName}`,
                welcomeBonus: savedCard.currentBalance || 0,
              }
            );
          }
          
          savedCard.walletIds = {
            ...(savedCard.walletIds || {}),
            jwtLink: jwtLink
          };
          savedCard.markModified('walletIds');
          console.log(`[CardsService] Success! Generated jwtLink for card ${savedCard._id}`);
          return await savedCard.save();
        } else {
          console.warn(`[CardsService] Skipping Wallet link: missing issuerId (${issuerId}) or classSuffix (${classSuffix})`);
        }
      } catch (err) {
        console.error('[CardsService] ERROR generating Google Wallet link:', err.message, err.stack);
      }
    }

    return savedCard;
  }

  async update(id: string, updateData: Partial<CardInstance>) {
    const updatedCard = await this.cardInstanceModel
      .findByIdAndUpdate(id, updateData, { new: true })
      .exec();
    if (!updatedCard) throw new NotFoundException('Card instance not found');
    return updatedCard;
  }

  async remove(id: string) {
    const deletedCard = await this.cardInstanceModel.findByIdAndDelete(id).exec();
    if (!deletedCard) throw new NotFoundException('Card instance not found');
    return deletedCard;
  }
}
