import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { IsEmail, IsEnum, IsNotEmpty, IsNumber, IsObject, IsOptional, IsString, Min } from 'class-validator';

export class CreateCardDto {
  @ApiProperty({ example: '60d21b4667d0d8992e610c85', description: 'The ID of the company this card belongs to' })
  @IsString()
  @IsOptional() // Optional if programId is provided (derived from program)
  companyId?: string;

  @ApiProperty({ example: '60d21b4667d0d8992e610c86', description: 'The ID of the user (customer) owning the card' })
  @IsString()
  @IsOptional() // Optional during enrollment (user created/found by email/phone)
  userId?: string;

  @ApiPropertyOptional({ example: '60d21b4667d0d8992e610c87', description: 'The ID of the card program (template)' })
  @IsString()
  @IsOptional()
  programId?: string;

  @ApiPropertyOptional({ example: 'loyalty', description: 'Type of the card' })
  @IsString()
  @IsOptional()
  type?: string;

  @ApiPropertyOptional({ example: 100, description: 'Initial balance of the card' })
  @IsNumber()
  @Min(0)
  @IsOptional()
  currentBalance?: number;

  @ApiPropertyOptional({ example: 'active', enum: ['active', 'inactive', 'suspended'], description: 'Status of the card' })
  @IsEnum(['active', 'inactive', 'suspended'])
  @IsOptional()
  status?: string;

  // Enrollment fields
  @ApiPropertyOptional({ example: 'John', description: 'First name of the customer (for enrollment)' })
  @IsString()
  @IsOptional()
  firstName?: string;

  @ApiPropertyOptional({ example: 'Doe', description: 'Last name of the customer (for enrollment)' })
  @IsString()
  @IsOptional()
  lastName?: string;

  @ApiPropertyOptional({ example: 'john.doe@example.com', description: 'Email of the customer (for enrollment)' })
  @IsEmail()
  @IsOptional()
  email?: string;

  @ApiPropertyOptional({ example: '+41791234567', description: 'Phone number of the customer (for enrollment)' })
  @IsString()
  @IsOptional()
  phone?: string;

  @ApiPropertyOptional({ example: '1990-01-01', description: 'Birthday of the customer' })
  @IsString()
  @IsOptional()
  birthday?: string;

  @ApiPropertyOptional({ example: 'male', description: 'Gender of the customer' })
  @IsString()
  @IsOptional()
  gender?: string;

  @ApiPropertyOptional({ example: 'Zurich', description: 'City of the customer' })
  @IsString()
  @IsOptional()
  city?: string;

  @ApiPropertyOptional({ example: 'Software Engineer', description: 'Job title (for business cards)' })
  @IsString()
  @IsOptional()
  jobTitle?: string;

  @ApiPropertyOptional({ 
    description: 'Additional metadata for the card instance',
    example: { instagram: '@johndoe', linkedin: 'john-doe' }
  })
  @IsObject()
  @IsOptional()
  metadata?: Record<string, any>;
}

export class UpdateCardDto extends PartialType(CreateCardDto) {
  @ApiPropertyOptional({ example: '60d21b4667d0d8992e610c85', description: 'Internal Mongoose ID of the card' })
  @IsString()
  @IsOptional()
  _id?: string;
}
