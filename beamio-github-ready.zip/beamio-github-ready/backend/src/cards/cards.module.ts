import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CardsService } from './cards.service';
import { CardsController } from './cards.controller';
import { CardInstance, CardInstanceSchema } from '../schemas/card-instance.schema';
import { UsersModule } from '../users/users.module';
import { CardProgramsModule } from '../card-programs/card-programs.module';
import { LoyaltyModule } from '../loyalty/loyalty.module';
import { BusinessCardsModule } from '../business-cards/business-cards.module';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: CardInstance.name, schema: CardInstanceSchema }]),
    UsersModule,
    CardProgramsModule,
    LoyaltyModule,
    BusinessCardsModule,
  ],
  controllers: [CardsController],
  providers: [CardsService],
  exports: [CardsService],
})
export class CardsModule {}
