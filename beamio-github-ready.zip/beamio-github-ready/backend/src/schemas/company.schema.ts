import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CompanyDocument = Company & Document;

@Schema({ timestamps: true })
export class Company {
  @Prop({ required: true })
  name: string;

  @Prop({ required: true, unique: true })
  uid: string;

  @Prop({ required: false })
  industry?: string;
 
  @Prop({ required: false })
  contactEmail?: string;
 
  @Prop({ required: false })
  contactPhone?: string;

  @Prop({
    type: {
      street: { type: String, required: true },
      houseNumber: { type: String, required: true },
      postalCode: { type: String, required: true },
      city: { type: String, required: true },
      country: { type: String, required: true },
    },
    required: true,
    _id: false,
  })
  address: {
    street: string;
    houseNumber: string;
    postalCode: string;
    city: string;
    country: string;
  };

  @Prop({ required: true, enum: ['active', 'suspended'], default: 'active' })
  status: string;

  @Prop({ required: true })
  type: string;

  @Prop({ required: false })
  logo?: string;
}

export const CompanySchema = SchemaFactory.createForClass(Company);
