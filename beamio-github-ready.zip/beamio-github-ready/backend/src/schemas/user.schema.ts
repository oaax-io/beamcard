import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type UserDocument = User & Document;

@Schema({ timestamps: true })
export class User {
  @Prop({ required: true })
  firstName: string;

  @Prop({ required: true })
  lastName: string;

  @Prop({ required: true, unique: true })
  email: string;

  @Prop({ required: false })
  phone?: string;

  @Prop({ required: false })
  passwordHash?: string;

  @Prop({ required: false })
  profileImage?: string;

  @Prop({ required: false })
  birthday?: Date;

  @Prop({ required: false })
  gender?: string;

  @Prop({ required: false })
  city?: string;

  @Prop({ required: true, enum: ['SUPERADMIN', 'ADMIN', 'TENANT', 'STAFF', 'CUSTOMER'], default: 'CUSTOMER' })
  role: string;

  @Prop({ type: Types.ObjectId, ref: 'Company', required: false })
  companyId?: Types.ObjectId;

  @Prop({ required: true, default: 'active' })
  status: string;
}

export const UserSchema = SchemaFactory.createForClass(User);
