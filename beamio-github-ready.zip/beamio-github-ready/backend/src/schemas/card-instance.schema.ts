import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type CardInstanceDocument = CardInstance & Document;

@Schema({ timestamps: true })
export class CardInstance {
  @Prop({ type: Types.ObjectId, ref: 'Company', required: true })
  companyId: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: 'User', required: true })
  userId: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: 'CardTemplate', required: false })
  programId?: Types.ObjectId;

  @Prop({ required: false })
  type?: string;

  @Prop({ required: true, default: 0 })
  currentBalance: number;

  @Prop({ required: true, default: 'active' })
  status: string;

  @Prop({ type: Object, required: false })
  walletIds?: Record<string, string>;
  
  // Custom user fields specific to this card instance
  @Prop({ required: false })
  firstName?: string;

  @Prop({ required: false })
  lastName?: string;

  @Prop({ required: false })
  email?: string;

  @Prop({ required: false })
  jobTitle?: string;

  @Prop({ required: false })
  phone?: string;

  // For extra links like instagram, linkedin, facebook
  @Prop({ type: Object, required: false })
  metadata?: Record<string, any>;
}

export const CardInstanceSchema = SchemaFactory.createForClass(CardInstance);
