import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type CardTemplateDocument = CardTemplate & Document;

@Schema({ timestamps: true })
export class CardTemplate {
  @Prop({ type: Types.ObjectId, ref: 'Company', required: true })
  companyId: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: 'User', required: false })
  createdBy?: Types.ObjectId;

  @Prop({ required: true })
  type: string;

  @Prop({ required: true })
  programName: string;

  @Prop({ required: false })
  logo?: string;

  @Prop({ required: false })
  issuerName?: string;

  @Prop({ required: false })
  backgroundColor?: string;

  @Prop({ required: false })
  heroImage?: string;

  @Prop({ type: Object, required: false })
  rules?: Record<string, any>;

  @Prop({ required: false })
  googleClassId?: string;

  @Prop({ required: false })
  applePassTypeIdentifier?: string;

  @Prop({ required: false })
  appleTeamIdentifier?: string;

  @Prop({ required: false, default: null })
  expiresAt?: Date;

  @Prop({ type: Object, required: false })
  config?: Record<string, any>;
}

export const CardTemplateSchema = SchemaFactory.createForClass(CardTemplate);
