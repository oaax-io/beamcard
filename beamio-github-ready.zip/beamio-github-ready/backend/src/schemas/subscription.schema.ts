import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type SubscriptionDocument = Subscription & Document;

@Schema({ timestamps: true })
export class Subscription {
  @Prop({ type: Types.ObjectId, ref: 'Company', required: true, unique: true })
  companyId: Types.ObjectId;

  @Prop({ required: true, enum: ['basic', 'pro', 'team'], default: 'basic' })
  planId: string;

  @Prop({
    required: true,
    enum: ['active', 'trialing', 'past_due', 'canceled', 'incomplete'],
    default: 'active',
  })
  status: string;

  /** Stripe Customer ID (cus_xxx) – stored so we can reuse across sessions */
  @Prop()
  stripeCustomerId?: string;

  /** Stripe Subscription ID (sub_xxx) */
  @Prop()
  stripeSubscriptionId?: string;

  /** Stripe Price ID that was used when subscribing */
  @Prop()
  stripePriceId?: string;

  @Prop()
  currentPeriodStart?: Date;

  /** End of current billing period – displayed as "renews on" in the UI */
  @Prop()
  currentPeriodEnd?: Date;

  /** True when the subscription is scheduled to cancel at period end (not immediate) */
  @Prop({ default: false })
  cancelAtPeriodEnd: boolean;

  /** The user who originally established or last updated this subscription */
  @Prop({ type: String, ref: 'User', required: false })
  userId?: string;
}

export const SubscriptionSchema = SchemaFactory.createForClass(Subscription);
