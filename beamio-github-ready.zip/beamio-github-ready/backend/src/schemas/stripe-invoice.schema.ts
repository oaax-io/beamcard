import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type StripeInvoiceDocument = StripeInvoice & Document;

@Schema({ timestamps: true })
export class StripeInvoice {
  @Prop({ type: Types.ObjectId, ref: 'Company', required: true })
  companyId: Types.ObjectId;

  @Prop({ type: String, ref: 'User', required: false })
  userId?: string;

  @Prop({ required: true })
  stripeInvoiceId: string;

  @Prop({ required: false })
  stripeSubscriptionId?: string;

  @Prop({ required: true })
  amountPaid: number;

  @Prop({ required: true })
  currency: string;

  @Prop({ required: true, enum: ['paid', 'open', 'void', 'uncollectible', 'draft'] })
  status: string;

  @Prop({ required: false })
  customerEmail?: string;

  @Prop({ required: false })
  hostedInvoiceUrl?: string;

  @Prop({ required: false })
  invoicePdf?: string;
}

export const StripeInvoiceSchema = SchemaFactory.createForClass(StripeInvoice);
