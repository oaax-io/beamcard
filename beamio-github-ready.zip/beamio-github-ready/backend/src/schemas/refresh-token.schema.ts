import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type RefreshTokenDocument = RefreshToken & Document;

@Schema({ timestamps: true })
export class RefreshToken {
  @Prop({ required: true })
  tokenHash: string;

  @Prop({ type: Types.ObjectId, ref: 'User', required: true })
  userId: Types.ObjectId;

  @Prop({ required: true, default: false })
  revoked: boolean;

  // TTL index ensures MongoDB will automatically remove documents when this time is reached.
  @Prop({ required: true, expires: 0 })
  expiresAt: Date;

  @Prop({ required: false })
  deviceInfo?: string;

  @Prop({ required: false })
  ip?: string;
}

export const RefreshTokenSchema = SchemaFactory.createForClass(RefreshToken);
