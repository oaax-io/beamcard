import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type PlanConfigDocument = PlanConfig & Document;

/**
 * Singleton document — only ONE document exists in the collection.
 * Managed exclusively by SuperAdmin via /stripe/admin/plan-config.
 */
@Schema({ timestamps: true })
export class PlanConfig {
  /** ISO 4217 currency code. Must match Stripe account's settlement currency. */
  @Prop({ required: true, enum: ['eur', 'usd', 'gbp', 'chf'], default: 'chf' })
  currency: string;

  @Prop({
    type: {
      proPrice: { type: Number, required: true },
      proPriceId: { type: String, required: false },
      proName: { type: String, default: 'Pro' },
      teamPrice: { type: Number, required: true },
      teamPriceId: { type: String, required: false },
      teamName: { type: String, default: 'Team' },
    },
    required: true,
    _id: false,
  })
  plans: {
    proPrice: number;
    proPriceId: string;
    proName: string;
    teamPrice: number;
    teamPriceId: string;
    teamName: string;
  };
}

export const PlanConfigSchema = SchemaFactory.createForClass(PlanConfig);
