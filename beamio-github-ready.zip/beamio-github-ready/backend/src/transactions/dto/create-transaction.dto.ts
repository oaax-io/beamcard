import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class CreateTransactionDto {
  @ApiProperty({ description: 'The ID of the loyalty card' })
  @IsString()
  @IsNotEmpty()
  cardId: string;

  @ApiProperty({ enum: ['award', 'redeem'], description: 'Transaction type: award or redeem' })
  @IsEnum(['award', 'redeem'])
  @IsNotEmpty()
  type: string;

  @ApiProperty({ minimum: 0, description: 'The amount of points to award or redeem' })
  @IsNumber()
  @Min(0)
  amount: number;

  @ApiPropertyOptional({ description: 'Optional note for the transaction' })
  @IsString()
  @IsOptional()
  note?: string;
}
