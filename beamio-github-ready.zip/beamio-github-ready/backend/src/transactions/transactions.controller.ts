import { Controller, Get, Post, Body, Param, UseGuards, Query, Request } from '@nestjs/common';
import { TransactionsService } from './transactions.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery, ApiBody, ApiParam, ApiOkResponse, ApiCreatedResponse } from '@nestjs/swagger';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { TransactionQueryDto } from './dto/transaction-query.dto';

@ApiTags('Transactions')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('transactions')
export class TransactionsController {
  constructor(private readonly transactionsService: TransactionsService) {}

  @Roles('SUPERADMIN', 'TENANT')
  @Get()
  @ApiOperation({ summary: 'Get all transactions', description: 'Fetch a paginated list of transactions, filterable by company, card, or search term.' })
  @ApiOkResponse({ description: 'List of transactions retrieved successfully' })
  findAll(@Query() query: TransactionQueryDto) {
    const { companyId, cardId, page, limit, search } = query;
    return this.transactionsService.findAll(companyId, cardId, page, limit, search);
  }

  @Roles('SUPERADMIN', 'TENANT')
  @Get(':id')
  @ApiOperation({ summary: 'Get a transaction by ID' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the transaction' })
  @ApiOkResponse({ description: 'Transaction details retrieved successfully' })
  findOne(@Param('id') id: string) {
    return this.transactionsService.findOne(id);
  }

  @Roles('SUPERADMIN', 'TENANT')
  @Post()
  @ApiOperation({ summary: 'Record a new transaction', description: 'Award (add) or Redeem (subtract) points from a loyalty card.' })
  @ApiBody({ type: CreateTransactionDto })
  @ApiCreatedResponse({ description: 'Transaction recorded and card balance updated successfully' })
  create(@Body() createTransactionDto: CreateTransactionDto, @Request() req: any) {
    return this.transactionsService.create({ 
      ...createTransactionDto, 
      performedBy: req.user?.userId || req.user?._id 
    });
  }
}
