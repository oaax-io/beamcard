import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { DemoLoyaltyService } from '../loyalty/demo-loyalty.service';
import { CardInstance, CardInstanceDocument } from '../schemas/card-instance.schema';
import { Transaction, TransactionDocument } from '../schemas/transaction.schema';

@Injectable()
export class TransactionsService {
  constructor(
    @InjectModel(Transaction.name) private transactionModel: Model<TransactionDocument>,
    @InjectModel(CardInstance.name) private cardInstanceModel: Model<CardInstanceDocument>,
    private readonly demoLoyaltyService: DemoLoyaltyService,
    private readonly configService: ConfigService,
  ) {}

  async findAll(companyId?: string, cardId?: string, page: number = 1, limit: number = 20, search?: string) {
    const skip = (page - 1) * limit;
    const filter: any = {};
    if (companyId) filter.companyId = companyId;
    if (cardId) filter.cardId = cardId;

    if (search) {
      // search by note only (customer name lives in User, not Transaction)
      filter.note = { $regex: search, $options: 'i' };
    }

    const [data, total] = await Promise.all([
      this.transactionModel
        .find(filter)
        .populate({
          path: 'cardId',
          populate: [
            { path: 'userId', select: 'firstName lastName email' },
            { path: 'programId', select: 'programName type' },
          ],
        })
        .populate('companyId', 'name logo')
        .populate('performedBy', 'firstName lastName email role')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .exec(),
      this.transactionModel.countDocuments(filter).exec(),
    ]);

    return {
      data,
      total,
      page,
      lastPage: Math.ceil(total / limit),
    };
  }

  async findOne(id: string) {
    const tx = await this.transactionModel.findById(id).populate('cardId').exec();
    if (!tx) throw new NotFoundException('Transaction not found');
    return tx;
  }

  async create(transactionData: any) {
  try {
    const { cardId, type, amount, note } = transactionData;

    if (!cardId || !type || !amount) {
      throw new BadRequestException('cardId, type and amount are required');
    }

    const card = await this.cardInstanceModel.findById(cardId).exec();
    if (!card) {
      throw new NotFoundException('Card not found');
    }

    const balanceBefore = card.currentBalance;
    const balanceAfter =
      type === 'award'
        ? balanceBefore + Number(amount)
        : balanceBefore - Number(amount);

    card.currentBalance = balanceAfter;
    await card.save();

    // Sync balance to Google Wallet
    const issuerId = this.configService.get<string>('GOOGLE_ISSUER_ID');
    if (issuerId) {
      await this.demoLoyaltyService.patchObjectBalance(
        issuerId,
        String(card._id),
        balanceAfter,
        type,
        Number(amount),
      );
    }

    const createdTx = new this.transactionModel({
      cardId,
      companyId: card.companyId,
      type,
      amount: Number(amount),
      balanceBefore,
      balanceAfter,
      note,
      performedBy: transactionData.performedBy || null,
      date: new Date(),
    });

    return {
      card,
      transaction: await createdTx.save(),
    };
  } catch (error) {
    if (
      error instanceof BadRequestException ||
      error instanceof NotFoundException
    ) {
      throw error;
    }
    throw new BadRequestException(
      error?.message || 'Something went wrong while creating transaction',
    );
  }
}
}
