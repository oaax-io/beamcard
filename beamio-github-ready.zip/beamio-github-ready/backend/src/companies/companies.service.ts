import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Company, CompanyDocument } from '../schemas/company.schema';

@Injectable()
export class CompaniesService {
  constructor(@InjectModel(Company.name) private companyModel: Model<CompanyDocument>) {}

  async findAll(page: number = 1, limit: number = 10, search?: string) {
    const skip = (page - 1) * limit;
    const filter: any = {};

    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { uid: { $regex: search, $options: 'i' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.companyModel.find(filter).skip(skip).limit(limit).sort({ createdAt: -1 }).exec(),
      this.companyModel.countDocuments(filter).exec(),
    ]);

    return {
      data,
      total,
      page,
      lastPage: Math.ceil(total / limit),
    };
  }

  async findOne(id: string) {
    const company = await this.companyModel.findById(id).exec();
    if (!company) throw new NotFoundException('Company not found');
    return company;
  }

  async create(companyData: Partial<Company>) {
    const createdCompany = new this.companyModel(companyData);
    return createdCompany.save();
  }

  async update(id: string, updateData: Partial<Company>) {
    const updatedCompany = await this.companyModel
      .findByIdAndUpdate(id, updateData, { new: true })
      .exec();
    if (!updatedCompany) throw new NotFoundException('Company not found');
    return updatedCompany;
  }

  async remove(id: string) {
    const deletedCompany = await this.companyModel.findByIdAndDelete(id).exec();
    if (!deletedCompany) throw new NotFoundException('Company not found');
    return deletedCompany;
  }
}
