import { Controller, Get, Post, Body, Param, Put, Delete, UseGuards, Query, ParseIntPipe, DefaultValuePipe } from '@nestjs/common';
import { CompaniesService } from './companies.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles, CurrentUser } from '../common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiOkResponse, ApiCreatedResponse, ApiQuery } from '@nestjs/swagger';
import { CreateCompanyDto } from './dto/create-company.dto';
import { UpdateCompanyDto } from './dto/update-company.dto';

@ApiTags('Companies')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('companies')
export class CompaniesController {
  constructor(private readonly companiesService: CompaniesService) {}

  @Get()
  @ApiOperation({ summary: 'Get all companies', description: 'Retrieve a paginated list of all companies, filterable by a search term.' })
  @ApiOkResponse({ description: 'List of companies retrieved successfully' })
  @ApiQuery({ name: 'page', required: false, type: Number, example: 1 })
  @ApiQuery({ name: 'limit', required: false, type: Number, example: 10 })
  @ApiQuery({ name: 'search', required: false, type: String, example: 'Acme' })
  findAll(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(10), ParseIntPipe) limit: number,
    @Query('search') search?: string,
  ) {
    return this.companiesService.findAll(page, limit, search);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a company by ID', description: 'Retrieve detailed information about a specific company by its unique identifier.' })
  @ApiOkResponse({ description: 'Company details retrieved successfully' })
  findOne(@Param('id') id: string) {
    return this.companiesService.findOne(id);
  }

  @Roles('SUPERADMIN')
  @Post()
  @ApiOperation({ summary: 'Create a new company', description: 'Create a new company record. Only accessible by SUPERADMIN.' })
  @ApiCreatedResponse({ description: 'Company created successfully' })
  create(@Body() createCompanyDto: CreateCompanyDto) {
    return this.companiesService.create(createCompanyDto);
  }

  @Roles('SUPERADMIN', 'TENANT')
  @Put(':id')
  @ApiOperation({ summary: 'Update a company', description: 'Update an existing company\'s information. TENANTs can only update their own company.' })
  @ApiOkResponse({ description: 'Company updated successfully' })
  update(@Param('id') id: string, @Body() updateCompanyDto: UpdateCompanyDto, @CurrentUser() user: any) {
    // A TENANT should only update their own company. Missing in this simplified version: authorization check `if(user.companyId !== id) throw Forbidden...`
    return this.companiesService.update(id, updateCompanyDto);
  }

  @Roles('SUPERADMIN')
  @Delete(':id')
  @ApiOperation({ summary: 'Delete a company', description: 'Remove a company and its associated data. Only accessible by SUPERADMIN.' })
  @ApiOkResponse({ description: 'Company deleted successfully' })
  remove(@Param('id') id: string) {
    return this.companiesService.remove(id);
  }
}
