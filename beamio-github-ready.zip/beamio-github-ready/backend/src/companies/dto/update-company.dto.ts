import { ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { CreateCompanyDto } from './create-company.dto';

export class UpdateCompanyDto extends PartialType(CreateCompanyDto) {
  @ApiPropertyOptional({ example: '60d21b4667d0d8992e610c85', description: 'Internal Mongoose ID of the company' })
  @IsString()
  @IsOptional()
  _id?: string;
}
