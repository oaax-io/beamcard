import { IsEmail, IsNotEmpty, IsOptional, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

class AddressDto {
  @ApiProperty({ example: 'Main Street' })
  @IsString()
  @IsNotEmpty()
  street: string;

  @ApiProperty({ example: '123' })
  @IsString()
  @IsNotEmpty()
  houseNumber: string;

  @ApiProperty({ example: '8000' })
  @IsString()
  @IsNotEmpty()
  postalCode: string;

  @ApiProperty({ example: 'Zurich' })
  @IsString()
  @IsNotEmpty()
  city: string;

  @ApiProperty({ example: 'Switzerland' })
  @IsString()
  @IsNotEmpty()
  country: string;
}

export class CreateCompanyDto {
  @ApiProperty({ example: 'Acme Corp' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ example: 'CHE-123.456.789' })
  @IsString()
  @IsNotEmpty()
  uid: string;

  @ApiPropertyOptional({ example: 'Technology' })
  @IsString()
  @IsOptional()
  industry?: string;
 
  @ApiPropertyOptional({ example: 'contact@acme.com' })
  @IsEmail()
  @IsOptional()
  contactEmail?: string;
 
  @ApiPropertyOptional({ example: '+41 79 123 45 67' })
  @IsString()
  @IsOptional()
  contactPhone?: string;

  @ApiProperty({ example: 'loyalty' })
  @IsString()
  @IsNotEmpty()
  type: string;

  @ApiPropertyOptional({ example: 'https://example.com/logo.png' })
  @IsString()
  @IsOptional()
  logo?: string;

  @ApiProperty({ type: AddressDto })
  @ValidateNested()
  @Type(() => AddressDto)
  address: AddressDto;
}
