import { Body, Controller, Post, Get, Param, Res, Req } from '@nestjs/common';
import { BusinessCardsService } from './business-cards.service';
import { Response, Request } from 'express';
import { ApiTags, ApiOperation, ApiCreatedResponse, ApiOkResponse, ApiParam, ApiBody } from '@nestjs/swagger';
import { CreateJwtDto } from './dto/create-jwt.dto';

@ApiTags('Business Cards (Google Wallet)')
@Controller('business-cards')
export class BusinessCardsController {
  constructor(private readonly businessCardsService: BusinessCardsService) {}

  @Post('create-jwt')
  @ApiOperation({ summary: 'Create a Google Wallet JWT link', description: 'Generates a JWT link that allows users to add their business card to Google Wallet.' })
  @ApiBody({ type: CreateJwtDto })
  @ApiCreatedResponse({ description: 'JWT link generated successfully' })
  async createJwt(
    @Req() req: Request,
    @Body() createJwtDto: CreateJwtDto,
  ) {
    const { issuerId, classSuffix, instanceId, cardData } = createJwtDto;
    
    // Ensure the Google class exists
    await this.businessCardsService.createGenericClass(issuerId, classSuffix, cardData);

    // Get the base url to dynamically generate the vcf link
    const protocol = req.headers['x-forwarded-proto'] || req.protocol;
    const host = req.headers.host;
    const baseUrl = `${protocol}://${host}`;

    // Create the JWT
    // We pass `instanceId` as part of the objectSuffix so we can trace it back when scanning
    const objectSuffix = `${instanceId}-${Date.now()}`;
    const jwtLink = this.businessCardsService.createJwtNewObjects(
      issuerId,
      classSuffix,
      objectSuffix,
      cardData,
      baseUrl
    );

    return { jwtLink };
  }

  // User scans the QR code and ends up here!
  // In a real app we might redirect to a web profile that HAS a download button
  // For the VCF direct download:
  @Get(':objectId/vcf')
  @ApiOperation({ summary: 'Download VCF for a card', description: 'Generates and downloads a VCF file for the specified card instance.' })
  @ApiParam({ name: 'objectId', description: 'The unique identifier of the card instance' })
  @ApiOkResponse({ description: 'VCF file returned' })
  async downloadVcf(@Param('objectId') objectId: string, @Res() res: Response) {
    const vcfData = await this.businessCardsService.generateVcf(objectId);
    if (!vcfData) {
      return res.status(404).send('Card not found');
    }

    res.set('Content-Type', 'text/vcard');
    res.set('Content-Disposition', `attachment; filename="contact.vcf"`);
    res.send(vcfData);
  }

  @Get(':objectId/profile')
  @ApiOperation({ summary: 'Get profile data for a card', description: 'Retrieve the metadata and profile information for a specific business card.' })
  @ApiParam({ name: 'objectId', description: 'The unique identifier of the card instance' })
  @ApiOkResponse({ description: 'Profile data retrieved successfully' })
  async getProfile(@Param('objectId') objectId: string, @Res() res: Response) {
    const profile = await this.businessCardsService.getProfileData(objectId);
    if (!profile) {
      return res.status(404).json({ message: 'Card not found' });
    }
    return res.json(profile);
  }

  @Get('template/:templateId/profile')
  @ApiOperation({ summary: 'Get profile data for a template', description: 'Retrieve the default profile information from a business card template.' })
  @ApiParam({ name: 'templateId', description: 'The unique identifier of the card template' })
  @ApiOkResponse({ description: 'Template profile data retrieved successfully' })
  async getTemplateProfile(@Param('templateId') templateId: string, @Res() res: Response) {
    const profile = await this.businessCardsService.getTemplateProfileData(templateId);
    if (!profile) {
      return res.status(404).json({ message: 'Template not found' });
    }
    return res.json(profile);
  }

  @Get('template/:templateId/vcf')
  @ApiOperation({ summary: 'Download VCF for a template', description: 'Generates and downloads a VCF file for the specified template.' })
  @ApiParam({ name: 'templateId', description: 'The unique identifier of the card template' })
  @ApiOkResponse({ description: 'VCF file returned' })
  async downloadTemplateVcf(@Param('templateId') templateId: string, @Res() res: Response) {
    const vcfData = await this.businessCardsService.generateTemplateVcf(templateId);
    if (!vcfData) {
      return res.status(404).send('Template not found');
    }

    res.set('Content-Type', 'text/vcard');
    res.set('Content-Disposition', `attachment; filename="contact.vcf"`);
    res.send(vcfData);
  }
}
