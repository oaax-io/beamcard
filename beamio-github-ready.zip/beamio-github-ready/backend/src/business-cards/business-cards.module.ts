import { Module } from '@nestjs/common';
import { BusinessCardsService } from './business-cards.service';
import { BusinessCardsController } from './business-cards.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { CardInstanceSchema } from '../schemas/card-instance.schema';

@Module({
  imports: [MongooseModule.forFeature([{ name: 'CardInstance', schema: CardInstanceSchema }])],
  providers: [BusinessCardsService],
  controllers: [BusinessCardsController],
  exports: [BusinessCardsService]
})
export class BusinessCardsModule {}
