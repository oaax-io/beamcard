import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsObject, IsString } from 'class-validator';

export class CreateJwtDto {
  @ApiProperty({ example: '3388000000022304910', description: 'Google Wallet Issuer ID' })
  @IsString()
  @IsNotEmpty()
  issuerId: string;

  @ApiProperty({ example: 'business_card_class', description: 'Suffix for the Google Wallet class' })
  @IsString()
  @IsNotEmpty()
  classSuffix: string;

  @ApiProperty({ example: 'instance_123', description: 'Unique identifier for the card instance' })
  @IsString()
  @IsNotEmpty()
  instanceId: string;

  @ApiProperty({ 
    description: 'Data used to populate the business card',
    example: {
      firstName: 'John',
      lastName: 'Doe',
      email: 'john@example.com',
      phone: '+41791234567',
      jobTitle: 'Software Engineer',
      companyName: 'Beamcard'
    }
  })
  @IsObject()
  @IsNotEmpty()
  cardData: any;
}
