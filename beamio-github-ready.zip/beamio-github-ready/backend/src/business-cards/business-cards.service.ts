import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectModel } from '@nestjs/mongoose';
import * as jwt from 'jsonwebtoken';
import { Model } from 'mongoose';
import { CardInstanceDocument } from '../schemas/card-instance.schema';

interface Credentials {
  client_email: string;
  private_key: string;
  project_id: string;
}

@Injectable()
export class BusinessCardsService {
  private readonly logger = new Logger(BusinessCardsService.name);
  private keyFilePath: string;
  private credentials: Credentials;
  private client: any;

  constructor(
    private configService: ConfigService,
    @InjectModel('CardInstance')
    private readonly cardInstanceModel: Model<CardInstanceDocument>,
  ) {
    this.keyFilePath = this.configService.get<string>(
      'GOOGLE_APPLICATION_CREDENTIALS',
    )!;
    if (!this.keyFilePath) {
      throw new Error(
        'GOOGLE_APPLICATION_CREDENTIALS environment variable is required',
      );
    }
    this.auth();
  }

  private auth() {
    const { google } = require('googleapis');
    const auth = new google.auth.GoogleAuth({
      keyFile: this.keyFilePath,
      scopes: ['https://www.googleapis.com/auth/wallet_object.issuer'],
    });

    this.credentials = require(this.keyFilePath) as Credentials;
    this.client = google.walletobjects({
      version: 'v1',
      auth: auth,
    });
  }

  async createGenericClass(
    issuerId: string,
    classSuffix: string,
    templateData: any,
  ): Promise<string> {
    const classId = `${issuerId}.${classSuffix}`;
    let response;

    try {
      response = await this.client.genericclass.get({ resourceId: classId });
      this.logger.log(`Class ${classId} already exists. Updating...`);
    } catch (err: any) {
      if (err.response && err.response.status === 404) {
        this.logger.log(`Class ${classId} not found! Creating it...`);
        const newClass: any = {
          id: classId,
          classTemplateInfo: {
            cardTemplateOverride: {
              cardRowTemplateInfos: [
                {
                  twoItems: {
                    startItem: {
                      firstValue: {
                        fields: [
                          { fieldPath: 'object.textModulesData["jobTitle"]' },
                        ],
                      },
                    },
                    endItem: {
                      firstValue: {
                        fields: [
                          { fieldPath: 'object.textModulesData["email"]' },
                        ],
                      },
                    },
                  },
                },
              ],
            },
          },
        };

        try {
          await this.client.genericclass.insert({ requestBody: newClass });
          return classId;
        } catch (insertErr) {
          this.logger.error(`Failed to create class ${classId}`, insertErr);
          throw insertErr;
        }
      } else {
        throw err;
      }
    }

    return classId;
  }

  createJwtNewObjects(
    issuerId: string,
    classSuffix: string,
    objectSuffix: string,
    cardData: any,
    baseUrl: string,
  ): string {
    const classId = `${issuerId}.${classSuffix}`;
    const objectId = `${issuerId}.${objectSuffix}`;

    const newClass: any = {
      id: classId,
      // GenericClass doesn't use programName, it relies on genericObject fields or class overrides.
      // But we can still provide a logo if necessary, though genericClass doesn't have programLogo natively like loyaltyClass, it uses classTemplateInfo.
    };

    // Construct the Web Profile URL for the QR Code
    const frontendUrl = this.configService.get<string>('FRONTEND_URL');
    const profileUrl = `${frontendUrl}/profile/${objectId}`;

    const newObject: any = {
      id: objectId,
      classId: classId,
      state: 'ACTIVE',
      genericType: 'GENERIC_TYPE_UNSPECIFIED',
      cardTitle: {
        defaultValue: {
          language: 'en-US',
          value:
            `${cardData.firstName || ''} ${cardData.lastName || ''}`.trim() ||
            'Business Card',
        },
      },
      header: {
        defaultValue: {
          language: 'en-US',
          value: cardData.companyName || 'Company',
        },
      },
      barcode: {
        type: 'QR_CODE',
        value: profileUrl,
      },
      textModulesData: [
        {
          id: 'jobTitle',
          header: 'Job Title',
          body: cardData.jobTitle || '',
        },
        {
          id: 'email',
          header: 'Email',
          body: cardData.email || '',
        },
        {
          id: 'phone',
          header: 'Phone',
          body: cardData.phone || '',
        },
      ],
    };

    if (cardData.logo) {
      newObject.logo = {
        sourceUri: { uri: cardData.logo },
        contentDescription: {
          defaultValue: { language: 'en-US', value: 'Logo' },
        },
      };
    }

    if (cardData.backgroundColor) {
      newObject.hexBackgroundColor = cardData.backgroundColor;
    }

    if (cardData.heroImage) {
      newObject.heroImage = {
        sourceUri: { uri: cardData.heroImage },
        contentDescription: {
          defaultValue: { language: 'en-US', value: 'Hero Image' },
        },
      };
    }

    const claims = {
      iss: this.credentials.client_email,
      aud: 'google',
      origins: [],
      typ: 'savetowallet',
      payload: {
        genericClasses: [newClass],
        genericObjects: [newObject],
      },
    };

    this.logger.log(`Generating JWT for Business Card. Object ID: ${objectId}`);

    const token = jwt.sign(claims, this.credentials.private_key, {
      algorithm: 'RS256',
    });

    const jwtLink = `https://pay.google.com/gp/v/save/${token}`;
    return jwtLink;
  }

  async generateVcf(objectId: string): Promise<string> {
    // 1. We receive Google's objectId (issuerId.objectSuffix)
    // 2. We extract the instance ID from objectSuffix assuming we named it `instanceId-timestamp`
    // OR we can just lookup by DB ID if objectSuffix matches cardInstance._id.
    const parts = objectId.split('.');
    if (parts.length < 2) return '';
    const suffix = parts[1];
    const instanceId = suffix.split('-')[0]; // assuming suffix is `instanceId-timestamp`

    const card = await this.cardInstanceModel
      .findById(instanceId)
      .populate(['companyId', 'programId'])
      .exec();
    if (!card) {
      return '';
    }

    const program = card.programId as any;
    const config = program?.config || {};
    const isLead = (card.metadata as any)?.isLead === true;

    // If it's a Lead, the name should be the Issuer Name (Company), and phone/email/links from config
    // If it's a proper Issued Card, use the Card fields.
    const firstName = isLead
      ? config.firstName || program?.issuerName || 'Business'
      : card.firstName || '';
    const lastName = isLead ? config.lastName || 'Card' : card.lastName || '';
    const phone = isLead ? config.phone : card.phone || '';
    const email = isLead ? config.email || '' : card.email || '';
    const jobTitle = isLead ? config.jobTitle : card.jobTitle || '';

    // Format the VCF
    const vcf = [
      'BEGIN:VCARD',
      'VERSION:3.0',
      `N:${lastName};${firstName};;;`,
      `FN:${firstName} ${lastName}`,
      `ORG:${(card.companyId as any)?.name || 'Company'}`,
      `TITLE:${jobTitle}`,
      `TEL;TYPE=WORK,VOICE:${phone}`,
    ];

    if (email) vcf.push(`EMAIL;TYPE=PREF,INTERNET:${email}`);

    // Add social links from metadata (already populated on card usually, but leads get them from config)
    const metadata = isLead ? config : card.metadata || {};
    if (metadata.linkedin) vcf.push(`URL;TYPE=LinkedIn:${metadata.linkedin}`);
    if (metadata.instagram)
      vcf.push(`URL;TYPE=Instagram:${metadata.instagram}`);
    if (metadata.facebook) vcf.push(`URL;TYPE=Facebook:${metadata.facebook}`);

    vcf.push('END:VCARD');
    return vcf.join('\n');
  }

  async getProfileData(objectId: string): Promise<any> {
    const parts = objectId.split('.');
    if (parts.length < 2) return null;
    const suffix = parts[1];
    const instanceId = suffix.split('-')[0];

    const card = await this.cardInstanceModel
      .findById(instanceId)
      .populate(['companyId', 'programId'])
      .exec();
    if (!card) return null;

    const program = card.programId as any;
    const config = program?.config || {};
    const isLead = (card.metadata as any)?.isLead === true;

    return {
      firstName: isLead
        ? config.firstName || program?.issuerName || 'Business'
        : card.firstName,
      lastName: isLead ? config.lastName || 'Card' : card.lastName,
      jobTitle: isLead ? config.jobTitle : card.jobTitle,
      email: isLead ? config.email || '' : card.email,
      phone: isLead ? config.phone : card.phone,
      companyName: (card.companyId as any)?.name,
      metadata: isLead ? config : card.metadata,
    };
  }

  async getTemplateProfileData(templateId: string): Promise<any> {
    const CardTemplate = this.cardInstanceModel.db.model('CardTemplate');
    
    const template: any = await CardTemplate.findById(templateId)
      .populate('companyId')
      .exec();
    
    if (!template || template.type !== 'business_card') return null;

    const config = template.config || {};

    return {
      firstName: config.firstName || template.issuerName || 'Business',
      lastName: config.lastName || '',
      jobTitle: config.jobTitle || '',
      email: config.email || '',
      phone: config.phone || '',
      companyName: template.companyId?.name || template.issuerName,
      metadata: {
        website: config.website || '',
        linkedin: config.linkedin || '',
        instagram: config.instagram || '',
        facebook: config.facebook || '',
      },
    };
  }

  async generateTemplateVcf(templateId: string): Promise<string> {
    const CardTemplate = this.cardInstanceModel.db.model('CardTemplate');
    
    const template: any = await CardTemplate.findById(templateId)
      .populate('companyId')
      .exec();
    
    if (!template || template.type !== 'business_card') return '';

    const config = template.config || {};
    const firstName = config.firstName || template.issuerName || 'Business';
    const lastName = config.lastName || '';
    const jobTitle = config.jobTitle || '';
    const email = config.email || '';
    const phone = config.phone || '';
    const companyName = template.companyId?.name || template.issuerName;

    // Format the VCF
    const vcf = [
      'BEGIN:VCARD',
      'VERSION:3.0',
      `N:${lastName};${firstName};;;`,
      `FN:${firstName} ${lastName}`,
      `ORG:${companyName}`,
      `TITLE:${jobTitle}`,
      `TEL;TYPE=WORK,VOICE:${phone}`,
    ];

    if (email) vcf.push(`EMAIL;TYPE=PREF,INTERNET:${email}`);

    // Add social links from config
    if (config.website) vcf.push(`URL;TYPE=Website:${config.website}`);
    if (config.linkedin) vcf.push(`URL;TYPE=LinkedIn:${config.linkedin}`);
    if (config.instagram) vcf.push(`URL;TYPE=Instagram:${config.instagram}`);
    if (config.facebook) vcf.push(`URL;TYPE=Facebook:${config.facebook}`);

    vcf.push('END:VCARD');
    return vcf.join('\n');
  }
}
