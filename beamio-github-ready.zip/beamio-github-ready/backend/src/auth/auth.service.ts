import { Injectable, UnauthorizedException, BadRequestException, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import * as bcrypt from 'bcrypt';
import { User, UserDocument } from '../schemas/user.schema';
import { RefreshToken, RefreshTokenDocument } from '../schemas/refresh-token.schema';
import { ConfigService } from '@nestjs/config';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';

@Injectable()
export class AuthService {
   private readonly logger = new Logger(AuthService.name);
  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    @InjectModel(RefreshToken.name) private refreshTokenModel: Model<RefreshTokenDocument>,
    private jwtService: JwtService,
    private configService: ConfigService,
  ) {}

  async register(registerDto: RegisterDto) {
    const existingUser = await this.userModel.findOne({ email: registerDto.email });
    if (existingUser) {
      throw new BadRequestException('User with this email already exists');
    }

    const saltRounds = this.configService.get<number>('BCRYPT_SALT_ROUNDS') || 10;
    const passwordHash = await bcrypt.hash(registerDto.password, Number(saltRounds));

    const createdUser = new this.userModel({
      email: registerDto.email,
      passwordHash,
      name: registerDto.name,
      role: 'CUSTOMER',
    });

    const savedUser = await createdUser.save();
    return this.generateTokens(savedUser);
  }

  async login(loginDto: LoginDto, ip?: string, userAgent?: string) {
    const user = await this.userModel.findOne({ email: loginDto.email });
    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const isPasswordValid = await bcrypt.compare(loginDto.password, user.passwordHash);
    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid credentials');
    }

    return this.generateTokens(user, ip, userAgent);
  }

  async refreshTokens(oldRefreshToken: string, ip?: string, userAgent?: string) {
    if (!oldRefreshToken) {
      throw new UnauthorizedException('Refresh token missing');
    }

    // Attempt to find the stored token. Note: the plain token from the cookie needs to be verified against the stored hash.
    // However, finding by hash requires hashing first or comparing all. 
    // Best practice for DB indexing: we can store the plain token (which is already a random UUID) as `tokenHash` directly, or hash it.
    // If we use bcrypt, we must find the token by user ID or keep a token ID embedded in the JWT.
    // simpler method for this implementation: use a random string and store it directly, but user requested bcrypt hash.
    // To find it efficiently, we decode the userId from the token if it's a JWT.
    
    // Instead of raw strings, let's treat the refresh token as a UUID or JWT that we hash before storing.
    // To look it up without comparing every row, we can just query all active tokens for this user... but we don't know the user!
    // Solution: The client sends a JWT refresh token containing the userId, and we compare its signature, then compare the token string against the stored bcrypt hash.

    try {
      const payload = this.jwtService.verify(oldRefreshToken, {
        secret: this.configService.get<string>('JWT_REFRESH_SECRET'),
      });

      this.logger.log('Refresh Token Payload:', payload);
      const userId = new Types.ObjectId(payload.sub);
      const storedTokens = await this.refreshTokenModel.find({ userId, revoked: false });

      this.logger.log(`Found ${storedTokens.length} active tokens for user ${userId}`);

      let validTokenDoc = null;
      for (const doc of storedTokens) {
        const isMatch = await bcrypt.compare(oldRefreshToken, doc.tokenHash);
        if (isMatch) {
          validTokenDoc = doc;
          break;
        }
      }

      if (!validTokenDoc) {
        this.logger.warn('No matching refresh token found in DB after bcrypt comparison');
        throw new UnauthorizedException('Invalid or revoked refresh token');
      }

      // Rotate token: invalidate old one
      validTokenDoc.revoked = true;
      this.logger.log(`Revoking token doc ${validTokenDoc._id}`);
      await validTokenDoc.save();

      const user = await this.userModel.findById(userId);
      if (!user) throw new UnauthorizedException('User not found');

      return this.generateTokens(user, ip, userAgent);

    } catch (e) {
      throw new UnauthorizedException('Invalid refresh token');
    }
  }

  async logout(refreshToken: string) {
    if (!refreshToken) return;
    try {
      const payload = this.jwtService.verify(refreshToken, {
        secret: this.configService.get<string>('JWT_REFRESH_SECRET'),
      });
      
      const userId = new Types.ObjectId(payload.sub);
      const storedTokens = await this.refreshTokenModel.find({ userId, revoked: false });
      
      this.logger.log(`Logout: Found ${storedTokens.length} active tokens for user ${userId}`);

      for (const doc of storedTokens) {
        if (await bcrypt.compare(refreshToken, doc.tokenHash)) {
          doc.revoked = true;
          this.logger.log(`Logout: Revoking token doc ${doc._id}`);
          await doc.save();
          break;
        }
      }
    } catch (e) {
      this.logger.error('Logout error:', e.message);
      // Ignore errors on logout
    }
  }

  private async generateTokens(user: UserDocument, ip?: string, userAgent?: string) {
    const payload = { sub: user._id, email: user.email, role: user.role, companyId: user.companyId };

    const accessToken = this.jwtService.sign(payload, {
      secret: this.configService.get<string>('JWT_SECRET'),
      expiresIn: (this.configService.get<string>('ACCESS_TOKEN_EXPIRES_IN') || '15m') as any,
    });

    const refreshToken = this.jwtService.sign(payload, {
      secret: this.configService.get<string>('JWT_REFRESH_SECRET'),
      expiresIn: (this.configService.get<string>('REFRESH_TOKEN_EXPIRES_IN') || '7d') as any,
    });

    // Store hashed refresh token
    const saltRounds = this.configService.get<number>('BCRYPT_SALT_ROUNDS') || 10;
    const tokenHash = await bcrypt.hash(refreshToken, Number(saltRounds));

    // Calculate expiration date for TTL index
    const expiresInStr = this.configService.get<string>('REFRESH_TOKEN_EXPIRES_IN') || '7d';
    const days = parseInt(expiresInStr.replace('d', '')) || 7;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + days);

    await new this.refreshTokenModel({
      tokenHash,
      userId: user._id,
      expiresAt,
      ip,
      deviceInfo: userAgent,
    }).save();

    return {
      accessToken,
      refreshToken,
      user: {
        id: user._id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        companyId: user.companyId,
      }
    };
  }
}
