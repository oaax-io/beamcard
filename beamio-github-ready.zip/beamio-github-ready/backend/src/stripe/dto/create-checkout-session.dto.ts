import { IsIn, IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateCheckoutSessionDto {
  @ApiProperty({ 
    description: 'The identifier of the requested plan (either "pro" or "team")',
    example: 'pro', 
    enum: ['pro', 'team'] 
  })
  @IsString()
  @IsNotEmpty()
  @IsIn(['pro', 'team'])
  planId: 'pro' | 'team';
}
