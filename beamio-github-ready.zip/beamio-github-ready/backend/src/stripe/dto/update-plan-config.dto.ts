import { IsIn, IsNumber, IsObject, IsOptional, IsString, Min, ValidateNested } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class PlansDto {
  @ApiProperty({ description: 'The monthly price for the Pro plan', example: 4.9 })
  @IsNumber()
  @Min(0)
  proPrice: number;

  @ApiPropertyOptional({ description: 'Display name for the Pro plan natively', example: 'Pro' })
  @IsString()
  @IsOptional()
  proName?: string;

  @ApiProperty({ description: 'The monthly price for the Team plan', example: 29.9 })
  @IsNumber()
  @Min(0)
  teamPrice: number;

  @ApiPropertyOptional({ description: 'Display name for the Team plan natively', example: 'Team' })
  @IsString()
  @IsOptional()
  teamName?: string;
}

export class UpdatePlanConfigDto {
  @ApiProperty({ 
    description: 'The preferred ISO currency code for pricing and Stripe billing',
    example: 'chf', 
    enum: ['eur', 'usd', 'gbp', 'chf'] 
  })
  @IsString()
  @IsIn(['eur', 'usd', 'gbp', 'chf'])
  currency: string;

  @ApiProperty({ 
    type: PlansDto,
    description: 'The configured prices and names for the platform native plans',
  })
  @IsObject()
  @ValidateNested()
  @Type(() => PlansDto)
  plans: PlansDto;
}
