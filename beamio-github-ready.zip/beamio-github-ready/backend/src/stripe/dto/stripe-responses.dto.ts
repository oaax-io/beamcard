import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class SubscriptionResponseDto {
  @ApiProperty({ description: 'The current plan ID', example: 'pro' })
  planId: string;

  @ApiProperty({ description: 'Subscription status', example: 'active' })
  status: string;

  @ApiProperty({ description: 'The company ID associated with the subscription' })
  companyId: string;

  @ApiProperty({ description: 'Will the subscription cancel at period end?', example: false })
  cancelAtPeriodEnd: boolean;

  @ApiPropertyOptional({ description: 'Stripe Customer ID' })
  stripeCustomerId?: string;

  @ApiPropertyOptional({ description: 'Stripe Subscription ID' })
  stripeSubscriptionId?: string;

  @ApiPropertyOptional({ description: 'Stripe Price ID' })
  stripePriceId?: string;

  @ApiPropertyOptional({ description: 'Start date of the current billing period' })
  currentPeriodStart?: Date;

  @ApiPropertyOptional({ description: 'End date of the current billing period' })
  currentPeriodEnd?: Date;
}

export class CheckoutSessionResponseDto {
  @ApiProperty({ description: 'The Stripe hosted checkout URL', example: 'https://checkout.stripe.com/...' })
  url: string;
}

export class PlanConfigDetailsDto {
  @ApiProperty({ description: 'Price of the Pro plan', example: 4.9 })
  proPrice: number;

  @ApiPropertyOptional({ description: 'Stripe Price ID for the Pro plan' })
  proPriceId?: string;

  @ApiProperty({ description: 'Name of the Pro plan', example: 'Pro' })
  proName: string;

  @ApiProperty({ description: 'Price of the Team plan', example: 29.9 })
  teamPrice: number;

  @ApiPropertyOptional({ description: 'Stripe Price ID for the Team plan' })
  teamPriceId?: string;

  @ApiProperty({ description: 'Name of the Team plan', example: 'Team' })
  teamName: string;
}

export class PlanConfigResponseDto {
  @ApiProperty({ description: 'Currency code', example: 'chf' })
  currency: string;

  @ApiProperty({ type: PlanConfigDetailsDto })
  plans: PlanConfigDetailsDto;
}

export class UserDetailsDto {
  @ApiPropertyOptional({ description: 'User ID' })
  _id?: string;

  @ApiProperty({ description: 'First name' })
  firstName: string;

  @ApiProperty({ description: 'Last name' })
  lastName: string;

  @ApiProperty({ description: 'Email address' })
  email: string;

  @ApiProperty({ description: 'User role' })
  role: string;
}

export class CompanyDetailsDto {
  @ApiProperty({ description: 'Company name' })
  name: string;

  @ApiPropertyOptional({ description: 'Company logo URL' })
  logo?: string;

  @ApiProperty({ description: 'Unique company ID' })
  uid: string;
}

export class StripeInvoiceResponseDto {
  @ApiProperty({ description: 'Company reference' })
  companyId: CompanyDetailsDto;

  @ApiPropertyOptional({ description: 'User who initiated the transaction', type: UserDetailsDto })
  userId?: UserDetailsDto;

  @ApiProperty({ description: 'Stripe Invoice ID' })
  stripeInvoiceId: string;

  @ApiPropertyOptional({ description: 'Stripe Subscription ID' })
  stripeSubscriptionId?: string;

  @ApiProperty({ description: 'Amount paid (in major currency units)', example: 4.9 })
  amountPaid: number;

  @ApiProperty({ description: 'Currency code', example: 'chf' })
  currency: string;

  @ApiProperty({ description: 'Status of the invoice', enum: ['paid', 'open', 'void', 'uncollectible', 'draft'] })
  status: string;

  @ApiPropertyOptional({ description: 'Customer email address' })
  customerEmail?: string;

  @ApiPropertyOptional({ description: 'URL to the hosted invoice page' })
  hostedInvoiceUrl?: string;

  @ApiPropertyOptional({ description: 'URL to download the invoice PDF' })
  invoicePdf?: string;

  @ApiProperty({ description: 'Creation date' })
  createdAt: Date;
}

export class PaginatedBillingTransactionsDto {
  @ApiProperty({ type: [StripeInvoiceResponseDto], description: 'List of billing transactions' })
  data: StripeInvoiceResponseDto[];

  @ApiProperty({ description: 'Total number of transactions', example: 100 })
  total: number;

  @ApiProperty({ description: 'Current page number', example: 1 })
  page: number;

  @ApiProperty({ description: 'Last page number', example: 10 })
  lastPage: number;
}
