import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Subscription, SubscriptionSchema } from '../schemas/subscription.schema';
import { PlanConfig, PlanConfigSchema } from '../schemas/plan-config.schema';
import { StripeInvoice, StripeInvoiceSchema } from '../schemas/stripe-invoice.schema';
import { StripeService } from './stripe.service';
import { StripeController } from './stripe.controller';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Subscription.name, schema: SubscriptionSchema },
      { name: PlanConfig.name, schema: PlanConfigSchema },
      { name: StripeInvoice.name, schema: StripeInvoiceSchema },
    ]),
  ],
  controllers: [StripeController],
  providers: [StripeService],
  exports: [StripeService],
})
export class StripeModule {}
