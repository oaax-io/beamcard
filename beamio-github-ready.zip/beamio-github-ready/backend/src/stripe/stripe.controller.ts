import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Headers,
  Post,
  Put,
  RawBodyRequest,
  Req,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiTags,
  ApiOkResponse,
  ApiCreatedResponse,
  ApiQuery,
} from '@nestjs/swagger';
import { Request } from 'express';
import { CurrentUser, JwtAuthGuard, Roles, RolesGuard } from '../common';
import { CreateCheckoutSessionDto } from './dto/create-checkout-session.dto';
import { UpdatePlanConfigDto } from './dto/update-plan-config.dto';
import { StripeService } from './stripe.service';
import {
  PaginatedBillingTransactionsDto,
  CheckoutSessionResponseDto,
  PlanConfigResponseDto,
  SubscriptionResponseDto,
} from './dto/stripe-responses.dto';

@ApiTags('Stripe')
@Controller('stripe')
export class StripeController {
  constructor(private readonly stripeService: StripeService) {}

  // ─────────────────────────────────────────────────────────────────────────────
  // Public endpoints (Tenant-facing)
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Returns the current subscription status for the logged-in tenant's company.
   */
  @Get('my-subscription')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('TENANT', 'SUPERADMIN', 'ADMIN')
  @ApiOperation({ summary: 'Get current subscription for the tenant company' })
  @ApiOkResponse({ description: 'Current subscription returned successfully', type: SubscriptionResponseDto })
  getMySubscription(@CurrentUser() user: any) {
    return this.stripeService.getCompanySubscription(String(user.companyId));
  }

  /**
   * Returns the plan config (prices, currency) for display in the subscription page.
   * Accessible by any authenticated user.
   */
  @Get('plan-config')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @ApiOperation({ summary: 'Get plan pricing configuration' })
  @ApiOkResponse({ description: 'Plan config returned successfully', type: PlanConfigResponseDto })
  getPlanConfig() {
    return this.stripeService.getPlanConfig();
  }

  /**
   * Creates a Stripe Checkout Session and returns the hosted URL.
   * Security:
   *  - Requires a valid JWT (tenant only)
   *  - planId is validated by DTO and mapped to a Price ID server-side
   *  - Price ID is never accepted from the client
   */
  @Post('create-checkout-session')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('TENANT', 'ADMIN')
  @ApiOperation({ summary: 'Create a Stripe Checkout session for a paid plan' })
  @ApiCreatedResponse({ description: 'Returns the Stripe-hosted checkout URL', type: CheckoutSessionResponseDto })
  createCheckoutSession(
    @Body() dto: CreateCheckoutSessionDto,
    @CurrentUser() user: any,
  ) {
    if (!user.companyId) {
      throw new BadRequestException('User is not associated with a company');
    }
    return this.stripeService.createCheckoutSession(
      String(user.companyId),
      dto.planId,
      user.email,
      String(user.userId || user._id),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // SuperAdmin — Plan Config management
  // ─────────────────────────────────────────────────────────────────────────────

  @Get('admin/plan-config')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('SUPERADMIN')
  @ApiOperation({ summary: '[SuperAdmin] Get full plan config including Price IDs' })
  @ApiOkResponse({ description: 'Full plan config returned', type: PlanConfigResponseDto })
  adminGetPlanConfig() {
    return this.stripeService.getPlanConfig();
  }

  @Put('admin/plan-config')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('SUPERADMIN')
  @ApiOperation({ summary: '[SuperAdmin] Update plan pricing config and Stripe Price IDs' })
  @ApiOkResponse({ description: 'Plan config updated successfully', type: PlanConfigResponseDto })
  adminUpdatePlanConfig(@Body() dto: UpdatePlanConfigDto) {
    return this.stripeService.updatePlanConfig(dto);
  }

  @Get('admin/billing-transactions')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('SUPERADMIN')
  @ApiOperation({ summary: '[SuperAdmin] Get all Stripe billing transactions' })
  @ApiQuery({ name: 'page', required: false, type: Number, description: 'Page number for pagination (default: 1)' })
  @ApiQuery({ name: 'limit', required: false, type: Number, description: 'Number of records per page (default: 10)' })
  @ApiOkResponse({ description: 'Returns a paginated list of billing transactions', type: PaginatedBillingTransactionsDto })
  adminGetBillingTransactions(@Req() req: Request) {
    const page = Number(req.query.page) || 1;
    const limit = Number(req.query.limit) || 10;
    return this.stripeService.adminGetBillingTransactions(page, limit);
  }

  @Get('my-billing-transactions')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('TENANT', 'SUPERADMIN', 'ADMIN')
  @ApiOperation({ summary: 'Get all Stripe billing transactions for the logged in user\'s company' })
  @ApiQuery({ name: 'page', required: false, type: Number, description: 'Page number for pagination (default: 1)' })
  @ApiQuery({ name: 'limit', required: false, type: Number, description: 'Number of records per page (default: 10)' })
  @ApiOkResponse({ description: 'Returns a paginated list of billing transactions', type: PaginatedBillingTransactionsDto })
  getMyBillingTransactions(@Req() req: Request, @CurrentUser() user: any) {
    const page = Number(req.query.page) || 1;
    const limit = Number(req.query.limit) || 10;
    return this.stripeService.getUserBillingTransactions(String(user.companyId), page, limit);
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Stripe Webhook — PUBLIC, raw body required
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * This endpoint MUST NOT be behind JwtAuthGuard — Stripe calls it directly.
   * Raw body preservation is configured in main.ts (express.raw middleware).
   * Signature verification happens inside stripeService.handleWebhookEvent().
   */
  @Post('webhook') 
  @ApiOperation({
    summary: 'Stripe webhook receiver',
    description:
      'Receives Stripe events. Signature is verified via HMAC-SHA256. Do not add JWT guard here.',
  })
  async handleWebhook(
    @Req() req: RawBodyRequest<Request>,
    @Headers('stripe-signature') signature: string,
  ) {
    if (!signature) {
      throw new BadRequestException('Missing stripe-signature header');
    }
    if (!req.rawBody) {
      throw new BadRequestException(
        'Raw body not available — ensure express.raw() is configured for this route in main.ts',
      );
    }
    await this.stripeService.handleWebhookEvent(req.rawBody, signature);
    return { received: true };
  }
}
