import {
  BadRequestException,
  Injectable,
  InternalServerErrorException,
  Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { PlanConfig, PlanConfigDocument } from '../schemas/plan-config.schema';
import { StripeInvoice, StripeInvoiceDocument } from '../schemas/stripe-invoice.schema';
import { Subscription, SubscriptionDocument } from '../schemas/subscription.schema';
import { UpdatePlanConfigDto } from './dto/update-plan-config.dto';
import Stripe = require('stripe');

@Injectable()
export class StripeService {
  private readonly stripe: any;
  private readonly logger = new Logger(StripeService.name);

  constructor(
    private readonly configService: ConfigService,
    @InjectModel(Subscription.name)
    private readonly subscriptionModel: Model<SubscriptionDocument>,
    @InjectModel(PlanConfig.name)
    private readonly planConfigModel: Model<PlanConfigDocument>,
    @InjectModel(StripeInvoice.name)
    private readonly stripeInvoiceModel: Model<StripeInvoiceDocument>,
  ) {
    const secretKey = this.configService.get<string>('STRIPE_SECRET_KEY');
    if (!secretKey) {
      throw new InternalServerErrorException('STRIPE_SECRET_KEY is not configured');
    }
    this.stripe = new Stripe(secretKey, { apiVersion: '2023-10-16' } as any);
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Plan Config (SuperAdmin only)
  // ─────────────────────────────────────────────────────────────────────────────

  /** Returns the singleton PlanConfig document (creates a default one if absent) */
  async getPlanConfig(): Promise<PlanConfigDocument> {
    let config = await this.planConfigModel.findOne().exec();
    if (!config) {
      // Seed a sensible default so the SuperAdmin page isn't empty on first load
      config = await this.planConfigModel.create({
        currency: 'chf',
        plans: {
          proPrice: 4.9,
          proPriceId: '',
          proName: 'Pro',
          teamPrice: 29.9,
          teamPriceId: '',
          teamName: 'Team',
        },
      });
    }
    return config;
  }

  /** Ensures a Stripe Product and Price exist for the requested config, returning the new (or existing) Stripe Price ID */
  private async ensureStripePrice(productName: string, amount: number, currency: string, existingPriceId?: string): Promise<string> {
    const unitAmount = Math.round(amount * 100);

    // If there's an existing price ID in DB, verify if it still matches
    if (existingPriceId) {
      try {
        const price = await this.stripe.prices.retrieve(existingPriceId);
        if (price.unit_amount === unitAmount && price.currency === currency.toLowerCase()) {
          return existingPriceId; // no change needed
        }
      } catch (e) {
        // Price not found or error, we create a new one
      }
    }

    // Find existing product or create one
    const products = await this.stripe.products.list({ active: true, limit: 100 });
    let product = products.data.find(p => p.name === productName);

    if (!product) {
      product = await this.stripe.products.create({ name: productName });
    }

    // Create the new price
    const newPrice = await this.stripe.prices.create({
      product: product.id,
      unit_amount: unitAmount,
      currency: currency.toLowerCase(),
      recurring: { interval: 'month' },
    });

    return newPrice.id;
  }

  /** Upserts the singleton PlanConfig document and synchronizes automatically with Stripe */
  async updatePlanConfig(dto: UpdatePlanConfigDto): Promise<PlanConfigDocument> {
    const currentConfig = await this.getPlanConfig();
    
    // Auto-sync with Stripe to generate or fetch price IDs
    const proName = dto.plans.proName || 'Beamcard Pro Plan';
    const teamName = dto.plans.teamName || 'Beamcard Team Plan';

    const proPriceId = await this.ensureStripePrice(proName, dto.plans.proPrice, dto.currency, currentConfig.plans.proPriceId);
    const teamPriceId = await this.ensureStripePrice(teamName, dto.plans.teamPrice, dto.currency, currentConfig.plans.teamPriceId);

    const config = await this.planConfigModel
      .findOneAndUpdate(
        {},
        {
          currency: dto.currency,
          plans: {
            proPrice: dto.plans.proPrice,
            proPriceId,
            proName,
            teamPrice: dto.plans.teamPrice,
            teamPriceId,
            teamName,
          },
        },
        { new: true, upsert: true },
      )
      .exec();
    return config;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Billing Transactions
  // ─────────────────────────────────────────────────────────────────────────────

  async adminGetBillingTransactions(page = 1, limit = 10) {
    const skip = (page - 1) * limit;
    const [data, total] = await Promise.all([
      this.stripeInvoiceModel
        .find()
        .populate('companyId', 'name uid logo')
        .populate('userId', 'firstName lastName email role')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .exec(),
      this.stripeInvoiceModel.countDocuments().exec(),
    ]);

    return {
      data,
      total,
      page,
      lastPage: Math.ceil(total / limit) || 1,
    };
  }

  async getUserBillingTransactions(companyId: string, page = 1, limit = 10) {
    const skip = (page - 1) * limit;
    const [data, total] = await Promise.all([
      this.stripeInvoiceModel
        .find({ companyId: new Types.ObjectId(companyId) })
        .populate('userId', 'firstName lastName email role')
        .populate('companyId', 'name uid logo')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .exec(),
      this.stripeInvoiceModel.countDocuments({ companyId: new Types.ObjectId(companyId) }).exec(),
    ]);

    return {
      data,
      total,
      page,
      lastPage: Math.ceil(total / limit) || 1,
    };
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Subscription
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Returns the current subscription for a company.
   * Falls back to a virtual "basic / active" object if no record exists yet.
   */
  async getCompanySubscription(companyId: string) {
    const sub = await this.subscriptionModel
      .findOne({ companyId: new Types.ObjectId(companyId) })
      .exec();

    if (!sub) {
      return { planId: 'basic', status: 'active', companyId, cancelAtPeriodEnd: false };
    }
    return sub;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Stripe Checkout
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Creates a Stripe Checkout Session for a paid plan.
   * Security: the Price ID is NEVER accepted from the client — it is always
   * pulled from the PlanConfig document stored in MongoDB.
   */
  async createCheckoutSession(
    companyId: string,
    planId: 'pro' | 'team',
    customerEmail: string,
    userId: string,
  ): Promise<{ url: string }> {
    const planConfig = await this.getPlanConfig();

    // Resolve the correct Stripe Price ID from DB, never from the request
    const priceId =
      planId === 'pro' ? planConfig.plans.proPriceId : planConfig.plans.teamPriceId;

    if (!priceId) {
      throw new BadRequestException(
        `Stripe Price ID for "${planId}" plan is not configured. Please ask your administrator to configure it.`,
      );
    }

    // Look up or create a Stripe Customer linked to this company
    const stripeCustomerId = await this.getOrCreateStripeCustomer(companyId, customerEmail);

    const successUrl = `${this.configService.get('STRIPE_SUCCESS_URL')}`;
    const cancelUrl = `${this.configService.get('STRIPE_CANCEL_URL')}`;

    const session = await this.stripe.checkout.sessions.create({
      mode: 'subscription',
      customer: stripeCustomerId,
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: successUrl,
      cancel_url: cancelUrl,
      // Attach companyId in metadata so we can reconcile in the webhook
      metadata: { companyId, planId, userId },
      subscription_data: {
        metadata: { companyId, planId, userId },
      },
      // Cancel at period end (not immediately) when unsubscribed
      payment_method_collection: 'always',
    });

    console.log('session===>',session);

    if (!session.url) {
      throw new InternalServerErrorException('Failed to create Stripe checkout session URL');
    }

    return { url: session.url };
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Webhook Handler
  // ─────────────────────────────────────────────────────────────────────────────

  /**
   * Verifies the Stripe webhook signature and dispatches the event.
   * MUST receive the raw (un-parsed) request body.
   */
  async handleWebhookEvent(rawBody: Buffer, signature: string): Promise<void> {
    const webhookSecret = this.configService.get<string>('STRIPE_WEBHOOK_SECRET');
    if (!webhookSecret) {
      throw new InternalServerErrorException('STRIPE_WEBHOOK_SECRET is not configured');
    }

    let event: any;
    try {
      event = this.stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
    } catch (err) {
      this.logger.warn(`Stripe webhook signature verification failed: ${err.message}`);
      throw new BadRequestException(`Invalid Stripe webhook signature: ${err.message}`);
    }

    this.logger.log(`Stripe event received: ${event.type} (${event.id})`);

    try {
      switch (event.type) {
        case 'checkout.session.completed':
          await this.onCheckoutSessionCompleted(event.data.object as any);
          break;

        case 'invoice.payment_succeeded':
          await this.onInvoicePaymentSucceeded(event.data.object as any);
          break;

        case 'invoice.payment_failed':
          await this.onInvoicePaymentFailed(event.data.object as any);
          break;

        case 'customer.subscription.updated':
          await this.onSubscriptionUpdated(event.data.object as any);
          break;

        case 'customer.subscription.deleted':
          await this.onSubscriptionDeleted(event.data.object as any);
          break;

        default:
          this.logger.log(`Unhandled Stripe event type: ${event.type}`);
      }
    } catch (err) {
      this.logger.error(`Error processing Stripe event ${event.type}: ${err.message}`, err.stack);
      // Re-throw so NestJS returns a 500 → Stripe will retry the webhook
      throw err;
    }
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // Private helpers
  // ─────────────────────────────────────────────────────────────────────────────

  private async saveStripeInvoice(companyId: string, invoice: any, userId?: string) {
    if (!companyId || !invoice.id) return;
    try {
      const updateData: any = {
        companyId: new Types.ObjectId(companyId),
        stripeSubscriptionId: invoice.subscription as string,
        amountPaid: invoice.amount_paid / 100,
        currency: invoice.currency,
        status: invoice.status,
        customerEmail: invoice.customer_email,
        hostedInvoiceUrl: invoice.hosted_invoice_url,
        invoicePdf: invoice.invoice_pdf,
      };

      if (userId) {
        updateData.userId = userId;
      }

      await this.stripeInvoiceModel.findOneAndUpdate(
        { stripeInvoiceId: invoice.id },
        updateData,
        { upsert: true, new: true }
      );
    } catch (e) {
      this.logger.error(`Error saving invoice ${invoice.id}: ${e.message}`);
    }
  }

  private async getOrCreateStripeCustomer(
    companyId: string,
    customerEmail: string,
  ): Promise<string> {
    const existing = await this.subscriptionModel
      .findOne({ companyId: new Types.ObjectId(companyId) })
      .exec();

    if (existing?.stripeCustomerId) {
      return existing.stripeCustomerId;
    }

    const customer = await this.stripe.customers.create({
      email: customerEmail,
      metadata: { companyId },
    });

    return customer.id;
  }

  private async onCheckoutSessionCompleted(session: any) {
    const companyId = session.metadata?.companyId;
    const planId = session.metadata?.planId as 'pro' | 'team';
    const userId = session.metadata?.userId;

    this.logger.debug(`Webhook checkout.session.completed extracted metadata: companyId=${companyId}, planId=${planId}, userId=${userId}`);

    if (!companyId || !planId) {
      this.logger.warn('checkout.session.completed: missing companyId or planId in metadata');
      return;
    }

    // Retrieve the full subscription object to get period dates
    const stripeSub = session.subscription
      ? await this.stripe.subscriptions.retrieve(session.subscription as string)
      : null;

    await this.subscriptionModel.findOneAndUpdate(
      { companyId: new Types.ObjectId(companyId) },
      {
        planId,
        status: 'active',
        stripeCustomerId: session.customer as string,
        stripeSubscriptionId: stripeSub?.id,
        stripePriceId: stripeSub?.items.data[0]?.price.id,
        currentPeriodStart: stripeSub ? new Date(stripeSub.current_period_start * 1000) : null,
        currentPeriodEnd: stripeSub ? new Date(stripeSub.current_period_end * 1000) : null,
        cancelAtPeriodEnd: stripeSub?.cancel_at_period_end ?? false,
        userId: userId,
      },
      { upsert: true, new: true },
    );

    this.logger.log(`Subscription activated: company=${companyId} plan=${planId}`);
  }

  private async onInvoicePaymentSucceeded(invoice: any) {
    const subscriptionId = (invoice as any).subscription as string;
    if (!subscriptionId) return;

    const stripeSub = await this.stripe.subscriptions.retrieve(subscriptionId);
    const companyId = stripeSub.metadata?.companyId;
    const userId = stripeSub.metadata?.userId;

    this.logger.debug(`Webhook invoice.payment_succeeded extracted metadata: companyId=${companyId}, userId=${userId}`);

    if (!companyId) return;

    await this.subscriptionModel.findOneAndUpdate(
      { companyId: new Types.ObjectId(companyId) },
      {
        status: 'active',
        currentPeriodStart: new Date(stripeSub.current_period_start * 1000),
        currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
        cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
      },
    );

    await this.saveStripeInvoice(companyId, invoice, userId);

    this.logger.log(`Invoice paid — subscription renewed: company=${companyId}`);
  }

  private async onInvoicePaymentFailed(invoice: any) {
    const subscriptionId = (invoice as any).subscription as string;
    if (!subscriptionId) return;

    const stripeSub = await this.stripe.subscriptions.retrieve(subscriptionId);
    const companyId = stripeSub.metadata?.companyId;
    const userId = stripeSub.metadata?.userId;
    if (!companyId) return;

    await this.subscriptionModel.findOneAndUpdate(
      { companyId: new Types.ObjectId(companyId) },
      { status: 'past_due' },
    );

    await this.saveStripeInvoice(companyId, invoice, userId);

    this.logger.warn(`Payment failed — subscription past_due: company=${companyId}`);
  }

  private async onSubscriptionUpdated(stripeSub: any) {
    const companyId = stripeSub.metadata?.companyId;
    if (!companyId) return;

    await this.subscriptionModel.findOneAndUpdate(
      { companyId: new Types.ObjectId(companyId) },
      {
        status: stripeSub.status,
        currentPeriodStart: new Date(stripeSub.current_period_start * 1000),
        currentPeriodEnd: new Date(stripeSub.current_period_end * 1000),
        cancelAtPeriodEnd: stripeSub.cancel_at_period_end,
      },
    );

    this.logger.log(
      `Subscription updated: company=${companyId} cancelAtPeriodEnd=${stripeSub.cancel_at_period_end}`,
    );
  }

  private async onSubscriptionDeleted(stripeSub: any) {
    const companyId = stripeSub.metadata?.companyId;
    if (!companyId) return;

    // Downgrade to basic at end of period (status marks it canceled but plan stays until period end)
    await this.subscriptionModel.findOneAndUpdate(
      { companyId: new Types.ObjectId(companyId) },
      {
        planId: 'basic',
        status: 'canceled',
        stripeSubscriptionId: null,
        stripePriceId: null,
        cancelAtPeriodEnd: false,
      },
    );

    this.logger.log(`Subscription canceled — downgraded to basic: company=${companyId}`);
  }
}
