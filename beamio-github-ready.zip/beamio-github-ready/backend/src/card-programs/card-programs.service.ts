import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import {
  CardTemplate,
  CardTemplateDocument,
} from '../schemas/card-template.schema';

@Injectable()
export class CardProgramsService {
  constructor(
    @InjectModel(CardTemplate.name)
    private cardTemplateModel: Model<CardTemplateDocument>,
  ) {}

  async findAll(
    companyId?: string,
    page: number = 1,
    limit: number = 10,
    search?: string,
    type?: string,
  ) {
    const skip = (page - 1) * limit;
    const filter: any = {};
    if (companyId) filter.companyId = companyId;
    if (type) filter.type = type;

    if (search) {
      filter.$or = [
        { programName: { $regex: search, $options: 'i' } },
        { issuerName: { $regex: search, $options: 'i' } },
      ];
    }
    const [data, total] = await Promise.all([
      this.cardTemplateModel
        .find(filter)
        .populate('companyId', 'name')
        .populate('createdBy', 'firstName lastName')
        .skip(skip)
        .limit(limit)
        .sort({ createdAt: -1 })
        .exec(),
      this.cardTemplateModel.countDocuments(filter).exec(),
    ]);

    return {
      data,
      total,
      page,
      lastPage: Math.ceil(total / limit),
    };
  }

  async findOne(id: string) {
    const program = await this.cardTemplateModel.findById(id).exec();
    if (!program) throw new NotFoundException('Card Program not found');
    return program;
  }

  async create(templateData: Partial<CardTemplate>) {
    const createdTemplate = new this.cardTemplateModel(templateData);
    return createdTemplate.save();
  }

  async update(id: string, updateData: Partial<CardTemplate>) {
    const updatedTemplate = await this.cardTemplateModel
      .findByIdAndUpdate(id, updateData, { new: true })
      .exec();
    if (!updatedTemplate) throw new NotFoundException('Card Program not found');
    return updatedTemplate;
  }

  async remove(id: string) {
    const deletedTemplate = await this.cardTemplateModel
      .findByIdAndDelete(id)
      .exec();
    if (!deletedTemplate) throw new NotFoundException('Card Program not found');
    return deletedTemplate;
  }
}
