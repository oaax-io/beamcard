import { Test, TestingModule } from '@nestjs/testing';
import { CardProgramsService } from './card-programs.service';

describe('CardProgramsService', () => {
  let service: CardProgramsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CardProgramsService],
    }).compile();

    service = module.get<CardProgramsService>(CardProgramsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
