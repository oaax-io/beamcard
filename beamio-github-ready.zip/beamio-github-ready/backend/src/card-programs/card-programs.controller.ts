import { Controller, Get, Post, Body, Param, Put, Delete, UseGuards, Query, ParseIntPipe, DefaultValuePipe, Request } from '@nestjs/common';
import { CardProgramsService } from './card-programs.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Public } from '../common/decorators/public.decorator';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery, ApiOkResponse, ApiCreatedResponse, ApiParam, ApiBody } from '@nestjs/swagger';
import { CreateCardProgramDto, UpdateCardProgramDto } from './dto/create-card-program.dto';

@ApiTags('Card Programs (Templates)')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('card-programs')
export class CardProgramsController {
  constructor(private readonly cardProgramsService: CardProgramsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all card programs', description: 'Retrieve a paginated list of card programs, optionally filtered by company ID and search term.' })
  @ApiOkResponse({ description: 'List of card programs retrieved successfully' })
  @ApiQuery({ name: 'page', required: false, type: Number, example: 1 })
  @ApiQuery({ name: 'limit', required: false, type: Number, example: 10 })
  @ApiQuery({ name: 'companyId', required: false, type: String, example: '60d21b4667d0d8992e610c85' })
  @ApiQuery({ name: 'search', required: false, type: String, example: 'Gold' })
  @ApiQuery({ name: 'type', required: false, type: String, example: 'loyalty', description: 'Filter by card type: loyalty, business_card' })
  findAll(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(10), ParseIntPipe) limit: number,
    @Query('companyId') companyId?: string,
    @Query('search') search?: string,
    @Query('type') type?: string,
  ) {
    return this.cardProgramsService.findAll(companyId, page, limit, search, type);
  }

  @Public()
  @Get(':id')
  @ApiOperation({ summary: 'Get a card program by ID', description: 'Retrieve detailed information about a specific card program.' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the card program' })
  @ApiOkResponse({ description: 'Card program details retrieved successfully' })
  findOne(@Param('id') id: string) {
    return this.cardProgramsService.findOne(id);
  }

  @Roles('SUPERADMIN', 'TENANT')
  @Post()
  @ApiOperation({ summary: 'Create a new card program', description: 'Define a new card program (loyalty or business card template).' })
  @ApiBody({ 
    type: CreateCardProgramDto,
    examples: {
      loyalty: {
        summary: 'Loyalty Program Example',
        description: 'A standard loyalty program with points per purchase and a welcome bonus.',
        value: {
          companyId: '60d21b4667d0d8992e610c85',
          type: 'loyalty',
          programName: 'Gold Rewards',
          issuerName: 'Acme Corp',
          backgroundColor: '#4338ca',
          rules: {
            pointsPerPurchase: 10,
            welcomeBonus: 100
          }
        }
      },
      business_card: {
        summary: 'Business Card Example',
        description: 'A digital business card template with contact information.',
        value: {
          companyId: '60d21b4667d0d8992e610c85',
          type: 'business_card',
          programName: 'Software Engineer',
          issuerName: 'John Doe',
          backgroundColor: '#1f2937',
          config: {
            firstName: 'John',
            lastName: 'Doe',
            jobTitle: 'Software Engineer',
            phone: '+41791234567',
            email: 'john.doe@example.com',
            linkedin: 'johndoe',
            instagram: 'johndoe_inst',
            facebook: 'johndoe_fb'
          }
        }
      }
    }
  })
  @ApiCreatedResponse({ description: 'Card program created successfully' })
  create(@Body() dto: CreateCardProgramDto, @Request() req: any) {
    return this.cardProgramsService.create({ ...dto, createdBy: req.user?.userId } as any);
  }

  @Roles('SUPERADMIN', 'TENANT')
  @Put(':id')
  @ApiOperation({ summary: 'Update a card program', description: 'Modify an existing card program\'s configuration.' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the card program' })
  @ApiBody({ type: UpdateCardProgramDto })
  @ApiOkResponse({ description: 'Card program updated successfully' })
  update(@Param('id') id: string, @Body() dto: UpdateCardProgramDto) {
    return this.cardProgramsService.update(id, dto as any);
  }

  @Roles('SUPERADMIN', 'TENANT')
  @Delete(':id')
  @ApiOperation({ summary: 'Delete a card program', description: 'Remove a card program definition.' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the card program' })
  @ApiOkResponse({ description: 'Card program deleted successfully' })
  remove(@Param('id') id: string) {
    return this.cardProgramsService.remove(id);
  }
}
