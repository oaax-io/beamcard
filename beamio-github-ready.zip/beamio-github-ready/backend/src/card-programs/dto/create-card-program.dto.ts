import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { IsDateString, IsEnum, IsNotEmpty, IsObject, IsOptional, IsString } from 'class-validator';

export class CreateCardProgramDto {
  @ApiProperty({ example: '60d21b4667d0d8992e610c85', description: 'The ID of the company this program belongs to' })
  @IsString()
  @IsNotEmpty()
  companyId: string;

  @ApiProperty({ example: 'loyalty', enum: ['loyalty', 'business_card'], description: 'Type of the card program' })
  @IsEnum(['loyalty', 'business_card'])
  @IsNotEmpty()
  type: string;

  @ApiProperty({ example: 'Gold Rewards', description: 'Name of the card program' })
  @IsString()
  @IsNotEmpty()
  programName: string;

  @ApiPropertyOptional({ example: 'https://example.com/logo.png', description: 'URL of the program logo' })
  @IsString()
  @IsOptional()
  logo?: string;

  @ApiPropertyOptional({ example: 'Acme Corp', description: 'Name of the issuer displayed on the card' })
  @IsString()
  @IsOptional()
  issuerName?: string;

  @ApiPropertyOptional({ example: '#FFFFFF', description: 'Background color of the card' })
  @IsString()
  @IsOptional()
  backgroundColor?: string;

  @ApiPropertyOptional({ example: 'https://example.com/hero.png', description: 'URL of the hero image displayed on the card' })
  @IsString()
  @IsOptional()
  heroImage?: string;

  @ApiPropertyOptional({ 
    description: 'Rules for the loyalty program (e.g. points per purchase)',
    example: { pointsPerPurchase: 10, welcomeBonus: 100 }
  })
  @IsObject()
  @IsOptional()
  rules?: Record<string, any>;

  @ApiPropertyOptional({ example: '3388000000022304910.gold_rewards', description: 'Google Wallet Class ID' })
  @IsString()
  @IsOptional()
  googleClassId?: string;

  @ApiPropertyOptional({ example: 'pass.com.beamcard.aroma', description: 'Apple Pass Type Identifier' })
  @IsString()
  @IsOptional()
  applePassTypeIdentifier?: string;

  @ApiPropertyOptional({ example: 'TEAMID1234', description: 'Apple Team Identifier' })
  @IsString()
  @IsOptional()
  appleTeamIdentifier?: string;

  @ApiPropertyOptional({ example: '2026-12-31T23:59:59Z', description: 'Expiration date of the program' })
  @IsDateString()
  @IsOptional()
  expiresAt?: Date;

  @ApiPropertyOptional({ 
    description: 'Custom configuration for the program',
    example: { primaryColor: '#000000' }
  })
  @IsObject()
  @IsOptional()
  config?: Record<string, any>;

  @ApiPropertyOptional({ example: 10, description: 'Points awarded per purchase' })
  @IsOptional()
  pointsPerPurchase?: number;

  @ApiPropertyOptional({ example: 100, description: 'Bonus points for joining' })
  @IsOptional()
  welcomeBonus?: number;

  @ApiPropertyOptional({ example: 'John', description: 'Default first name for business cards' })
  @IsOptional()
  firstName?: string;

  @ApiPropertyOptional({ example: 'Doe', description: 'Default last name for business cards' })
  @IsOptional()
  lastName?: string;

  @ApiPropertyOptional({ example: 'Software Engineer', description: 'Default job title for business cards' })
  @IsOptional()
  jobTitle?: string;

  @ApiPropertyOptional({ example: '+41791234567', description: 'Default phone for business cards' })
  @IsOptional()
  phone?: string;

  @ApiPropertyOptional({ example: 'john.doe@example.com', description: 'Default email for business cards' })
  @IsOptional()
  email?: string;

  @ApiPropertyOptional({ example: 'johndoe', description: 'LinkedIn username' })
  @IsOptional()
  linkedin?: string;

  @ApiPropertyOptional({ example: 'johndoe_inst', description: 'Instagram username' })
  @IsOptional()
  instagram?: string;

  @ApiPropertyOptional({ example: 'johndoe_fb', description: 'Facebook username' })
  @IsOptional()
  facebook?: string;
}

export class UpdateCardProgramDto extends PartialType(CreateCardProgramDto) {
  @ApiPropertyOptional({ example: '60d21b4667d0d8992e610c85', description: 'Internal Mongoose ID of the program' })
  @IsString()
  @IsOptional()
  _id?: string;
}
