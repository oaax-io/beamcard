import { Test, TestingModule } from '@nestjs/testing';
import { CardProgramsController } from './card-programs.controller';

describe('CardProgramsController', () => {
  let controller: CardProgramsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CardProgramsController],
    }).compile();

    controller = module.get<CardProgramsController>(CardProgramsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
