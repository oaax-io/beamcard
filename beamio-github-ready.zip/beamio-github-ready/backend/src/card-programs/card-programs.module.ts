import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CardProgramsService } from './card-programs.service';
import { CardProgramsController } from './card-programs.controller';
import { CardTemplate, CardTemplateSchema } from '../schemas/card-template.schema';

@Module({
  imports: [MongooseModule.forFeature([{ name: CardTemplate.name, schema: CardTemplateSchema }])],
  controllers: [CardProgramsController],
  providers: [CardProgramsService],
  exports: [CardProgramsService],
})
export class CardProgramsModule {}
