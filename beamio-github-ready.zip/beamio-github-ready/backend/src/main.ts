import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import * as cookieParser from 'cookie-parser';
import * as express from 'express';
import { existsSync } from 'fs';
import { join } from 'path';
import { AppModule } from './app.module';

async function bootstrap() {
  const defaultGoogleCreds = join(process.cwd(), '.secrets', 'google-wallet.json');
  if (!process.env.GOOGLE_APPLICATION_CREDENTIALS && existsSync(defaultGoogleCreds)) {
    process.env.GOOGLE_APPLICATION_CREDENTIALS = defaultGoogleCreds;
  }

  const app = await NestFactory.create(AppModule, { rawBody: true });
  
  app.enableCors({
    origin: ['http://localhost:3000', /^https?:\/\/(.*\.)?beamcard\.ch$/],
    credentials: true,
  });

  app.use(cookieParser());
  
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    forbidNonWhitelisted: true,
    transform: true,
  }));

  const config = new DocumentBuilder()
    .setTitle('Beamcard API')
    .setDescription('The Beamcard Backend API description')
    .setVersion('1.0')
    .addBearerAuth()
    .addCookieAuth('refreshToken')
    .build();
  
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);

  await app.listen(3001);
}
bootstrap();

// Triggering restart for .env changes
