import { ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { CreateUserDto } from './create-user.dto';

export class UpdateUserDto extends PartialType(CreateUserDto) {
  @ApiPropertyOptional({ example: '60d21b4667d0d8992e610c85', description: 'Internal Mongoose ID of the user' })
  @IsString()
  @IsOptional()
  _id?: string;
}
