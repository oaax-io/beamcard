import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User, UserDocument } from '../schemas/user.schema';

@Injectable()
export class UsersService {
  constructor(@InjectModel(User.name) private userModel: Model<UserDocument>) {}

  async findAll(page: number = 1, limit: number = 10, search?: string, role?: string, companyId?: string) {
    const skip = (page - 1) * limit;
    const filter: any = {
      role: { $ne: 'SUPERADMIN' },
    };

    if (role) {
      filter.role = role;
    }

    if (companyId) {
      filter.companyId = companyId;
    }

    if (search) {
      filter.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.userModel
        .find(filter)
        .select('-passwordHash')
        .skip(skip)
        .limit(limit)
        .sort({ createdAt: -1 })
        .exec(),
      this.userModel.countDocuments(filter).exec(),
    ]);

    return {
      data,
      total,
      page,
      lastPage: Math.ceil(total / limit),
    };
  }

  async findOne(id: string) {
    const user = await this.userModel
      .findById(id)
      .select('-passwordHash')
      .exec();
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async findByEmail(email: string) {
    return this.userModel.findOne({ email }).exec();
  }

  async findByPhone(phone: string) {
    return this.userModel.findOne({ phone }).exec();
  }

  async findByContact(contact: string) {
    // Search by email or phone
    return this.userModel
      .findOne({
        $or: [{ email: contact }, { phone: contact }],
      })
      .select('-passwordHash')
      .exec();
  }

  // passwordHash is already bcrypt-hashed by the controller before calling this
  async create(userData: Partial<User>) {
    const createdUser = new this.userModel(userData);
    return createdUser.save();
  }

  async createCustomer(
    email: string,
    firstName: string,
    lastName: string,
    phone?: string,
    extraData: any = {},
  ) {
    const createdUser = new this.userModel({
      email,
      firstName,
      lastName,
      phone,
      role: 'CUSTOMER',
      status: 'active',
      ...extraData,
    });
    return createdUser.save();
  }

  // passwordHash is already bcrypt-hashed by the controller before calling this
  async update(id: string, updateData: Partial<User>) {
    const updatedUser = await this.userModel
      .findByIdAndUpdate(
        id,
        { $set: updateData },
        { new: true, runValidators: false },
      )
      .select('-passwordHash')
      .exec();
    if (!updatedUser) throw new NotFoundException('User not found');
    return updatedUser;
  }

  async remove(id: string) {
    const deletedUser = await this.userModel
      .findByIdAndDelete(id)
      .select('-passwordHash')
      .exec();
    if (!deletedUser) throw new NotFoundException('User not found');
    return deletedUser;
  }
}
