import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards, ParseIntPipe, DefaultValuePipe } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags, ApiOkResponse, ApiCreatedResponse, ApiQuery, ApiParam } from '@nestjs/swagger';
import * as bcrypt from 'bcrypt';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

import { Public } from '../common/decorators/public.decorator';

@ApiTags('Users')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Public()
  @Get('find-by-contact')
  @ApiOperation({ summary: 'Find user by email or phone', description: 'Search for a user based on their email or phone number. Publicly accessible for enrollment flows.' })
  @ApiQuery({ name: 'contact', required: true, description: 'Email address or phone number' })
  @ApiOkResponse({ description: 'User found or null if not found' })
  findByContact(@Query('contact') contact: string) {
    if (!contact) return null;
    return this.usersService.findByContact(contact);
  }

  @Roles('SUPERADMIN', 'ADMIN')
  @Get()
  @ApiOperation({ summary: 'Get all users', description: 'Retrieve a paginated list of all users, filterable by search, role, and company.' })
  @ApiOkResponse({ description: 'List of users retrieved successfully' })
  @ApiQuery({ name: 'page', required: false, type: Number, example: 1 })
  @ApiQuery({ name: 'limit', required: false, type: Number, example: 10 })
  @ApiQuery({ name: 'search', required: false, type: String, example: 'John' })
  @ApiQuery({ name: 'role', required: false, type: String, example: 'ADMIN' })
  @ApiQuery({ name: 'companyId', required: false, type: String, example: '60d21b4667d0d8992e610c85' })
  findAll(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe) page: number,
    @Query('limit', new DefaultValuePipe(10), ParseIntPipe) limit: number,
    @Query('search') search?: string,
    @Query('role') role?: string,
    @Query('companyId') companyId?: string,
  ) {
    return this.usersService.findAll(page, limit, search, role, companyId);
  }

  @Roles('SUPERADMIN', 'ADMIN', 'TENANT')
  @Get(':id')
  @ApiOperation({ summary: 'Get a user by ID', description: 'Retrieve detailed information about a specific user by their unique identifier.' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the user' })
  @ApiOkResponse({ description: 'User details retrieved successfully' })
  findOne(@Param('id') id: string) {
    return this.usersService.findOne(id);
  }

  @Roles('SUPERADMIN', 'ADMIN')
  @Post()
  @ApiOperation({ summary: 'Create a new user', description: 'Create a new user account with specified role and company.' })
  @ApiCreatedResponse({ description: 'User created successfully' })
  async create(@Body() dto: CreateUserDto) {
    const { password, companyId, ...rest } = dto;
    const passwordHash = await bcrypt.hash(password, 10);
    return this.usersService.create({
      ...rest,
      passwordHash,
      ...(companyId ? { companyId: companyId as any } : {}),
    });
  }

  @Roles('SUPERADMIN', 'ADMIN', 'TENANT')
  @Put(':id')
  @ApiOperation({ summary: 'Update a user', description: 'Update an existing user\'s information.' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the user' })
  @ApiOkResponse({ description: 'User updated successfully' })
  async update(@Param('id') id: string, @Body() dto: UpdateUserDto) {
    const { password, companyId, ...rest } = dto;
    const updateData: any = { ...rest };
    if (password) {
      updateData.passwordHash = await bcrypt.hash(password, 10);
    }
    if (companyId) {
      updateData.companyId = companyId;
    }
    return this.usersService.update(id, updateData);
  }

  @Roles('SUPERADMIN', 'ADMIN', 'TENANT')
  @Delete(':id')
  @ApiOperation({ summary: 'Delete a user', description: 'Remove a user account.' })
  @ApiParam({ name: 'id', description: 'The unique identifier of the user' })
  @ApiOkResponse({ description: 'User deleted successfully' })
  remove(@Param('id') id: string) {
    return this.usersService.remove(id);
  }
}
