import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { getModelToken } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import * as bcrypt from 'bcrypt';
import { ConfigService } from '@nestjs/config';
import { User } from './schemas/user.schema';

async function bootstrap() {
  const app = await NestFactory.createApplicationContext(AppModule);
  
  const userModel = app.get<Model<User>>(getModelToken(User.name));
  const configService = app.get(ConfigService);
  
  const email = 'admin@beamcard.com';
  const existingAdmin = await userModel.findOne({ email });
  
  if (existingAdmin) {
    console.log('SuperAdmin already exists.');
  } else {
    const saltRounds = configService.get<number>('BCRYPT_SALT_ROUNDS') || 10;
    const passwordHash = await bcrypt.hash('admin', Number(saltRounds));
    
    await userModel.create({
      email,
      passwordHash,
      firstName: 'Bilel',
      lastName: 'Chagra',
      role: 'SUPERADMIN',
    });
    
    console.log('SuperAdmin seeded successfully.');
  }

  await app.close();
  process.exit(0);
}

bootstrap();
