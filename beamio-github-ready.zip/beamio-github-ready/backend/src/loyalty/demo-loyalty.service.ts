import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';

interface Credentials {
  client_email: string;
  private_key: string;
  project_id: string;
}

@Injectable()
export class DemoLoyaltyService {
  private readonly logger = new Logger(DemoLoyaltyService.name);
  private keyFilePath: string;
  private credentials: Credentials;
  private client: any;

  constructor(private configService: ConfigService) {
    this.keyFilePath = this.configService.get<string>('GOOGLE_APPLICATION_CREDENTIALS')!;
    if (!this.keyFilePath) {
      throw new Error('GOOGLE_APPLICATION_CREDENTIALS environment variable is required');
    }
    this.auth();
  }

  private auth() {
    const { google } = require('googleapis');
    const auth = new google.auth.GoogleAuth({
      keyFile: this.keyFilePath,
      scopes: ['https://www.googleapis.com/auth/wallet_object.issuer'],
    });

    this.credentials = require(this.keyFilePath) as Credentials;
    this.client = google.walletobjects({
      version: 'v1',
      auth: auth,
    });
  }

  async createClass(issuerId: string, classSuffix: string): Promise<string> {
    let response;

    // Check if the class exists
    try {
      response = await this.client.loyaltyclass.get({
        resourceId: `${issuerId}.${classSuffix}`,
      });
      this.logger.log(`Class ${issuerId}.${classSuffix} already exists!`);
      return `${issuerId}.${classSuffix}`;
    } catch (err: any) {
      if (err.response && err.response.status !== 404) {
        this.logger.error(err);
        return `${issuerId}.${classSuffix}`;
      }
    }

    let newClass = {
      id: `${issuerId}.${classSuffix}`,
      issuerName: 'SRayen',
      reviewStatus: 'UNDER_REVIEW',
      programName: 'TechAzum',
      programLogo: {
        sourceUri: {
          uri: 'https://i.postimg.cc/J4337pqD/1668361684673.jpg',
        },
        contentDescription: {
          defaultValue: {
            language: 'en-US',
            value: 'Logo description',
          },
        },
      },
    };

    response = await this.client.loyaltyclass.insert({
      requestBody: newClass,
    });

    this.logger.log('Class insert response');
    this.logger.log(response);
    return `${issuerId}.${classSuffix}`;
  }

  async updateClass(issuerId: string, classSuffix: string): Promise<string> {
    let response;

    // Check if the class exists
    try {
      response = await this.client.loyaltyclass.get({
        resourceId: `${issuerId}.${classSuffix}`,
      });
    } catch (err: any) {
      if (err.response && err.response.status === 404) {
        this.logger.log(`Class ${issuerId}.${classSuffix} not found!`);
        return `${issuerId}.${classSuffix}`;
      } else {
        this.logger.error(err);
        return `${issuerId}.${classSuffix}`;
      }
    }

    // Class exists
    let updatedClass = response.data;

    // Update the class by adding a homepage
    updatedClass['homepageUri'] = {
      uri: 'https://developers.google.com/wallet',
      description: 'Homepage description',
    };

    updatedClass['reviewStatus'] = 'UNDER_REVIEW';

    response = await this.client.loyaltyclass.update({
      resourceId: `${issuerId}.${classSuffix}`,
      requestBody: updatedClass,
    });

    this.logger.log('Class update response');
    this.logger.log(response);
    return `${issuerId}.${classSuffix}`;
  }

  async patchClass(issuerId: string, classSuffix: string, templateData?: any): Promise<string> {
    let response;

    // Check if the class exists
    try {
      response = await this.client.loyaltyclass.get({
        resourceId: `${issuerId}.${classSuffix}`,
      });
    } catch (err: any) {
      if (err.response && err.response.status === 404) {
        this.logger.log(`Class ${issuerId}.${classSuffix} not found! Creating it...`);
        let newClass: any = {
          id: `${issuerId}.${classSuffix}`,
          issuerName: templateData?.issuerName || 'BeamCard Tenant',
          reviewStatus: 'UNDER_REVIEW',
          programName: templateData?.programName || 'Loyalty Program',
        };
        if (templateData?.logo) {
          const isBase64 = templateData.logo.startsWith('data:image');
          newClass.programLogo = {
            sourceUri: { uri: isBase64 ? 'https://i.postimg.cc/J4337pqD/1668361684673.jpg' : templateData.logo },
            contentDescription: { defaultValue: { language: 'en-US', value: 'Logo description' } },
          };
        }
        if (templateData?.backgroundColor) {
          newClass.hexBackgroundColor = templateData.backgroundColor;
        }

        try {
          await this.client.loyaltyclass.insert({ requestBody: newClass });
          this.logger.log(`Class ${issuerId}.${classSuffix} created successfully.`);
          return `${issuerId}.${classSuffix}`;
        } catch (insertErr) {
          this.logger.error(`Failed to create class ${issuerId}.${classSuffix}`, insertErr);
          throw insertErr;
        }
      } else {
        this.logger.error(err);
        return `${issuerId}.${classSuffix}`;
      }
    }

    // Patch the class
    let patchBody: any = {
      issuerName: templateData?.issuerName || 'BeamCard Tenant',
      programName: templateData?.programName || 'Loyalty Program',
      homepageUri: {
        uri: 'https://developers.google.com/wallet',
        description: 'Homepage description',
      },
      reviewStatus: 'UNDER_REVIEW',
    };
    if (templateData?.logo) {
      const isBase64 = templateData.logo.startsWith('data:image');
      patchBody.programLogo = {
        sourceUri: { uri: isBase64 ? 'https://i.postimg.cc/J4337pqD/1668361684673.jpg' : templateData.logo },
        contentDescription: { defaultValue: { language: 'en-US', value: 'Logo description' } },
      };
    }
    
    if (templateData?.backgroundColor) {
      patchBody.hexBackgroundColor = templateData.backgroundColor;
    }

    response = await this.client.loyaltyclass.patch({
      resourceId: `${issuerId}.${classSuffix}`,
      requestBody: patchBody,
    });

    this.logger.log('Class patch response');
    this.logger.log(response);
    return `${issuerId}.${classSuffix}`;
  }

  async addClassMessage(issuerId: string, classSuffix: string, header: string, body: string): Promise<string> {
    let response;

    // Check if the class exists
    try {
      response = await this.client.loyaltyclass.get({
        resourceId: `${issuerId}.${classSuffix}`,
      });
    } catch (err: any) {
      if (err.response && err.response.status === 404) {
        this.logger.log(`Class ${issuerId}.${classSuffix} not found!`);
        return `${issuerId}.${classSuffix}`;
      } else {
        this.logger.error(err);
        return `${issuerId}.${classSuffix}`;
      }
    }

    response = await this.client.loyaltyclass.addmessage({
      resourceId: `${issuerId}.${classSuffix}`,
      requestBody: {
        message: {
          header: header,
          body: body,
        },
      },
    });

    this.logger.log('Class addMessage response');
    this.logger.log(response);
    return `${issuerId}.${classSuffix}`;
  }

  async createObject(issuerId: string, classSuffix: string, objectSuffix: string): Promise<string> {
    let response;

    // Check if the object exists
    try {
      response = await this.client.loyaltyobject.get({
        resourceId: `${issuerId}.${objectSuffix}`,
      });
      this.logger.log(`Object ${issuerId}.${objectSuffix} already exists!`);
      return `${issuerId}.${objectSuffix}`;
    } catch (err: any) {
      if (err.response && err.response.status !== 404) {
        this.logger.error(err);
        return `${issuerId}.${objectSuffix}`;
      }
    }

    let newObject = {
      id: `${issuerId}.${objectSuffix}`,
      classId: `${issuerId}.${classSuffix}`,
      state: 'ACTIVE',
      heroImage: {
        sourceUri: {
          uri: 'https://farm4.staticflickr.com/3723/11177041115_6e6a3b6f49_o.jpg',
        },
        contentDescription: {
          defaultValue: {
            language: 'en-US',
            value: 'Hero image description',
          },
        },
      },
      textModulesData: [
        {
          header: 'Text module header',
          body: 'Text module body',
          id: 'TEXT_MODULE_ID',
        },
      ],
      linksModuleData: {
        uris: [
          {
            uri: 'http://maps.google.com/',
            description: 'Link module URI description',
            id: 'LINK_MODULE_URI_ID',
          },
          {
            uri: 'tel:6505555555',
            description: 'Link module tel description',
            id: 'LINK_MODULE_TEL_ID',
          },
        ],
      },
      imageModulesData: [
        {
          mainImage: {
            sourceUri: {
              uri: 'http://farm4.staticflickr.com/3738/12440799783_3dc3c20606_b.jpg',
            },
            contentDescription: {
              defaultValue: {
                language: 'en-US',
                value: 'Image module description',
              },
            },
          },
          id: 'IMAGE_MODULE_ID',
        },
      ],
      barcode: {
        type: 'QR_CODE',
        value: 'QR code',
      },
      locations: [
        {
          latitude: 37.424015499999996,
          longitude: -122.09259560000001,
        },
      ],
      accountId: 'Account id',
      accountName: 'Account name',
      loyaltyPoints: {
        label: 'Points',
        balance: {
          int: 0,
        },
      },
    };

    response = await this.client.loyaltyobject.insert({
      requestBody: newObject,
    });

    this.logger.log('Object insert response');
    this.logger.log(response);
    return `${issuerId}.${objectSuffix}`;
  }

  async updateObject(issuerId: string, objectSuffix: string): Promise<string> {
    let response;

    // Check if the object exists
    try {
      response = await this.client.loyaltyobject.get({
        resourceId: `${issuerId}.${objectSuffix}`,
      });
    } catch (err: any) {
      if (err.response && err.response.status === 404) {
        this.logger.log(`Object ${issuerId}.${objectSuffix} not found!`);
        return `${issuerId}.${objectSuffix}`;
      } else {
        this.logger.error(err);
        return `${issuerId}.${objectSuffix}`;
      }
    }

    // Object exists
    let updatedObject = response.data;

    // Update the object by adding a link
    let newLink = {
      uri: 'https://developers.google.com/wallet',
      description: 'New link description',
    };
    if (updatedObject['linksModuleData'] === undefined) {
      updatedObject['linksModuleData'] = {
        uris: [newLink],
      };
    } else {
      updatedObject['linksModuleData']['uris'].push(newLink);
    }

    response = await this.client.loyaltyobject.update({
      resourceId: `${issuerId}.${objectSuffix}`,
      requestBody: updatedObject,
    });

    this.logger.log('Object update response');
    this.logger.log(response);
    return `${issuerId}.${objectSuffix}`;
  }

  async patchObjectBalance(issuerId: string, objectSuffix: string, newBalance: number, type: 'award' | 'redeem' = 'award', amount: number = 0): Promise<void> {
    try {
      await this.client.loyaltyobject.get({ resourceId: `${issuerId}.${objectSuffix}` });
    } catch (err: any) {
      if (err.response?.status === 404) {
        this.logger.log(`Wallet object ${issuerId}.${objectSuffix} not yet saved by user — skipping balance patch.`);
        return;
      }
    }
    try {
      await this.client.loyaltyobject.patch({
        resourceId: `${issuerId}.${objectSuffix}`,
        requestBody: {
          loyaltyPoints: { label: 'Points', balance: { int: Math.round(newBalance) } },
          notifyPreference: 'NOTIFY_ON_UPDATE',
        },
      });
      this.logger.log(`Patched wallet object ${issuerId}.${objectSuffix} balance → ${newBalance}`);
    } catch (err: any) {
      this.logger.error(`Failed to patch wallet object balance: ${err.message}`);
      return;
    }
    try {
      const header = type === 'award' ? `+${amount} points added!` : `-${amount} points redeemed`;
      const body = `Your new balance is ${Math.round(newBalance)} points.`;
      await this.client.loyaltyobject.addmessage({
        resourceId: `${issuerId}.${objectSuffix}`,
        requestBody: { message: { header, body } },
      });
      this.logger.log(`Push notification sent for object ${issuerId}.${objectSuffix}`);
    } catch (err: any) {
      this.logger.error(`Failed to send push notification: ${err.message}`);
    }
  }

  async patchObject(issuerId: string, objectSuffix: string): Promise<string> {
    let response;

    // Check if the object exists
    try {
      response = await this.client.loyaltyobject.get({
        resourceId: `${issuerId}.${objectSuffix}`,
      });
    } catch (err: any) {
      if (err.response && err.response.status === 404) {
        this.logger.log(`Object ${issuerId}.${objectSuffix} not found!`);
        return `${issuerId}.${objectSuffix}`;
      } else {
        this.logger.error(err);
        return `${issuerId}.${objectSuffix}`;
      }
    }

    // Object exists
    let existingObject = response.data;

    // Patch the object by adding a link
    let newLink = {
      uri: 'https://developers.google.com/wallet',
      description: 'New link description',
    };

    let patchBody = {};
    if (existingObject['linksModuleData'] === undefined) {
      patchBody['linksModuleData'] = {
        uris: [],
      };
    } else {
      patchBody['linksModuleData'] = {
        uris: existingObject['linksModuleData']['uris'],
      };
    }
    patchBody['linksModuleData']['uris'].push(newLink);

    response = await this.client.loyaltyobject.patch({
      resourceId: `${issuerId}.${objectSuffix}`,
      requestBody: patchBody,
    });

    this.logger.log('Object patch response');
    this.logger.log(response);
    return `${issuerId}.${objectSuffix}`;
  }

  async expireObject(issuerId: string, objectSuffix: string): Promise<string> {
    let response;

    // Check if the object exists
    try {
      response = await this.client.loyaltyobject.get({
        resourceId: `${issuerId}.${objectSuffix}`,
      });
    } catch (err: any) {
      if (err.response && err.response.status === 404) {
        this.logger.log(`Object ${issuerId}.${objectSuffix} not found!`);
        return `${issuerId}.${objectSuffix}`;
      } else {
        this.logger.error(err);
        return `${issuerId}.${objectSuffix}`;
      }
    }

    // Patch the object, setting the pass as expired
    let patchBody = {
      state: 'EXPIRED',
    };

    response = await this.client.loyaltyobject.patch({
      resourceId: `${issuerId}.${objectSuffix}`,
      requestBody: patchBody,
    });

    this.logger.log('Object expiration response');
    this.logger.log(response);
    return `${issuerId}.${objectSuffix}`;
  }

  async addObjectMessage(issuerId: string, objectSuffix: string, header: string, body: string): Promise<string> {
    let response;

    // Check if the object exists
    try {
      response = await this.client.loyaltyobject.get({
        resourceId: `${issuerId}.${objectSuffix}`,
      });
    } catch (err: any) {
      if (err.response && err.response.status === 404) {
        this.logger.log(`Object ${issuerId}.${objectSuffix} not found!`);
        return `${issuerId}.${objectSuffix}`;
      } else {
        this.logger.error(err);
        return `${issuerId}.${objectSuffix}`;
      }
    }

    response = await this.client.loyaltyobject.addmessage({
      resourceId: `${issuerId}.${objectSuffix}`, // FIXED: was classSuffix bug
      requestBody: {
        message: {
          header: header,
          body: body,
        },
      },
    });

    this.logger.log('Object addMessage response');
    this.logger.log(response);
    return `${issuerId}.${objectSuffix}`;
  }

  createJwtNewObjects(issuerId: string, classSuffix: string, objectSuffix: string, templateData?: any): string {
    let newClass: any = {
      id: `${issuerId}.${classSuffix}`,
      issuerName: templateData?.issuerName || 'BeamCard Tenant',
      reviewStatus: 'UNDER_REVIEW',
      programName: templateData?.programName || 'Loyalty Program',
    };
    if (templateData?.logo) {
      const isBase64 = templateData.logo.startsWith('data:image');
      newClass.programLogo = {
        sourceUri: { uri: isBase64 ? 'https://i.postimg.cc/J4337pqD/1668361684673.jpg' : templateData.logo },
        contentDescription: { defaultValue: { language: 'en-US', value: 'Logo description' } },
      };
    }
    
    if (templateData?.backgroundColor) {
      newClass.hexBackgroundColor = templateData.backgroundColor;
    }

    let newObject: any = {
      id: `${issuerId}.${objectSuffix}`,
      classId: `${issuerId}.${classSuffix}`,
      state: 'ACTIVE',
      barcode: {
        type: 'QR_CODE',
        value: templateData?.qrCodeData || (templateData?.customerId ? String(templateData.customerId) : objectSuffix),
      },
      accountId: templateData?.customerId ? String(templateData.customerId) : objectSuffix,
      accountName: templateData?.customerName || 'Customer',
      loyaltyPoints: {
        label: 'Points',
        balance: {
          int: templateData?.welcomeBonus !== undefined ? parseInt(templateData.welcomeBonus, 10) : 0,
        },
      },
    };

    if (templateData?.heroImage && templateData.heroImage.trim() !== '') {
      newObject.heroImage = {
        sourceUri: {
          uri: templateData.heroImage,
        },
        contentDescription: {
          defaultValue: {
            language: 'en-US',
            value: 'Cover Image',
          },
        },
      };
    }

    // Create the JWT claims
    let claims = {
      iss: this.credentials.client_email,
      aud: 'google',
      origins: [],
      typ: 'savetowallet',
      payload: {
        loyaltyClasses: [newClass],
        loyaltyObjects: [newObject],
      },
    };

    this.logger.log(`Generating JWT for Google Wallet. Issuer ID: ${issuerId}, Project: ${this.credentials.project_id}`);

    let token = jwt.sign(claims, this.credentials.private_key, {
      algorithm: 'RS256',
    });

    let jwtLink = `https://pay.google.com/gp/v/save/${token}`;
    this.logger.log('🔗 NOUVEAU LIEN:', jwtLink);
    return jwtLink;
  }

  createJwtExistingObjects(issuerId: string): string {
    let objectsToAdd = {
      eventTicketObjects: [{ id: `${issuerId}.EVENT_OBJECT_SUFFIX`, classId: `${issuerId}.EVENT_CLASS_SUFFIX` }],
      flightObjects: [{ id: `${issuerId}.FLIGHT_OBJECT_SUFFIX`, classId: `${issuerId}.FLIGHT_CLASS_SUFFIX` }],
      genericObjects: [{ id: `${issuerId}.GENERIC_OBJECT_SUFFIX`, classId: `${issuerId}.GENERIC_CLASS_SUFFIX` }],
      giftCardObjects: [{ id: `${issuerId}.GIFT_CARD_OBJECT_SUFFIX`, classId: `${issuerId}.GIFT_CARD_CLASS_SUFFIX` }],
      loyaltyObjects: [{ id: `${issuerId}.LOYALTY_OBJECT_SUFFIX`, classId: `${issuerId}.LOYALTY_CLASS_SUFFIX` }],
      offerObjects: [{ id: `${issuerId}.OFFER_OBJECT_SUFFIX`, classId: `${issuerId}.OFFER_CLASS_SUFFIX` }],
      transitObjects: [{ id: `${issuerId}.TRANSIT_OBJECT_SUFFIX`, classId: `${issuerId}.TRANSIT_CLASS_SUFFIX` }],
    };

    let claims = {
      iss: this.credentials.client_email,
      aud: 'google',
      origins: ['www.example.com'],
      typ: 'savetowallet',
      payload: objectsToAdd,
    };

    let token = jwt.sign(claims, this.credentials.private_key, {
      algorithm: 'RS256',
    });

    let jwtLink = `https://pay.google.com/gp/v/save/${token}`;
    this.logger.log('Add to Google Wallet link:', jwtLink);
    return jwtLink;
  }

  async batchCreateObjects(issuerId: string, classSuffix: string) {
    let data = '';
    let batchObject;
    let objectSuffix;

    for (let i = 0; i < 3; i++) {
      objectSuffix = uuidv4().replace(/[^\w.-]/g, '_');

      batchObject = {
        id: `${issuerId}.${objectSuffix}`,
        classId: `${issuerId}.${classSuffix}`,
        state: 'ACTIVE',
        heroImage: {
          sourceUri: { uri: 'https://farm4.staticflickr.com/3723/11177041115_6e6a3b6f49_o.jpg' },
          contentDescription: { defaultValue: { language: 'en-US', value: 'Hero image description' } },
        },
        textModulesData: [{ header: 'Text module header', body: 'Text module body', id: 'TEXT_MODULE_ID' }],
        linksModuleData: {
          uris: [
            { uri: 'http://maps.google.com/', description: 'Link module URI description', id: 'LINK_MODULE_URI_ID' },
            { uri: 'tel:6505555555', description: 'Link module tel description', id: 'LINK_MODULE_TEL_ID' },
          ],
        },
        imageModulesData: [{
          mainImage: {
            sourceUri: { uri: 'http://farm4.staticflickr.com/3738/12440799783_3dc3c20606_b.jpg' },
            contentDescription: { defaultValue: { language: 'en-US', value: 'Image module description' } },
          },
          id: 'IMAGE_MODULE_ID',
        }],
        barcode: { type: 'QR_CODE', value: 'QR code' },
        locations: [{ latitude: 37.424015499999996, longitude: -122.09259560000001 }],
        accountId: 'Account id',
        accountName: 'Account name',
        loyaltyPoints: { label: 'Points', balance: { int: 0 } },
      };

      data += '--batch_createobjectbatch\n';
      data += 'Content-Type: application/json\n\n';
      data += 'POST /walletobjects/v1/loyaltyObject\n\n';
      data += JSON.stringify(batchObject) + '\n\n';
    }
    data += '--batch_createobjectbatch--';

    let response = await this.client.context._options.auth.request({
      url: 'https://walletobjects.googleapis.com/batch',
      method: 'POST',
      data: data,
      headers: {
        'Content-Type': 'multipart/mixed; boundary=batch_createobjectbatch',
      },
    });

    this.logger.log('Batch insert response');
    this.logger.log(response);
  }
}
