import { Body, Controller, Post } from '@nestjs/common';
import { DemoLoyaltyService } from './demo-loyalty.service';
import { ApiTags, ApiOperation, ApiCreatedResponse, ApiBody } from '@nestjs/swagger';
import { LoyaltyCreateJwtDto, LoyaltyCreateClassDto, LoyaltyGenerateCardDto } from './dto/loyalty.dto';

@ApiTags('Loyalty (Legacy / Demo)')
@Controller('loyalty')
export class LoyaltyController {
  constructor(private demoLoyaltyService: DemoLoyaltyService) {}

  @Post('create-jwt')
  @ApiOperation({ summary: 'Create a loyalty JWT link', description: 'Generates a JWT link for adding a loyalty card to Google Wallet.' })
  @ApiBody({ type: LoyaltyCreateJwtDto })
  @ApiCreatedResponse({ description: 'JWT link generated successfully' })
  async createJwt(
    @Body() dto: LoyaltyCreateJwtDto,
  ) {
    const { issuerId, classSuffix, templateData } = dto;
    await this.demoLoyaltyService.patchClass(issuerId, classSuffix, templateData);
    const jwtLink = await this.demoLoyaltyService.createJwtNewObjects(
      issuerId,
      classSuffix,
      `client-${Date.now()}`,
      templateData,
    );
    return { jwtLink };
  }

  @Post('create-class')
  @ApiOperation({ summary: 'Create a loyalty class', description: 'Defines a new loyalty class in Google Wallet.' })
  @ApiBody({ type: LoyaltyCreateClassDto })
  @ApiCreatedResponse({ description: 'Loyalty class created successfully' })
  async createClass(
    @Body() dto: LoyaltyCreateClassDto,
  ) {
    const { issuerId, classSuffix, templateData } = dto;
    const classId = await this.demoLoyaltyService.patchClass(issuerId, classSuffix, templateData);
    return { classId };
  }

  @Post('generate-customer-card')
  @ApiOperation({ summary: 'Generate a customer card link', description: 'Create a specific loyalty card instance for a customer.' })
  @ApiBody({ type: LoyaltyGenerateCardDto })
  @ApiCreatedResponse({ description: 'Customer card link generated successfully' })
  async generateCustomerCard(
    @Body() dto: LoyaltyGenerateCardDto,
  ) {
    const { issuerId, classSuffix, customerId, templateData } = dto;
    // Inject customerId into templateData so it can be used for the barcode and accountId
    const enrichedTemplateData = {
      ...templateData,
      customerId,
    };

    // Generate a unique token for the specific customer
    const jwtLink = await this.demoLoyaltyService.createJwtNewObjects(
      issuerId,
      classSuffix,
      `${customerId}-${Date.now()}`,
      enrichedTemplateData,
    );
    return { jwtLink };
  }
}
