import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsObject, IsString } from 'class-validator';

export class LoyaltyCreateJwtDto {
  @ApiProperty({ example: '3388000000022304910', description: 'Google Wallet Issuer ID' })
  @IsString()
  @IsNotEmpty()
  issuerId: string;

  @ApiProperty({ example: 'loyalty_class', description: 'Suffix for the Google Wallet class' })
  @IsString()
  @IsNotEmpty()
  classSuffix: string;

  @ApiProperty({ 
    description: 'Data used to populate the loyalty card template',
    example: {
      issuerName: 'Acme Corp',
      programName: 'Gold Rewards',
      logo: 'https://example.com/logo.png',
      backgroundColor: '#FFFFFF'
    }
  })
  @IsObject()
  @IsNotEmpty()
  templateData: any;
}

export class LoyaltyCreateClassDto {
  @ApiProperty({ example: '3388000000022304910', description: 'Google Wallet Issuer ID' })
  @IsString()
  @IsNotEmpty()
  issuerId: string;

  @ApiProperty({ example: 'loyalty_class', description: 'Suffix for the Google Wallet class' })
  @IsString()
  @IsNotEmpty()
  classSuffix: string;

  @ApiProperty({ 
    description: 'Data used to define the loyalty class',
    example: {
      issuerName: 'Acme Corp',
      programName: 'Gold Rewards'
    }
  })
  @IsObject()
  @IsNotEmpty()
  templateData: any;
}

export class LoyaltyGenerateCardDto {
  @ApiProperty({ example: '3388000000022304910', description: 'Google Wallet Issuer ID' })
  @IsString()
  @IsNotEmpty()
  issuerId: string;

  @ApiProperty({ example: 'loyalty_class', description: 'Suffix for the Google Wallet class' })
  @IsString()
  @IsNotEmpty()
  classSuffix: string;

  @ApiProperty({ example: 'customer_123', description: 'Unique identifier for the customer' })
  @IsString()
  @IsNotEmpty()
  customerId: string;

  @ApiProperty({ 
    description: 'Data used to populate the customer card',
    example: {
      customerName: 'John Doe',
      welcomeBonus: 100
    }
  })
  @IsObject()
  @IsNotEmpty()
  templateData: any;
}
