import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { DemoLoyaltyService } from './demo-loyalty.service';
import { LoyaltyController } from './loyalty.controller';

@Module({
  imports: [ConfigModule],
  controllers: [LoyaltyController],
  providers: [DemoLoyaltyService],
  exports: [DemoLoyaltyService],
})
export class LoyaltyModule {}
